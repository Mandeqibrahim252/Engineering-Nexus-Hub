<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Question extends Model
{
    use HasFactory;

    protected $fillable = [
        'title',
        'body',
        'tags',
        'user_id',
        'votes',
        'answers_count',
        'views',
        'is_resolved',
    ];

    protected $casts = [
        'tags' => 'array',
        'votes' => 'integer',
        'answers_count' => 'integer',
        'views' => 'integer',
        'is_resolved' => 'boolean',
    ];

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function answers(): HasMany
    {
        return $this->hasMany(Answer::class)->orderBy('votes', 'desc');
    }

    public function getExcerptAttribute(): string
    {
        return \Str::limit($this->body, 150);
    }
}