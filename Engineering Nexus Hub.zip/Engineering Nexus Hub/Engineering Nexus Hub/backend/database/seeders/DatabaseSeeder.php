<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        DB::table('users')->insert([
            [
                'id' => 1,
                'name' => 'Admin User',
                'email' => 'admin@enh.com',
                'password' => Hash::make('password123'),
                'role' => 'admin',
                'field' => 'software',
                'bio' => 'Platform Administrator',
                'status' => 'active',
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'id' => 2,
                'name' => 'John Smith',
                'email' => 'john@enh.com',
                'password' => Hash::make('password123'),
                'role' => 'student',
                'field' => 'electrical',
                'bio' => 'Electrical Engineering Student',
                'status' => 'active',
                'created_at' => now(),
                'updated_at' => now(),
            ],
        ]);

        DB::table('courses')->insert([
            [
                'id' => 1,
                'title' => 'Circuit Analysis Fundamentals',
                'description' => 'Learn the basics of electrical circuit analysis including Ohm\'s Law, Kirchhoff\'s Laws, and circuit theorems.',
                'field' => 'electrical',
                'level' => 'beginner',
                'duration' => '4 hours',
                'rating' => 45,
                'students' => 1250,
                'instructor_id' => 1,
                'is_published' => true,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'id' => 2,
                'title' => 'Digital Electronics Basics',
                'description' => 'Introduction to digital logic gates, flip-flops, and combinational circuits.',
                'field' => 'electrical',
                'level' => 'beginner',
                'duration' => '3 hours',
                'rating' => 42,
                'students' => 890,
                'instructor_id' => 1,
                'is_published' => true,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'id' => 3,
                'title' => 'Thermodynamics: From Basics to Advanced',
                'description' => 'Comprehensive course covering thermodynamic principles, heat transfer, and energy systems.',
                'field' => 'mechanical',
                'level' => 'intermediate',
                'duration' => '6 hours',
                'rating' => 48,
                'students' => 2100,
                'instructor_id' => 1,
                'is_published' => true,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'id' => 4,
                'title' => 'Structural Engineering Masterclass',
                'description' => 'Learn structural analysis, design principles, and practical applications in civil engineering.',
                'field' => 'civil',
                'level' => 'advanced',
                'duration' => '8 hours',
                'rating' => 46,
                'students' => 750,
                'instructor_id' => 1,
                'is_published' => true,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'id' => 5,
                'title' => 'Python for Engineers',
                'description' => 'Learn Python programming with focus on engineering applications and problem solving.',
                'field' => 'software',
                'level' => 'beginner',
                'duration' => '5 hours',
                'rating' => 49,
                'students' => 3200,
                'instructor_id' => 1,
                'is_published' => true,
                'created_at' => now(),
                'updated_at' => now(),
            ],
        ]);

        DB::table('jobs')->insert([
            [
                'id' => 1,
                'title' => 'Junior Electrical Engineer',
                'description' => 'Design and maintain medical equipment electrical systems. Join our team to work on innovative healthcare technology.',
                'company' => 'MedTech Solutions',
                'location' => 'Mogadishu',
                'type' => 'Full-time',
                'salary' => '$800 - $1,200/month',
                'field' => 'electrical',
                'posted_by' => 1,
                'is_active' => true,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'id' => 2,
                'title' => 'Software Developer',
                'description' => 'Develop web and mobile applications. Create solutions that impact thousands of users across Somalia.',
                'company' => 'TechHub Somalia',
                'location' => 'Garowe',
                'type' => 'Full-time',
                'salary' => '$1,000 - $1,500/month',
                'field' => 'software',
                'posted_by' => 1,
                'is_active' => true,
                'created_at' => now(),
                'updated_at' => now(),
            ],
        ]);

        DB::table('questions')->insert([
            [
                'id' => 1,
                'user_id' => 2,
                'title' => 'How to calculate resistance in a complex circuit?',
                'body' => 'I have a circuit with multiple resistors in series and parallel configuration. How do I simplify it to find the total resistance?',
                'field' => 'electrical',
                'votes' => 15,
                'views' => 234,
                'is_solved' => true,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'id' => 2,
                'user_id' => 2,
                'title' => 'Best programming language for mechanical engineers?',
                'body' => 'I\'m a mechanical engineering student looking to learn programming. Which language would be most useful for my career?',
                'field' => 'mechanical',
                'votes' => 23,
                'views' => 456,
                'is_solved' => false,
                'created_at' => now(),
                'updated_at' => now(),
            ],
        ]);

        DB::table('answers')->insert([
            [
                'id' => 1,
                'question_id' => 1,
                'user_id' => 1,
                'body' => 'For complex circuits, use Kirchhoff\'s Laws: 1) Sum of voltages around a loop = 0, 2) Current into junction = current out. Simplify step by step starting with parallel resistors first.',
                'votes' => 12,
                'is_accepted' => true,
                'created_at' => now(),
                'updated_at' => now(),
            ],
        ]);
    }
}