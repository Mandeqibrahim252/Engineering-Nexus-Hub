<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
*/

Route::prefix('v1')->group(function () {

    // Public Routes
    Route::post('/auth/register', [App\Http\Controllers\Auth\AuthController::class, 'register']);
    Route::post('/auth/login', [App\Http\Controllers\Auth\AuthController::class, 'login']);

    // Public Course Routes
    Route::get('/courses', [App\Http\Controllers\Course\CourseController::class, 'index']);
    Route::get('/courses/{id}', [App\Http\Controllers\Course\CourseController::class, 'show']);

    // Public Job Routes
    Route::get('/jobs', [App\Http\Controllers\Job\JobController::class, 'index']);
    Route::get('/jobs/{id}', [App\Http\Controllers\Job\JobController::class, 'show']);

    // Public Question Routes
    Route::get('/questions', [App\Http\Controllers\Forum\QuestionController::class, 'index']);
    Route::get('/questions/{id}', [App\Http\Controllers\Forum\QuestionController::class, 'show']);

    // Public Resource Routes
    Route::get('/resources', [App\Http\Controllers\Resource\ResourceController::class, 'index']);
    Route::get('/resources/{id}', [App\Http\Controllers\Resource\ResourceController::class, 'show']);

    // Protected Routes
    Route::middleware('auth:api')->group(function () {

        // Auth Routes
        Route::post('/auth/logout', [App\Http\Controllers\Auth\AuthController::class, 'logout']);
        Route::get('/auth/me', [App\Http\Controllers\Auth\AuthController::class, 'me']);
        Route::put('/auth/profile', [App\Http\Controllers\Auth\AuthController::class, 'updateProfile']);

        // User Routes
        Route::get('/users/{id}', [App\Http\Controllers\User\UserController::class, 'show']);
        Route::put('/users/{id}', [App\Http\Controllers\User\UserController::class, 'update']);

        // Course Routes
        Route::post('/courses', [App\Http\Controllers\Course\CourseController::class, 'store']);
        Route::put('/courses/{id}', [App\Http\Controllers\Course\CourseController::class, 'update']);
        Route::delete('/courses/{id}', [App\Http\Controllers\Course\CourseController::class, 'destroy']);
        Route::get('/courses/{id}/lessons', [App\Http\Controllers\Course\LessonController::class, 'index']);
        Route::post('/courses/{id}/enroll', [App\Http\Controllers\Course\CourseController::class, 'enroll']);
        Route::get('/courses/enrolled', [App\Http\Controllers\Course\CourseController::class, 'enrolledCourses']);

        // Lesson Routes
        Route::get('/lessons/{id}', [App\Http\Controllers\Course\LessonController::class, 'show']);
        Route::post('/lessons', [App\Http\Controllers\Course\LessonController::class, 'store']);
        Route::put('/lessons/{id}', [App\Http\Controllers\Course\LessonController::class, 'update']);
        Route::delete('/lessons/{id}', [App\Http\Controllers\Course\LessonController::class, 'destroy']);
        Route::post('/lessons/{id}/complete', [App\Http\Controllers\Course\LessonController::class, 'complete']);

        // Quiz Routes
        Route::get('/quizzes/{id}', [App\Http\Controllers\Course\QuizController::class, 'show']);
        Route::post('/quizzes/{id}/submit', [App\Http\Controllers\Course\QuizController::class, 'submit']);

        // Resource Routes
        Route::post('/resources', [App\Http\Controllers\Resource\ResourceController::class, 'store']);
        Route::put('/resources/{id}', [App\Http\Controllers\Resource\ResourceController::class, 'update']);
        Route::delete('/resources/{id}', [App\Http\Controllers\Resource\ResourceController::class, 'destroy']);
        Route::get('/resources/download/{id}', [App\Http\Controllers\Resource\ResourceController::class, 'download']);

        // Job Routes
        Route::post('/jobs', [App\Http\Controllers\Job\JobController::class, 'store']);
        Route::put('/jobs/{id}', [App\Http\Controllers\Job\JobController::class, 'update']);
        Route::delete('/jobs/{id}', [App\Http\Controllers\Job\JobController::class, 'destroy']);
        Route::post('/jobs/{id}/apply', [App\Http\Controllers\Job\ApplicationController::class, 'apply']);
        Route::post('/jobs/{id}/bookmark', [App\Http\Controllers\Job\JobController::class, 'bookmark']);

        // Application Routes
        Route::get('/applications', [App\Http\Controllers\Job\ApplicationController::class, 'index']);
        Route::get('/applications/{id}', [App\Http\Controllers\Job\ApplicationController::class, 'show']);
        Route::put('/applications/{id}/status', [App\Http\Controllers\Job\ApplicationController::class, 'updateStatus']);

        // Question Routes
        Route::post('/questions', [App\Http\Controllers\Forum\QuestionController::class, 'store']);
        Route::put('/questions/{id}', [App\Http\Controllers\Forum\QuestionController::class, 'update']);
        Route::delete('/questions/{id}', [App\Http\Controllers\Forum\QuestionController::class, 'destroy']);
        Route::post('/questions/{id}/answers', [App\Http\Controllers\Forum\AnswerController::class, 'store']);
        Route::post('/questions/{id}/vote', [App\Http\Controllers\Forum\QuestionController::class, 'vote']);

        // Answer Routes
        Route::put('/answers/{id}', [App\Http\Controllers\Forum\AnswerController::class, 'update']);
        Route::delete('/answers/{id}', [App\Http\Controllers\Forum\AnswerController::class, 'destroy']);
        Route::post('/answers/{id}/vote', [App\Http\Controllers\Forum\AnswerController::class, 'vote']);
        Route::post('/answers/{id}/accept', [App\Http\Controllers\Forum\AnswerController::class, 'accept']);

        // Tool Routes
        Route::post('/tools/ohms-law', [App\Http\Controllers\Tool\CalculatorController::class, 'ohmsLaw']);
        Route::post('/tools/unit-convert', [App\Http\Controllers\Tool\CalculatorController::class, 'unitConvert']);
        Route::post('/tools/load-calc', [App\Http\Controllers\Tool\CalculatorController::class, 'loadCalc']);

        // Notification Routes
        Route::get('/notifications', [App\Http\Controllers\User\NotificationController::class, 'index']);
        Route::put('/notifications/{id}/read', [App\Http\Controllers\User\NotificationController::class, 'markRead']);
    });

    // Admin Routes
    Route::middleware(['auth:api', 'role:admin'])->group(function () {
        Route::get('/admin/users', [App\Http\Controllers\User\UserController::class, 'index']);
        Route::delete('/admin/users/{id}', [App\Http\Controllers\User\UserController::class, 'destroy']);
        Route::get('/admin/stats', [App\Http\Controllers\User\UserController::class, 'stats']);
    });
});