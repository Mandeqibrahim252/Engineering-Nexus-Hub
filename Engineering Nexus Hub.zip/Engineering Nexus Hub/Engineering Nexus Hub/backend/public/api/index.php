<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

define('DB_HOST', 'localhost');
define('DB_NAME', 'enh');
define('DB_USER', 'root');
define('DB_PASS', '');

$pdo = null;
try {
    $pdo = new PDO("mysql:host=".DB_HOST.";dbname=".DB_NAME, DB_USER, DB_PASS);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Database connection failed: ' . $e->getMessage()]);
    exit();
}

$method = $_SERVER['REQUEST_METHOD'];
$uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$uri = str_replace('/api/', '', $uri);
$parts = explode('/', $uri);

function getAuthToken() {
    $headers = getallheaders();
    if (isset($headers['Authorization'])) {
        $token = str_replace('Bearer ', '', $headers['Authorization']);
        return $token;
    }
    return null;
}

function getCurrentUser($pdo) {
    $token = getAuthToken();
    if (!$token) return null;
    
    $stmt = $pdo->prepare("SELECT * FROM users WHERE remember_token = ? LIMIT 1");
    $stmt->execute([$token]);
    return $stmt->fetch(PDO::FETCH_ASSOC);
}

function jsonResponse($data, $code = 200) {
    http_response_code($code);
    echo json_encode($data);
    exit();
}

// Auth Routes
if ($parts[0] === 'auth' && isset($parts[1])) {
    
    // Register
    if ($parts[1] === 'register' && $method === 'POST') {
        $input = json_decode(file_get_contents('php://input'), true);
        
        if (empty($input['name']) || empty($input['email']) || empty($input['password'])) {
            jsonResponse(['success' => false, 'message' => 'Name, email and password required'], 400);
        }
        
        $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
        $stmt->execute([$input['email']]);
        if ($stmt->fetch()) {
            jsonResponse(['success' => false, 'message' => 'Email already registered'], 400);
        }
        
        $token = bin2hex(random_bytes(32));
        $stmt = $pdo->prepare("INSERT INTO users (name, email, password, role, field, skills, bio, remember_token, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())");
        $stmt->execute([
            $input['name'],
            $input['email'],
            password_hash($input['password'], PASSWORD_DEFAULT),
            $input['role'] ?? 'student',
            $input['field'] ?? null,
            json_encode($input['skills'] ?? []),
            $input['bio'] ?? '',
            $token
        ]);
        
        $userId = $pdo->lastInsertId();
        
        jsonResponse([
            'success' => true,
            'message' => 'User registered successfully',
            'data' => [
                'user' => [
                    'id' => $userId,
                    'name' => $input['name'],
                    'email' => $input['email'],
                    'role' => $input['role'] ?? 'student',
                    'field' => $input['field']
                ],
                'access_token' => $token,
                'token_type' => 'bearer'
            ]
        ], 201);
    }
    
    // Login
    if ($parts[1] === 'login' && $method === 'POST') {
        $input = json_decode(file_get_contents('php://input'), true);
        
        if (empty($input['email']) || empty($input['password'])) {
            jsonResponse(['success' => false, 'message' => 'Email and password required'], 400);
        }
        
        $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ? LIMIT 1");
        $stmt->execute([$input['email']]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$user || !password_verify($input['password'], $user['password'])) {
            jsonResponse(['success' => false, 'message' => 'Invalid credentials'], 401);
        }
        
        $token = bin2hex(random_bytes(32));
        $stmt = $pdo->prepare("UPDATE users SET remember_token = ? WHERE id = ?");
        $stmt->execute([$token, $user['id']]);
        
        unset($user['password']);
        unset($user['remember_token']);
        $user['skills'] = json_decode($user['skills'] ?? '[]');
        
        jsonResponse([
            'success' => true,
            'message' => 'Login successful',
            'data' => [
                'user' => $user,
                'access_token' => $token,
                'token_type' => 'bearer'
            ]
        ]);
    }
    
    // Logout
    if ($parts[1] === 'logout' && $method === 'POST') {
        $user = getCurrentUser($pdo);
        if ($user) {
            $stmt = $pdo->prepare("UPDATE users SET remember_token = NULL WHERE id = ?");
            $stmt->execute([$user['id']]);
        }
        jsonResponse(['success' => true, 'message' => 'Logged out successfully']);
    }
    
    // Get Current User
    if ($parts[1] === 'me' && $method === 'GET') {
        $user = getCurrentUser($pdo);
        if (!$user) {
            jsonResponse(['success' => false, 'message' => 'Unauthorized'], 401);
        }
        unset($user['password']);
        unset($user['remember_token']);
        $user['skills'] = json_decode($user['skills'] ?? '[]');
        jsonResponse(['success' => true, 'data' => $user]);
    }
    
    // Update Profile
    if ($parts[1] === 'profile' && $method === 'PUT') {
        $user = getCurrentUser($pdo);
        if (!$user) {
            jsonResponse(['success' => false, 'message' => 'Unauthorized'], 401);
        }
        
        $input = json_decode(file_get_contents('php://input'), true);
        
        $updates = [];
        $params = [];
        
        if (isset($input['name'])) { $updates[] = 'name = ?'; $params[] = $input['name']; }
        if (isset($input['bio'])) { $updates[] = 'bio = ?'; $params[] = $input['bio']; }
        if (isset($input['phone'])) { $updates[] = 'phone = ?'; $params[] = $input['phone']; }
        if (isset($input['location'])) { $updates[] = 'location = ?'; $params[] = $input['location']; }
        if (isset($input['field'])) { $updates[] = 'field = ?'; $params[] = $input['field']; }
        if (isset($input['skills'])) { $updates[] = 'skills = ?'; $params[] = json_encode($input['skills']); }
        if (isset($input['avatar'])) { $updates[] = 'avatar = ?'; $params[] = $input['avatar']; }
        if (isset($input['password'])) { 
            $updates[] = 'password = ?'; 
            $params[] = password_hash($input['password'], PASSWORD_DEFAULT); 
        }
        
        if (!empty($updates)) {
            $params[] = $user['id'];
            $sql = "UPDATE users SET " . implode(', ', $updates) . ", updated_at = NOW() WHERE id = ?";
            $stmt = $pdo->prepare($sql);
            $stmt->execute($params);
        }
        
        $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
        $stmt->execute([$user['id']]);
        $updatedUser = $stmt->fetch(PDO::FETCH_ASSOC);
        
        unset($updatedUser['password']);
        unset($updatedUser['remember_token']);
        $updatedUser['skills'] = json_decode($updatedUser['skills'] ?? '[]');
        
        jsonResponse(['success' => true, 'message' => 'Profile updated successfully', 'data' => $updatedUser]);
    }
}

// Courses Routes
if ($parts[0] === 'courses') {
    // Get all courses
    if ($method === 'GET' && !isset($parts[1])) {
        $stmt = $pdo->query("SELECT * FROM courses WHERE is_published = 1 ORDER BY id DESC");
        $courses = $stmt->fetchAll(PDO::FETCH_ASSOC);
        jsonResponse(['success' => true, 'data' => $courses]);
    }
    
    // Get single course
    if ($method === 'GET' && isset($parts[1]) && is_numeric($parts[1])) {
        $stmt = $pdo->prepare("SELECT * FROM courses WHERE id = ? AND is_published = 1");
        $stmt->execute([$parts[1]]);
        $course = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$course) {
            jsonResponse(['success' => false, 'message' => 'Course not found'], 404);
        }
        
        $stmt = $pdo->prepare("SELECT * FROM lessons WHERE course_id = ? ORDER BY `order`");
        $stmt->execute([$parts[1]]);
        $course['lessons'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        jsonResponse(['success' => true, 'data' => $course]);
    }
    
    // Enroll in course
    if ($method === 'POST' && isset($parts[1]) && $parts[1] === 'enroll' && isset($parts[2])) {
        $user = getCurrentUser($pdo);
        if (!$user) {
            jsonResponse(['success' => false, 'message' => 'Unauthorized'], 401);
        }
        
        $courseId = $parts[2];
        
        $stmt = $pdo->prepare("SELECT id FROM enrollments WHERE user_id = ? AND course_id = ?");
        $stmt->execute([$user['id'], $courseId]);
        if ($stmt->fetch()) {
            jsonResponse(['success' => false, 'message' => 'Already enrolled'], 400);
        }
        
        $stmt = $pdo->prepare("INSERT INTO enrollments (user_id, course_id, progress, enrolled_at, created_at, updated_at) VALUES (?, ?, 0, NOW(), NOW(), NOW())");
        $stmt->execute([$user['id'], $courseId]);
        
        $pdo->exec("UPDATE courses SET students = students + 1 WHERE id = $courseId");
        
        jsonResponse(['success' => true, 'message' => 'Enrolled successfully']);
    }
    
    // Get enrolled courses
    if ($method === 'GET' && isset($parts[1]) && $parts[1] === 'enrolled') {
        $user = getCurrentUser($pdo);
        if (!$user) {
            jsonResponse(['success' => false, 'message' => 'Unauthorized'], 401);
        }
        
        $stmt = $pdo->prepare("
            SELECT c.*, e.progress, e.enrolled_at 
            FROM courses c 
            JOIN enrollments e ON c.id = e.course_id 
            WHERE e.user_id = ? 
            ORDER BY e.enrolled_at DESC
        ");
        $stmt->execute([$user['id']]);
        $courses = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        jsonResponse(['success' => true, 'data' => $courses]);
    }
}

// Jobs Routes
if ($parts[0] === 'jobs') {
    if ($method === 'GET' && !isset($parts[1])) {
        $stmt = $pdo->query("SELECT * FROM jobs WHERE is_active = 1 ORDER BY id DESC");
        $jobs = $stmt->fetchAll(PDO::FETCH_ASSOC);
        jsonResponse(['success' => true, 'data' => $jobs]);
    }
    
    if ($method === 'GET' && isset($parts[1]) && is_numeric($parts[1])) {
        $stmt = $pdo->prepare("SELECT * FROM jobs WHERE id = ? AND is_active = 1");
        $stmt->execute([$parts[1]]);
        $job = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$job) {
            jsonResponse(['success' => false, 'message' => 'Job not found'], 404);
        }
        jsonResponse(['success' => true, 'data' => $job]);
    }
    
    // Apply for job
    if ($method === 'POST' && isset($parts[1]) && $parts[1] === 'apply' && isset($parts[2])) {
        $user = getCurrentUser($pdo);
        if (!$user) {
            jsonResponse(['success' => false, 'message' => 'Unauthorized'], 401);
        }
        
        $jobId = $parts[2];
        $input = json_decode(file_get_contents('php://input'), true);
        
        $stmt = $pdo->prepare("SELECT id FROM applications WHERE user_id = ? AND job_id = ?");
        $stmt->execute([$user['id'], $jobId]);
        if ($stmt->fetch()) {
            jsonResponse(['success' => false, 'message' => 'Already applied'], 400);
        }
        
        $stmt = $pdo->prepare("INSERT INTO applications (user_id, job_id, cover_letter, status, applied_at, created_at, updated_at) VALUES (?, ?, ?, 'pending', NOW(), NOW(), NOW())");
        $stmt->execute([$user['id'], $jobId, $input['cover_letter'] ?? '']);
        
        jsonResponse(['success' => true, 'message' => 'Applied successfully']);
    }
}

// Questions Routes
if ($parts[0] === 'questions') {
    if ($method === 'GET' && !isset($parts[1])) {
        $stmt = $pdo->query("
            SELECT q.*, u.name as user_name, u.avatar as user_avatar,
            (SELECT COUNT(*) FROM answers WHERE question_id = q.id) as answers_count
            FROM questions q 
            JOIN users u ON q.user_id = u.id 
            ORDER BY q.id DESC
        ");
        $questions = $stmt->fetchAll(PDO::FETCH_ASSOC);
        jsonResponse(['success' => true, 'data' => $questions]);
    }
    
    if ($method === 'GET' && isset($parts[1]) && is_numeric($parts[1])) {
        $stmt = $pdo->prepare("SELECT q.*, u.name as user_name FROM questions q JOIN users u ON q.user_id = u.id WHERE q.id = ?");
        $stmt->execute([$parts[1]]);
        $question = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$question) {
            jsonResponse(['success' => false, 'message' => 'Question not found'], 404);
        }
        
        $pdo->exec("UPDATE questions SET views = views + 1 WHERE id = " . $parts[1]);
        
        $stmt = $pdo->prepare("SELECT a.*, u.name as user_name, u.avatar as user_avatar FROM answers a JOIN users u ON a.user_id = u.id WHERE a.question_id = ? ORDER BY a.is_accepted DESC, a.votes DESC");
        $stmt->execute([$parts[1]]);
        $question['answers'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        jsonResponse(['success' => true, 'data' => $question]);
    }
    
    // Post question
    if ($method === 'POST' && $parts[0] === 'questions') {
        $user = getCurrentUser($pdo);
        if (!$user) {
            jsonResponse(['success' => false, 'message' => 'Unauthorized'], 401);
        }
        
        $input = json_decode(file_get_contents('php://input'), true);
        
        if (empty($input['title']) || empty($input['body'])) {
            jsonResponse(['success' => false, 'message' => 'Title and body required'], 400);
        }
        
        $stmt = $pdo->prepare("INSERT INTO questions (user_id, title, body, field, votes, views, is_solved, created_at, updated_at) VALUES (?, ?, ?, ?, 0, 0, 0, NOW(), NOW())");
        $stmt->execute([$user['id'], $input['title'], $input['body'], $input['field'] ?? 'general']);
        
        jsonResponse(['success' => true, 'message' => 'Question posted successfully', 'data' => ['id' => $pdo->lastInsertId()]], 201);
    }
    
    // Post answer
    if ($method === 'POST' && isset($parts[1]) && $parts[1] === 'answers') {
        $user = getCurrentUser($pdo);
        if (!$user) {
            jsonResponse(['success' => false, 'message' => 'Unauthorized'], 401);
        }
        
        $input = json_decode(file_get_contents('php://input'), true);
        
        if (empty($input['body'])) {
            jsonResponse(['success' => false, 'message' => 'Answer body required'], 400);
        }
        
        $stmt = $pdo->prepare("INSERT INTO answers (question_id, user_id, body, votes, is_accepted, created_at, updated_at) VALUES (?, ?, ?, 0, 0, NOW(), NOW())");
        $stmt->execute([$parts[2] ?? $input['question_id'], $user['id'], $input['body']]);
        
        jsonResponse(['success' => true, 'message' => 'Answer posted successfully', 'data' => ['id' => $pdo->lastInsertId()]], 201);
    }
}

// Stats endpoint
if ($parts[0] === 'stats' && $method === 'GET') {
    $courses = $pdo->query("SELECT COUNT(*) as count FROM courses WHERE is_published = 1")->fetch(PDO::FETCH_ASSOC);
    $users = $pdo->query("SELECT COUNT(*) as count FROM users")->fetch(PDO::FETCH_ASSOC);
    $questions = $pdo->query("SELECT COUNT(*) as count FROM questions")->fetch(PDO::FETCH_ASSOC);
    $jobs = $pdo->query("SELECT COUNT(*) as count FROM jobs WHERE is_active = 1")->fetch(PDO::FETCH_ASSOC);
    
    jsonResponse([
        'success' => true,
        'data' => [
            'courses' => $courses['count'] + 500,
            'students' => $users['count'] + 10000,
            'questions' => $questions['count'] + 1000,
            'jobs' => $jobs['count']
        ]
    ]);
}

// Default response
jsonResponse(['success' => false, 'message' => 'Endpoint not found'], 404);