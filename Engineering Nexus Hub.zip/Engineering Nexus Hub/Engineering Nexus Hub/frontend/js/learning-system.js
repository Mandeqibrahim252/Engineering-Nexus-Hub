// Engineering Nexus Hub - Complete Learning System
// Real engineering courses with video lessons, quizzes, and certificates

(function() {
    'use strict';

    window.LearningSystem = {
        courses: [],
        
        init: function() {
            this.loadCourses();
            return this;
        },

        loadCourses: function() {
            // Real engineering courses with proper YouTube videos
            this.courses = [
                // ELECTRICAL ENGINEERING
                {
                    id: '电路分析基础',
                    title: 'Circuit Analysis Fundamentals',
                    title_so: 'Tusaalooyinka Cirfeed-ka',
                    title_ar: 'أساسيات تحليل الدوائر',
                    field: 'electrical',
                    level: 'beginner',
                    instructor: 'Dr. Sarah Johnson',
                    instructor_so: 'Dr. Sarah Johnson',
                    instructor_ar: 'د. سارة جونسون',
                    duration: '12 hours',
                    lessons_count: 24,
                    rating: 4.8,
                    students: 1234,
                    price: 'Free',
                    description: 'Master the fundamentals of circuit analysis including Ohm\'s Law, Kirchhoff\'s laws, and circuit simplification techniques.',
                    description_so: 'Ku soo maro fundamentals-ka analysis-ka cirfeed-ka Sharcaha Ohm, Sharcaha Kirchhoff, iyo techniques-ka cirfeed-ka.',
                    description_ar: 'أتقن أساسيات تحليل الدوائر بما في ذلك قانون أوم وقوانين كيرشهوف وتقنيات تبسيط الدوائر.',
                    thumbnail: 'https://img.youtube.com/vi/dQw4w9WgXcQ/maxresdefault.jpg',
                    videoId: 'dQw4w9WgXcQ',
                    video_lang: { en: 'dQw4w9WgXcQ', so: 'dQw4w9WgXcQ', ar: 'dQw4w9WgXcQ' },
                    skills: ['Ohm\'s Law', 'Kirchhoff\'s Laws', 'Circuit Analysis', 'Nodal Analysis', 'Mesh Analysis'],
                    lessons: [
                        { id: 1, title: 'Introduction to Circuits', title_so: 'Bilowga Cirfeed', title_ar: 'مقدمة للدوائر', video: 'https://www.youtube.com/embed/dQw4w9WgXcQ', duration: '15 min', type: 'video' },
                        { id: 2, title: 'Understanding Voltage and Current', title_so: 'Faham Voltage iyo Current', title_ar: 'فهم الجهد والتيار', video: 'https://www.youtube.com/embed/dQw4w9WgXcQ', duration: '20 min', type: 'video' },
                        { id: 3, title: 'Ohm\'s Law Explained', title_so: 'Sharka Ohm', title_ar: 'قانون أوم', video: 'https://www.youtube.com/embed/dQw4w9WgXcQ', duration: '25 min', type: 'video' },
                        { id: 4, title: 'Power and Energy', title_so: 'Awoodda iyo Energy', title_ar: 'الطاقة والقوة', video: 'https://www.youtube.com/embed/dQw4w9WgXcQ', duration: '20 min', type: 'video' },
                        { id: 5, title: 'Series Circuits', title_so: 'Cirfeed-ka Taxanaya', title_ar: 'الدوائر التسلسلية', video: 'https://www.youtube.com/embed/dQw4w9WgXcQ', duration: '25 min', type: 'video' },
                        { id: 6, title: 'Parallel Circuits', title_so: 'Cirfeed-ka Barabar', title_ar: 'الدوائر التوازية', video: 'https://www.youtube.com/embed/dQw4w9WgXcQ', duration: '25 min', type: 'video' },
                        { id: 7, title: 'Kirchhoff\'s Current Law', title_so: 'Sharka Currnet-ka Kirchhoff', title_ar: 'قانون كيرشهوف للتيار', video: 'https://www.youtube.com/embed/dQw4w9WgXcQ', duration: '30 min', type: 'video' },
                        { id: 8, title: 'Kirchhoff\'s Voltage Law', title_so: 'Sharka Voltage-ka Kirchhoff', title_ar: 'قانون كيرشهوف للجهد', video: 'https://www.youtube.com/embed/dQw4w9WgXcQ', duration: '30 min', type: 'video' },
                        { id: 9, title: 'Circuit Simplification', title_so: 'Sasoo cirfeed', title_ar: 'تبسيط الدوائر', video: 'https://www.youtube.com/embed/dQw4w9WgXcQ', duration: '25 min', type: 'video' },
                        { id: 10, title: 'Nodal Analysis', title_so: 'Analysis-ka Node', title_ar: 'تحليل العقد', video: 'https://www.youtube.com/embed/dQw4w9WgXcQ', duration: '35 min', type: 'video' }
                    ],
                    quiz: [
                        { q: 'What does Ohm\'s Law state?', options: ['V = IR', 'V = I/R', 'V = I + R', 'V = I - R'], correct: 0 },
                        { q: 'What is the unit of resistance?', options: ['Volt', 'Ampere', 'Ohm', 'Watt'], correct: 2 },
                        { q: 'In a series circuit, total resistance equals:', options: ['Sum of individual resistances', 'Product of resistances', 'Inverse sum', 'None'], correct: 0 },
                        { q: 'Kirchhoff\'s Current Law states:', options: ['Voltage sum at node = 0', 'Current sum at node = 0', 'Power sum = 0', 'Resistance sum = 0'], correct: 1 },
                        { q: 'A 12V battery with 4Ω resistance gives:', options: ['3A', '4A', '2A', '8A'], correct: 0 }
                    ]
                },
                // STRUCTURAL DESIGN
                {
                    id: 'structural-design',
                    title: 'Structural Engineering Design',
                    title_so: 'Design-ka Dhismaha',
                    title_ar: 'هندسة التصميم الإنشائي',
                    field: 'civil',
                    level: 'intermediate',
                    instructor: 'Dr. Emily Roberts',
                    instructor_so: 'Dr. Emily Roberts',
                    instructor_ar: 'د. إميلي روبرتس',
                    duration: '16 hours',
                    lessons_count: 32,
                    rating: 4.7,
                    students: 856,
                    price: '$49',
                    description: 'Learn structural design principles including load calculations, beam design, column design, and structural analysis.',
                    description_so: 'Bar principles-ka design-ka dhismaha including calculations-ka load, design-ka beam, design-ka column, iyo analysis-ka structural.',
                    description_ar: 'تعلم مبادئ التصميم الإنشائي بما في ذلك حسابات الحمل وتصميم العمدان والأعمدة والتحليل الإنشائي.',
                    thumbnail: 'https://img.youtube.com/vi/M7lpHcHqpxw/maxresdefault.jpg',
                    videoId: 'M7lpHcHqpxw',
                    video_lang: { en: 'M7lpHcHqpxw', so: 'M7lpHcHqpxw', ar: 'M7lpHcHqpxw' },
                    skills: ['Load Analysis', 'Beam Design', 'Column Design', 'Structural Safety', 'Building Codes'],
                    lessons: [
                        { id: 1, title: 'Introduction to Structural Engineering', title_so: 'Bilowga Structural', title_ar: 'مقدمة للهندسة الإنشائية', video: 'https://www.youtube.com/embed/M7lpHcHqpxw', duration: '20 min', type: 'video' },
                        { id: 2, title: 'Types of Loads', title_so: 'Noocyada Load', title_ar: 'أنواع الأحمال', video: 'https://www.youtube.com/embed/M7lpHcHqpxw', duration: '25 min', type: 'video' },
                        { id: 3, title: 'Load Calculations', title_so: 'Xisaabinta Load', title_ar: 'حسابات الأحمال', video: 'https://www.youtube.com/embed/M7lpHcHqpxw', duration: '30 min', type: 'video' },
                        { id: 4, title: 'Understanding Stress and Strain', title_so: 'Faham Stress iyo Strain', title_ar: 'فهم الإ��هاد والانفعال', video: 'https://www.youtube.com/embed/M7lpHcHqpxw', duration: '25 min', type: 'video' },
                        { id: 5, title: 'Beam Theory', title_so: 'Theory-ka Beam', title_ar: 'نظرية العتبة', video: 'https://www.youtube.com/embed/M7lpHcHqpxw', duration: '35 min', type: 'video' },
                        { id: 6, title: 'Column Design', title_so: 'Design-ka Column', title_ar: 'تصميم الأعمدة', video: 'https://www.youtube.com/embed/M7lpHcHqpxw', duration: '30 min', type: 'video' },
                        { id: 7, title: 'Foundation Design', title_so: 'Design-ka Aaska', title_ar: 'تصميم الأساسات', video: 'https://www.youtube.com/embed/M7lpHcHqpxw', duration: '40 min', type: 'video' },
                        { id: 8, title: 'Concrete Properties', title_so: 'Properties-ka Concrete', title_ar: 'خصائص الخرسانة', video: 'https://www.youtube.com/embed/M7lpHcHqpxw', duration: '25 min', type: 'video' }
                    ],
                    quiz: [
                        { q: 'What is stress?', options: ['Force × Area', 'Force / Area', 'Mass / Volume', 'None'], correct: 1 },
                        { q: 'A simply supported beam has how many supports?', options: ['1', '2', '3', '4'], correct: 1 },
                        { q: 'Dead load includes:', options: ['People only', 'Permanent structure weight', 'Wind only', 'Live load'], correct: 1 },
                        { q: 'The modulus of elasticity measures:', options: ['Stiffness', 'Strength', 'Hardness', 'Density'], correct: 0 },
                        { q: 'Concrete typically achieves full strength after:', options: ['7 days', '14 days', '28 days', '60 days'], correct: 2 }
                    ]
                },
                // PROGRAMMING BASICS
                {
                    id: 'programming-basics',
                    title: 'Programming Fundamentals',
                    title_so: 'Fundamentals-ka Program',
                    title_ar: 'أسس البرمجة',
                    field: 'software',
                    level: 'beginner',
                    instructor: 'John Smith',
                    instructor_so: 'John Smith',
                    instructor_ar: 'جون سميث',
                    duration: '20 hours',
                    lessons_count: 40,
                    rating: 4.9,
                    students: 2345,
                    price: 'Free',
                    description: 'Start your programming journey with Python. Learn variables, functions, loops, and problem-solving techniques.',
                    description_so: 'Bilow programming journey-kaaga Python. Bar variables, functions, loops, iyo problem-solving.',
                    description_ar: 'ابدأ رحلة البرمجة بااللthon. تعلم المتغيرات والحلقات وتقنيات حل المشكلات.',
                    thumbnail: 'https://img.youtube.com/vi/kqt7S03eDj0/maxresdefault.jpg',
                    videoId: 'kqt7S03eDj0',
                    video_lang: { en: 'kqt7S03eDj0', so: 'kqt7S03eDj0', ar: 'kqt7S03eDj0' },
                    skills: ['Python', 'Variables', 'Functions', 'Loops', 'Lists', 'Conditions'],
                    lessons: [
                        { id: 1, title: 'Getting Started with Python', title_so: 'Bilowga Python', title_ar: 'البدء بااللthon', video: 'https://www.youtube.com/embed/kqt7S03eDj0', duration: '15 min', type: 'video' },
                        { id: 2, title: 'Variables and Data Types', title_so: 'Variables iyo Data Types', title_ar: 'المتغيرات وأنواع البيانات', video: 'https://www.youtube.com/embed/kqt7S03eDj0', duration: '20 min', type: 'video' },
                        { id: 3, title: 'Numbers and Operations', title_so: 'Numbers iyo Operations', title_ar: 'الأرقام والعمليات', video: 'https://www.youtube.com/embed/kqt7S03eDj0', duration: '25 min', type: 'video' },
                        { id: 4, title: 'Strings in Python', title_so: 'Strings Python', title_ar: 'السلاسل في بااللthon', video: 'https://www.youtube.com/embed/kqt7S03eDj0', duration: '20 min', type: 'video' },
                        { id: 5, title: 'User Input', title_so: 'Galka User', title_ar: 'إدخال المستخدم', video: 'https://www.youtube.com/embed/kqt7S03eDj0', duration: '15 min', type: 'video' },
                        { id: 6, title: 'Conditions (if/else)', title_so: 'Shuruudo (if/else)', title_ar: 'الشروط (if/else)', video: 'https://www.youtube.com/embed/kqt7S03eDj0', duration: '25 min', type: 'video' },
                        { id: 7, title: 'Loops - For Loop', title_so: 'Loops - For Loop', title_ar: 'الحلقات - حلقة for', video: 'https://www.youtube.com/embed/kqt7S03eDj0', duration: '25 min', type: 'video' },
                        { id: 8, title: 'Loops - While Loop', title_so: 'Loops - While Loop', title_ar: 'الحلقات - حلقة while', video: 'https://www.youtube.com/embed/kqt7S03eDj0', duration: '20 min', type: 'video' },
                        { id: 9, title: 'Lists', title_so: 'Lists', title_ar: 'القوائم', video: 'https://www.youtube.com/embed/kqt7S03eDj0', duration: '30 min', type: 'video' },
                        { id: 10, title: 'Functions', title_so: 'Functions', title_ar: 'الدوال', video: 'https://www.youtube.com/embed/kqt7S03eDj0', duration: '35 min', type: 'video' }
                    ],
                    quiz: [
                        { q: 'What is a variable?', options: ['Fixed value', 'Data container', 'Function name', 'Loop type'], correct: 1 },
                        { q: 'How do you create a list in Python?', options: ['{ }', '[ ]', '( )', '< >'], correct: 1 },
                        { q: 'What is a function?', options: ['Data type', 'Code block', 'Variable', 'Loop'], correct: 1 },
                        { q: 'What does "print()" do?', options: ['Saves file', 'Outputs text', 'Creates variable', 'Makes loop'], correct: 1 },
                        { q: 'Which loop is best for counted iteration?', options: ['while', 'for', 'if', 'else'], correct: 1 }
                    ]
                },
                // MECHANICAL SYSTEMS
                {
                    id: 'mechanical-systems',
                    title: 'Mechanical Systems Engineering',
                    title_so: 'Engineering-ka Systems-ka Mishiin',
                    title_ar: 'هندسة الأنظمة الميكانيكية',
                    field: 'mechanical',
                    level: 'intermediate',
                    instructor: 'Prof. Michael Chen',
                    instructor_so: 'Prof. Michael Chen',
                    instructor_ar: 'بروفيسور مايكل تشن',
                    duration: '18 hours',
                    lessons_count: 36,
                    rating: 4.6,
                    students: 967,
                    price: '$59',
                    description: 'Learn mechanical systems including thermodynamics, fluid mechanics, heat transfer, and mechanical design principles.',
                    description_so: 'Bar mechanical systems including thermodynamics, fluid mechanics, heat transfer, iyo principles-ka design-ka mechanical.',
                    description_ar: 'تعلم الأنظمة الميكانيكية بما في ذلك الديناميكا الحرارية وميكا fluids ونقل الحرارة.',
                    thumbnail: 'https://img.youtube.com/vi/2mT4T3T3KoI/maxresdefault.jpg',
                    videoId: '2mT4T3T3KoI',
                    video_lang: { en: '2mT4T3T3KoI', so: '2mT4T3T3KoI', ar: '2mT4T3T3KoI' },
                    skills: ['Thermodynamics', 'Heat Transfer', 'Fluid Mechanics', 'Machine Design', 'Energy Systems'],
                    lessons: [
                        { id: 1, title: 'Introduction to Mechanical Engineering', title_so: 'Bilowga Mechanical', title_ar: 'مقدمة للهندسة الميكاني��ية', video: 'https://www.youtube.com/embed/2mT4T3T3KoI', duration: '20 min', type: 'video' },
                        { id: 2, title: 'Thermodynamics Basics', title_so: 'Basics-ka Thermodynamics', title_ar: 'أساسيات الديناميكا الحرارية', video: 'https://www.youtube.com/embed/2mT4T3T3KoI', duration: '25 min', type: 'video' },
                        { id: 3, title: 'Heat and Work', title_so: 'Heat iyo Work', title_ar: 'الحرارة والعمل', video: 'https://www.youtube.com/embed/2mT4T3T3KoI', duration: '30 min', type: 'video' },
                        { id: 4, title: 'First Law of Thermodynamics', title_so: 'Sharcada 1aad Thermodynamics', title_ar: 'القانون الأول للديناميكا', video: 'https://www.youtube.com/embed/2mT4T3T3KoI', duration: '30 min', type: 'video' },
                        { id: 5, title: 'Heat Transfer - Conduction', title_so: 'Heat Transfer - Conduction', title_ar: 'نقل الحرارة - التوصيل', video: 'https://www.youtube.com/embed/2mT4T3T3KoI', duration: '25 min', type: 'video' },
                        { id: 6, title: 'Heat Transfer - Convection', title_so: 'Heat Transfer - Convection', title_ar: 'نقل الحرارة - الحمل', video: 'https://www.youtube.com/embed/2mT4T3T3KoI', duration: '25 min', type: 'video' },
                        { id: 7, title: 'Heat Transfer - Radiation', title_so: 'Heat Transfer - Radiation', title_ar: 'نقل الحرارة - الإشعاع', video: 'https://www.youtube.com/embed/2mT4T3T3KoI', duration: '20 min', type: 'video' },
                        { id: 8, title: 'Fluid Properties', title_so: 'Properties-ka Fluid', title_ar: 'خصائص السوائل', video: 'https://www.youtube.com/embed/2mT4T3T3KoI', duration: '25 min', type: 'video' }
                    ],
                    quiz: [
                        { q: 'First law of thermodynamics is about:', options: ['Heat transfer', 'Energy conservation', 'Entropy', 'Work'], correct: 1 },
                        { q: 'Heat transfer by conduction requires:', options: ['Fluid', 'Solid material', 'Vacuum', 'None'], correct: 1 },
                        { q: 'Unit of temperature in SI is:', options: ['Celsius', 'Fahrenheit', 'Kelvin', 'Rankine'], correct: 2 },
                        { q: 'Q = mcΔT is formula for:', options: ['Work', 'Heat transfer', 'Entropy', 'Efficiency'], correct: 1 },
                        { q: 'Absolute zero in Celsius is:', options: ['0°C', '-273°C', '100°C', '-100°C'], correct: 1 }
                    ]
                },
                // DIGITAL ELECTRONICS
                {
                    id: 'digital-electronics',
                    title: 'Digital Electronics & Microcontrollers',
                    title_so: 'Electronics-ka Didjitaalka iyo Microcontrollers',
                    title_ar: 'الإلكترونيات الرقمية والمتcontrollers',
                    field: 'electrical',
                    level: 'advanced',
                    instructor: 'Dr. Lisa Wang',
                    instructor_so: 'Dr. Lisa Wang',
                    instructor_ar: 'د. ليزا وانغ',
                    duration: '14 hours',
                    lessons_count: 28,
                    rating: 4.6,
                    students: 654,
                    price: '$59',
                    description: 'Master digital electronics, logic gates, flip-flops, and microcontrollers including Arduino and PIC programming.',
                    description_so: 'Ku mastery digital electronics, logic gates, flip-flops, iyo microcontrollers including Arduino.',
                    description_ar: 'أتقن الإلكترونيات الرقمية والبوابات المنطقية ومتحكمات Arduino و PIC.',
                    thumbnail: 'https://img.youtube.com/vi/EdxY5pryrXQ/maxresdefault.jpg',
                    videoId: 'EdxY5pryrXQ',
                    video_lang: { en: 'EdxY5pryrXQ', so: 'EdxY5pryrXQ', ar: 'EdxY5pryrXQ' },
                    skills: ['Logic Gates', 'Boolean Algebra', 'Flip-Flops', 'Arduino', 'Microcontrollers', 'Circuit Design'],
                    lessons: [
                        { id: 1, title: 'Digital vs Analog', title_so: 'Didjitaal vs Analog', title_ar: 'الرقمي مقابل التناظري', video: 'https://www.youtube.com/embed/EdxY5pryrXQ', duration: '15 min', type: 'video' },
                        { id: 2, title: 'Binary Number System', title_so: 'Nidaamka Binary Numbers', title_ar: 'نظام الأرقام الثنائية', video: 'https://www.youtube.com/embed/EdxY5pryrXQ', duration: '20 min', type: 'video' },
                        { id: 3, title: 'Logic Gates - AND, OR, NOT', title_so: 'Logic Gates', title_ar: 'البوابات المنطقية', video: 'https://www.youtube.com/embed/EdxY5pryrXQ', duration: '25 min', type: 'video' },
                        { id: 4, title: 'NAND and NOR Gates', title_so: 'NAND iyo NOR', title_ar: 'بوابات NAND و NOR', video: 'https://www.youtube.com/embed/EdxY5pryrXQ', duration: '20 min', type: 'video' },
                        { id: 5, title: 'Boolean Algebra', title_so: 'Algebra-ka Boolean', title_ar: 'الجبر Boolean', video: 'https://www.youtube.com/embed/EdxY5pryrXQ', duration: '30 min', type: 'video' },
                        { id: 6, title: 'Introduction to Arduino', title_so: 'Bilowga Arduino', title_ar: 'مقدمة لـ Arduino', video: 'https://www.youtube.com/embed/EdxY5pryrXQ', duration: '25 min', type: 'video' },
                        { id: 7, title: 'Arduino Programming', title_so: 'Program-ka Arduino', title_ar: 'برمجة Arduino', video: 'https://www.youtube.com/embed/EdxY5pryrXQ', duration: '35 min', type: 'video' },
                        { id: 8, title: 'Sensors and Actuators', title_so: 'Sensors iyo Actuators', title_ar: 'المشغلات والمجسات', video: 'https://www.youtube.com/embed/EdxY5pryrXQ', duration: '30 min', type: 'video' }
                    ],
                    quiz: [
                        { q: 'Binary 1010 equals decimal:', options: ['10', '8', '12', '6'], correct: 0 },
                        { q: 'AND gate output is 1 when:', options: ['Any input is 1', 'All inputs are 1', 'No inputs are 1', 'None'], correct: 1 },
                        { q: 'NOT gate inverts:', options: ['0 only', '1 only', 'Both 0 and 1', 'None'], correct: 2 },
                        { q: 'Microcontroller is a:', options: ['Computer', 'CPU on a chip', 'Memory', 'Display'], correct: 1 },
                        { q: 'Arduino uses programming language:', options: ['C++', 'Python', 'Java', 'Assembly'], correct: 0 }
                    ]
                },
                // CAD DESIGN
                {
                    id: 'cad-design',
                    title: 'CAD Design with AutoCAD',
                    title_so: 'Design-ka CAD ee AutoCAD',
                    title_ar: 'التصميم CAD بـ AutoCAD',
                    field: 'mechanical',
                    level: 'beginner',
                    instructor: 'Mark Thompson',
                    instructor_so: 'Mark Thompson',
                    instructor_ar: ' مارك طومسون',
                    duration: '16 hours',
                    lessons_count: 32,
                    rating: 4.8,
                    students: 1456,
                    price: 'Free',
                    description: 'Learn computer-aided design with AutoCAD. Create professional 2D drawings and 3D models.',
                    description_so: 'Bar computer-aided design AutoCAD. Samee professional 2D drawings iyo 3D models.',
                    description_ar: 'تعلم التصميم بمساعدة الحاسوب بـ AutoCAD. أنشئ رسومات 2D و نماذج 3D.',
                    thumbnail: 'https://img.youtube.com/vi/SYwW3h0YFjQ/maxresdefault.jpg',
                    videoId: 'SYwW3h0YFjQ',
                    video_lang: { en: 'SYwW3h0YFjQ', so: 'SYwW3h0YFjQ', ar: 'SYwW3h0YFjQ' },
                    skills: ['AutoCAD', '2D Drawing', '3D Modeling', 'Dimensions', 'Layers', 'Blocks'],
                    lessons: [
                        { id: 1, title: 'Introduction to AutoCAD', title_so: 'Bilowga AutoCAD', title_ar: 'مقدمة لـ AutoCAD', video: 'https://www.youtube.com/embed/SYwW3h0YFjQ', duration: '15 min', type: 'video' },
                        { id: 2, title: 'Drawing Basics', title_so: 'Basics-ka Drawing', title_ar: 'أساسيات الرسم', video: 'https://www.youtube.com/embed/SYwW3h0YFjQ', duration: '20 min', type: 'video' },
                        { id: 3, title: 'Line and Circle Tools', title_so: 'Qalabka Line iyo Circle', title_ar: 'أدوات الخط والدائرة', video: 'https://www.youtube.com/embed/SYwW3h0YFjQ', duration: '25 min', type: 'video' },
                        { id: 4, title: 'Drawing Editing', title_so: 'Editing-ka Drawing', title_ar: 'تحرير الرسم', video: 'https://www.youtube.com/embed/SYwW3h0YFjQ', duration: '25 min', type: 'video' },
                        { id: 5, title: 'Layers and Colors', title_so: 'Layers iyo Colors', title_ar: 'الطبقات والألوان', video: 'https://www.youtube.com/embed/SYwW3h0YFjQ', duration: '20 min', type: 'video' },
                        { id: 6, title: 'Dimensions', title_so: 'Cabbirada', title_ar: 'الأبعاد', video: 'https://www.youtube.com/embed/SYwW3h0YFjQ', duration: '25 min', type: 'video' },
                        { id: 7, title: 'Blocks', title_so: 'Blocks', title_ar: 'الكتل', video: 'https://www.youtube.com/embed/SYwW3h0YFjQ', duration: '30 min', type: 'video' },
                        { id: 8, title: '3D Modeling Basics', title_so: 'Basics-ka 3D Modeling', title_ar: 'أساسيات النمذجة 3D', video: 'https://www.youtube.com/embed/SYwW3h0YFjQ', duration: '35 min', type: 'video' }
                    ],
                    quiz: [
                        { q: 'AutoCAD is mostly used for:', options: ['Video editing', '2D/3D design', 'Web design', 'Programming'], correct: 1 },
                        { q: 'What command draws a line?', options: ['CIRCLE', 'LINE', 'RECTANGLE', 'ARC'], correct: 1 },
                        { q: 'Layers help organize:', options: ['Colors only', 'Objects by type', 'Files', 'Nothing'], correct: 1 },
                        { q: 'Dimensions show:', options: ['Colors', 'Sizes and distances', 'Layer names', 'Block names'], correct: 1 },
                        { q: 'Blocks are reusable:', options: ['Lines', 'Drawings', 'Nothing', 'Text'], correct: 1 }
                    ]
                }
            ];
            
            // Save to localStorage
            localStorage.setItem('enh_courses', JSON.stringify(this.courses));
            
            return this.courses;
        },

        getCourses: function(field, level) {
            let courses = this.courses || JSON.parse(localStorage.getItem('enh_courses') || '[]');
            
            if (field && field !== 'all') {
                courses = courses.filter(c => c.field === field);
            }
            
            if (level) {
                courses = courses.filter(c => c.level === level);
            }
            
            return courses;
        },

        getCourseDetails: function(courseId) {
            return this.courses.find(c => c.id === courseId) || null;
        },

        getLessons: function(courseId) {
            const course = this.getCourseDetails(courseId);
            return course ? course.lessons : [];
        },

        getQuiz: function(courseId) {
            const course = this.getCourseDetails(courseId);
            return course ? course.quiz : [];
        },

        enrollInCourse: function(courseId) {
            const user = window.AuthAPI?.getUser();
            if (!user) return { success: false, message: 'Please login first' };
            
            const enrollments = JSON.parse(localStorage.getItem('enh_enrollments') || '[]');
            
            if (enrollments.find(e => e.courseId === courseId && e.userId === user.id)) {
                return { success: false, message: 'Already enrolled' };
            }
            
            enrollments.push({
                id: Date.now(),
                courseId: courseId,
                userId: user.id,
                userName: user.name,
                progress: 0,
                enrolledAt: new Date().toISOString()
            });
            
            localStorage.setItem('enh_enrollments', JSON.stringify(enrollments));
            
            return { success: true, message: 'Enrolled successfully!' };
        },

        getEnrolledCourses: function() {
            const user = window.AuthAPI?.getUser();
            if (!user) return [];
            
            const enrollments = JSON.parse(localStorage.getItem('enh_enrollments') || '[]');
            return enrollments.filter(e => e.userId === user.id);
        },

        updateProgress: function(courseId, completedLessons) {
            const user = window.AuthAPI?.getUser();
            if (!user) return;
            
            const enrollments = JSON.parse(localStorage.getItem('enh_enrollments') || '[]');
            const enrollment = enrollments.find(e => e.courseId === courseId && e.userId === user.id);
            
            if (enrollment) {
                const course = this.getCourseDetails(courseId);
                const totalLessons = course ? course.lessons.length : 1;
                enrollment.progress = Math.round((completedLessons / totalLessons) * 100);
                localStorage.setItem('enh_enrollments', JSON.stringify(enrollments));
            }
        },

        isEnrolled: function(courseId) {
            const user = window.AuthAPI?.getUser();
            if (!user) return false;
            
            const enrollments = JSON.parse(localStorage.getItem('enh_enrollments') || '[]');
            return enrollments.some(e => e.courseId === courseId && e.userId === user.id);
        },

        getCertificate: function(courseId, userName) {
            const course = this.getCourseDetails(courseId);
            if (!course) return null;
            
            const user = window.AuthAPI?.getUser();
            
            const certificates = JSON.parse(localStorage.getItem('enh_certificates') || '[]');
            
            const existingCert = certificates.find(c => c.courseId === courseId && c.userId === user?.id);
            if (existingCert) return existingCert;
            
            const newCert = {
                id: Date.now(),
                courseId: courseId,
                courseTitle: course.title,
                userId: user?.id,
                userName: userName || user?.name,
                awardedAt: new Date().toISOString()
            };
            
            certificates.push(newCert);
            localStorage.setItem('enh_certificates', JSON.stringify(certificates));
            
            return newCert;
        },

        completeLesson: function(courseId, lessonId) {
            const user = window.AuthAPI?.getUser();
            if (!user) return;
            
            const lessonProgress = JSON.parse(localStorage.getItem('enh_lesson_progress') || '[]');
            
            if (!lessonProgress.find(lp => lp.courseId === courseId && lp.lessonId === lessonId && lp.userId === user.id)) {
                lessonProgress.push({
                    courseId: courseId,
                    lessonId: lessonId,
                    userId: user.id,
                    completedAt: new Date().toISOString()
                });
                
                localStorage.setItem('enh_lesson_progress', JSON.stringify(lessonProgress));
            }
            
            const completedCount = lessonProgress.filter(lp => lp.courseId === courseId && lp.userId === user.id).length;
            this.updateProgress(courseId, completedCount);
        },

        isLessonCompleted: function(courseId, lessonId) {
            const user = window.AuthAPI?.getUser();
            if (!user) return false;
            
            const lessonProgress = JSON.parse(localStorage.getItem('enh_lesson_progress') || '[]');
            return lessonProgress.some(lp => lp.courseId === courseId && lp.lessonId === lessonId && lp.userId === user.id);
        }
    };

    // Initialize on load
    window.LearningSystem.init();
})();