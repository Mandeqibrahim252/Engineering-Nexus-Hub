// Engineering Nexus Hub - API Service
// Connect to PHP Backend

const API_BASE = 'http://localhost/enaa/backend/public/api';

const ApiService = {
    // Get auth token
    getToken: () => localStorage.getItem('enh_token'),
    
    // Set auth data
    setAuth: (token, user) => {
        localStorage.setItem('enh_token', token);
        localStorage.setItem('enh_user', JSON.stringify(user));
    },
    
    // Clear auth
    clearAuth: () => {
        localStorage.removeItem('enh_token');
        localStorage.removeItem('enh_user');
    },
    
    // Make API request
    async request(endpoint, options = {}) {
        const token = this.getToken();
        const headers = {
            'Content-Type': 'application/json',
            ...(token ? { 'Authorization': `Bearer ${token}` } : {}),
            ...options.headers
        };
        
        try {
            const response = await fetch(`${API_BASE}${endpoint}`, {
                ...options,
                headers
            });
            
            const data = await response.json();
            
            if (!response.ok) {
                throw new Error(data.message || 'Request failed');
            }
            
            return data;
        } catch (error) {
            console.error('API Error:', error);
            throw error;
        }
    },
    
    // Auth endpoints
    auth: {
        async register(userData) {
            const result = await this.request('/auth/register', {
                method: 'POST',
                body: JSON.stringify(userData)
            });
            if (result.data.access_token) {
                ApiService.setAuth(result.data.access_token, result.data.user);
            }
            return result;
        },
        
        async login(email, password) {
            const result = await this.request('/auth/login', {
                method: 'POST',
                body: JSON.stringify({ email, password })
            });
            if (result.data.access_token) {
                ApiService.setAuth(result.data.access_token, result.data.user);
            }
            return result;
        },
        
        async logout() {
            try {
                await this.request('/auth/logout', { method: 'POST' });
            } catch (e) {
                // Continue even if API fails
            }
            ApiService.clearAuth();
            window.location.href = 'pages/auth/login.html';
        },
        
        async me() {
            return await this.request('/auth/me');
        },
        
        async updateProfile(data) {
            return await this.request('/auth/profile', {
                method: 'PUT',
                body: JSON.stringify(data)
            });
        }
    },
    
    // Courses endpoints
    courses: {
        async getAll() {
            return await this.request('/courses');
        },
        
        async getById(id) {
            return await this.request(`/courses/${id}`);
        },
        
        async enroll(courseId) {
            return await this.request(`/courses/enroll/${courseId}`, {
                method: 'POST'
            });
        },
        
        async getEnrolled() {
            return await this.request('/courses/enrolled');
        }
    },
    
    // Jobs endpoints
    jobs: {
        async getAll() {
            return await this.request('/jobs');
        },
        
        async getById(id) {
            return await this.request(`/jobs/${id}`);
        },
        
        async apply(jobId, coverLetter = '') {
            return await this.request(`/jobs/apply/${jobId}`, {
                method: 'POST',
                body: JSON.stringify({ cover_letter: coverLetter })
            });
        }
    },
    
    // Questions endpoints
    questions: {
        async getAll() {
            return await this.request('/questions');
        },
        
        async getById(id) {
            return await this.request(`/questions/${id}`);
        },
        
        async create(data) {
            return await this.request('/questions', {
                method: 'POST',
                body: JSON.stringify(data)
            });
        },
        
        async answer(questionId, body) {
            return await this.request(`/questions/${questionId}/answers`, {
                method: 'POST',
                body: JSON.stringify({ question_id: questionId, body })
            });
        }
    },
    
    // Stats
    async getStats() {
        return await this.request('/stats');
    }
};

// Make available globally
window.ApiService = ApiService;