// Engineering Nexus Hub - Main JavaScript

// ============================================
// INITIALIZATION
// ============================================

document.addEventListener('DOMContentLoaded', () => {
    initApp();
});

function initApp() {
    loadTheme();
    initNavbar();
    initSidebar();
    initModals();
    initSearch();
    initNotifications();
    updateUserDisplay();
    initQuizSystem();
    loadDemoData();
}

// ============================================
// THEME SYSTEM
// ============================================

function loadTheme() {
    const theme = localStorage.getItem('enh_theme') || 'light';
    document.documentElement.setAttribute('data-theme', theme);
}

function toggleTheme() {
    const current = document.documentElement.getAttribute('data-theme');
    const next = current === 'dark' ? 'light' : 'dark';
    document.documentElement.setAttribute('data-theme', next);
    localStorage.setItem('enh_theme', next);
    showToast(next === 'dark' ? 'Dark mode enabled' : 'Light mode enabled', 'success');
}

window.toggleTheme = toggleTheme;

// ============================================
// NAVBAR & SIDEBAR
// ============================================

function initNavbar() {
    const navbar = document.querySelector('.navbar');
    if (!navbar) return;

    // User menu dropdown
    const userMenuBtn = document.getElementById('userMenuBtn');
    const dropdown = userMenuBtn?.closest('.dropdown');
    
    if (userMenuBtn && dropdown) {
        userMenuBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            dropdown.classList.toggle('active');
        });
    }

    // Close dropdowns on outside click
    document.addEventListener('click', () => {
        if (dropdown) dropdown.classList.remove('active');
    });

    // Mobile menu
    const mobileMenuBtn = document.querySelector('.mobile-menu-btn');
    const sidebar = document.querySelector('.sidebar');
    
    if (mobileMenuBtn && sidebar) {
        mobileMenuBtn.addEventListener('click', () => {
            sidebar.classList.toggle('active');
        });
    }
}

function initSidebar() {
    const sidebar = document.querySelector('.sidebar');
    if (!sidebar) return;

    const links = sidebar.querySelectorAll('.sidebar-link');
    const currentPage = window.location.pathname.split('/').pop() || 'dashboard.html';

    links.forEach(link => {
        const href = link.getAttribute('href');
        if (href && (href === currentPage || href === '../' + currentPage || href === currentPage.replace('.html', ''))) {
            link.classList.add('active');
        }
    });
}

// ============================================
// MODALS
// ============================================

function initModals() {
    const modals = document.querySelectorAll('.modal-overlay');
    
    modals.forEach(modal => {
        const closeBtn = modal.querySelector('.modal-close');
        
        if (closeBtn) {
            closeBtn.addEventListener('click', () => closeModal(modal.id));
        }

        modal.addEventListener('click', (e) => {
            if (e.target === modal) closeModal(modal.id);
        });
    });
}

function openModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.classList.add('active');
        document.body.style.overflow = 'hidden';
    }
}

function closeModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.classList.remove('active');
        document.body.style.overflow = '';
    }
    // Stop video when closing course modal
    if (modalId === 'courseDetailModal') {
        const videoFrame = document.getElementById('courseVideo');
        if (videoFrame) videoFrame.src = '';
    }
}

window.openModal = openModal;
window.closeModal = closeModal;

// ============================================
// GLOBAL SEARCH
// ============================================

function initSearch() {
    const searchInputs = document.querySelectorAll('.search-input');
    
    searchInputs.forEach(input => {
        input.addEventListener('input', (e) => {
            const query = e.target.value.toLowerCase();
            performSearch(query);
        });
    });
}

function performSearch(query) {
    if (!query) {
        document.querySelectorAll('[data-search-item]').forEach(item => {
            item.style.display = '';
        });
        return;
    }

    document.querySelectorAll('[data-search-item]').forEach(item => {
        const text = item.textContent.toLowerCase();
        item.style.display = text.includes(query) ? '' : 'none';
    });
}

function searchCourses(query) {
    const courses = document.querySelectorAll('[data-course-item]');
    courses.forEach(course => {
        const title = course.querySelector('.course-title')?.textContent.toLowerCase() || '';
        course.style.display = title.includes(query) ? '' : 'none';
    });
}

function searchJobs(query) {
    const jobs = document.querySelectorAll('[data-job-item]');
    jobs.forEach(job => {
        const title = job.querySelector('.job-title')?.textContent.toLowerCase() || '';
        const company = job.querySelector('.job-company')?.textContent.toLowerCase() || '';
        job.style.display = (title + company).includes(query) ? '' : 'none';
    });
}

function searchForum(query) {
    const questions = document.querySelectorAll('[data-question-item]');
    questions.forEach(q => {
        const title = q.querySelector('.question-title')?.textContent.toLowerCase() || '';
        q.style.display = title.includes(query) ? '' : 'none';
    });
}

// ============================================
// NOTIFICATIONS
// ============================================

function initNotifications() {
    updateNotificationBadge();
}

function addNotification(type, title, message, link = null) {
    let notifications = JSON.parse(localStorage.getItem('enh_notifications') || '[]');
    
    notifications.unshift({
        id: Date.now(),
        type: type,
        title: title,
        message: message,
        link: link,
        read: false,
        createdAt: new Date().toISOString()
    });
    
    localStorage.setItem('enh_notifications', JSON.stringify(notifications));
    updateNotificationBadge();
    showToast(message, type);
}

function updateNotificationBadge() {
    const notifications = JSON.parse(localStorage.getItem('enh_notifications') || '[]');
    const unread = notifications.filter(n => !n.read).length;
    
    document.querySelectorAll('.notification-badge').forEach(badge => {
        badge.textContent = unread;
        badge.style.display = unread > 0 ? 'flex' : 'none';
    });
}

function showNotifications() {
    const container = document.getElementById('notificationsList');
    if (!container) return;
    
    const notifications = JSON.parse(localStorage.getItem('enh_notifications') || '[]');
    
    if (notifications.length === 0) {
        container.innerHTML = '<p class="text-center text-muted p-3">No notifications</p>';
        return;
    }
    
    container.innerHTML = notifications.map(n => `
        <div class="notification-item ${n.read ? '' : 'unread'}" 
             style="padding:12px;border-bottom:1px solid var(--border-light);cursor:pointer;"
             onclick="markNotificationRead(${n.id})">
            <p class="font-medium">${n.title}</p>
            <p class="text-sm text-secondary">${n.message}</p>
            <p class="text-xs text-muted mt-1">${formatDate(n.createdAt)}</p>
        </div>
    `).join('');
}

function markNotificationRead(id) {
    let notifications = JSON.parse(localStorage.getItem('enh_notifications') || '[]');
    notifications = notifications.map(n => n.id === id ? { ...n, read: true } : n);
    localStorage.setItem('enh_notifications', JSON.stringify(notifications));
    updateNotificationBadge();
    showNotifications();
}

function markAllNotificationsRead() {
    let notifications = JSON.parse(localStorage.getItem('enh_notifications') || '[]');
    notifications = notifications.map(n => ({ ...n, read: true }));
    localStorage.setItem('enh_notifications', JSON.stringify(notifications));
    updateNotificationBadge();
    showNotifications();
    showToast('All notifications marked as read', 'success');
}

window.showNotifications = showNotifications;
window.markAllNotificationsRead = markAllNotificationsRead;

// ============================================
// USER DISPLAY
// ============================================

function updateUserDisplay() {
    const user = window.AuthAPI?.getUser();
    if (!user) return;

    // Update display name
    document.querySelectorAll('#userDisplayName, .user-display-name').forEach(el => {
        el.textContent = user.name;
    });

    // Update avatar
    document.querySelectorAll('#userAvatar, .user-avatar').forEach(el => {
        if (user.avatar) {
            el.innerHTML = `<img src="${user.avatar}" style="width:100%;height:100%;object-fit:cover;border-radius:50%;">`;
        } else {
            const initials = user.name.split(' ').map(n => n[0]).join('').substring(0, 2).toUpperCase();
            el.textContent = initials;
        }
    });
}

// ============================================
// QUIZ SYSTEM
// ============================================

function initQuizSystem() {
    window.quizAnswers = [];
}

function startQuiz(quizId) {
    openModal('quizModal');
    loadQuizQuestions(quizId);
}

function loadQuizQuestions(quizId) {
    const questions = getQuizData(quizId);
    displayQuizQuestion(quizId, 0, questions);
}

function displayQuizQuestion(quizId, questionIndex, questions) {
    const container = document.getElementById('quizQuestions');
    if (questionIndex >= questions.length) {
        showQuizResults(quizId, questions);
        return;
    }
    
    const q = questions[questionIndex];
    container.innerHTML = `
        <div class="quiz-question">
            <div class="mb-3">
                <span class="badge badge-primary">Question ${questionIndex + 1} of ${questions.length}</span>
            </div>
            <h4 class="mb-3">${q.question}</h4>
            <div class="flex flex-col gap-2">
                ${q.options.map((opt, i) => `
                    <label class="quiz-option" style="display:flex;align-items:center;gap:12px;padding:12px 16px;border:1px solid var(--border-light);border-radius:8px;cursor:pointer;transition:all 0.2s;">
                        <input type="radio" name="quizAnswer" value="${i}">
                        <span>${opt}</span>
                    </label>
                `).join('')}
            </div>
            <button class="btn btn-primary mt-3" onclick="submitQuizAnswer('${quizId}', ${questionIndex}, ${questions.length})">Next</button>
        </div>
    `;
}

function submitQuizAnswer(quizId, questionIndex, total) {
    const selected = document.querySelector('input[name="quizAnswer"]:checked');
    if (!selected) {
        showToast('Please select an answer', 'warning');
        return;
    }
    
    if (!window.quizAnswers) window.quizAnswers = [];
    window.quizAnswers.push(parseInt(selected.value));
    
    const questions = getQuizData(quizId);
    displayQuizQuestion(quizId, questionIndex + 1, questions);
}

function showQuizResults(quizId, questions) {
    let correct = 0;
    window.quizAnswers.forEach((ans, i) => {
        if (ans === questions[i].correct) correct++;
    });
    
    const score = Math.round((correct / questions.length) * 100);
    const passed = score >= 70;
    
    document.getElementById('quizQuestions').innerHTML = `
        <div class="text-center" style="padding:40px;">
            <div style="font-size:64px;margin-bottom:16px;">${passed ? '🎉' : '📚'}</div>
            <h3>${passed ? 'Congratulations!' : 'Keep Learning!'}</h3>
            <p class="text-2xl font-bold mt-2" style="color: ${passed ? 'var(--accent)' : 'var(--danger)'}">${score}%</p>
            <p class="text-secondary">You got ${correct} out of ${questions.length} correct</p>
            <button class="btn btn-primary mt-3" onclick="closeModal('quizModal'); window.quizAnswers = [];">Continue</button>
        </div>
    `;
    
    if (passed) {
        addNotification('success', 'Quiz Completed!', `You passed with ${score}%`);
    }
}

function getQuizData(quizId) {
    const quizzes = {
        'circuit-basics': [
            { question: 'What is Ohm\'s Law?', options: ['V = IR', 'V = I/R', 'V = I + R', 'V = I - R'], correct: 0 },
            { question: 'Unit of resistance?', options: ['Volt', 'Ampere', 'Ohm', 'Watt'], correct: 2 },
            { question: 'What happens if resistance increases?', options: ['Current increases', 'Current decreases', 'Voltage decreases', 'Power increases'], correct: 1 },
            { question: 'Power formula is?', options: ['P = V/I', 'P = VI', 'P = V/I', 'All of above'], correct: 3 }
        ],
        'thermo-1': [
            { question: 'First law of thermodynamics is about?', options: ['Heat transfer', 'Energy conservation', 'Entropy', 'Work'], correct: 1 },
            { question: 'Unit of temperature in SI?', options: ['Celsius', 'Fahrenheit', 'Kelvin', 'Rankine'], correct: 2 },
            { question: 'Q = mcΔT is formula for?', options: ['Work', 'Heat transfer', 'Entropy', 'Efficiency'], correct: 1 },
            { question: 'Absolute zero is?', options: ['0°C', '-273°C', '0K', '-100°C'], correct: 2 }
        ],
        'structural': [
            { question: 'What is stress?', options: ['Force/Area', 'Force x Area', 'Mass/Volume', 'None'], correct: 0 },
            { question: 'Young\'s modulus measures?', options: ['Stiffness', 'Hardness', 'Density', 'Strength'], correct: 0 },
            { question: 'Bending moment is measured in?', options: ['N', 'Nm', 'N/m', 'Nm²'], correct: 1 }
        ]
    };
    return quizzes[quizId] || quizzes['circuit-basics'];
}

window.startQuiz = startQuiz;

// ============================================
// ENGINEERING TOOLS
// ============================================

const EngineeringTools = {
    // Ohm's Law Calculator
    ohmsLaw: {
        calculate: function(voltage, current, resistance) {
            if (voltage && current) {
                return { resistance: (voltage / current).toFixed(2) + ' Ω' };
            }
            if (voltage && resistance) {
                return { current: (voltage / resistance).toFixed(2) + ' A' };
            }
            if (current && resistance) {
                return { voltage: (current * resistance).toFixed(2) + ' V' };
            }
            return null;
        }
    },

    // Unit Converter
    unitConverter: {
        lengths: { mm: 0.001, cm: 0.01, m: 1, km: 1000, in: 0.0254, ft: 0.3048, yd: 0.9144, mi: 1609.344 },
        masses: { mg: 0.000001, g: 0.001, kg: 1, ton: 1000, lb: 0.453592, oz: 0.0283495 },
        forces: { N: 1, kN: 1000, lbf: 4.44822, kgf: 9.80665 },
        pressures: { Pa: 1, kPa: 1000, MPa: 1000000, bar: 100000, psi: 6894.76 },
        
        convert: function(value, from, to, type) {
            const rates = this[type];
            if (!rates || !rates[from] || !rates[to]) return null;
            const base = value * rates[from];
            return (base / rates[to]).toFixed(4);
        }
    },

    // Load Calculator
    loadCalculator: {
        materials: {
            concrete: { density: 2400, name: 'Concrete' },
            steel: { density: 7850, name: 'Steel' },
            aluminum: { density: 2700, name: 'Aluminum' },
            wood: { density: 600, name: 'Wood' },
            glass: { density: 2500, name: 'Glass' }
        },
        
        calculate: function(volume, material) {
            const mat = this.materials[material];
            if (!mat) return null;
            const weight = volume * mat.density * 9.81 / 1000;
            return { weight: weight.toFixed(2) + ' kN', material: mat.name };
        }
    }
};

function calculateOhmsLaw() {
    const v = parseFloat(document.getElementById('voltage')?.value);
    const i = parseFloat(document.getElementById('current')?.value);
    const r = parseFloat(document.getElementById('resistance')?.value);
    
    const result = EngineeringTools.ohmsLaw.calculate(v, i, r);
    const output = document.getElementById('ohmsResult');
    
    if (result) {
        const key = Object.keys(result)[0];
        const value = Object.values(result)[0];
        output.innerHTML = `<strong>${key.toUpperCase()}:</strong> ${value}`;
        output.style.display = 'block';
    }
}

function convertUnit() {
    const value = parseFloat(document.getElementById('unitValue')?.value);
    const from = document.getElementById('unitFrom')?.value;
    const to = document.getElementById('unitTo')?.value;
    const type = document.getElementById('unitType')?.value;
    
    const result = EngineeringTools.unitConverter.convert(value, from, to, type);
    const output = document.getElementById('convertResult');
    
    if (result) {
        output.innerHTML = `<strong>Result:</strong> ${result} ${to}`;
        output.style.display = 'block';
    }
}

function calculateLoad() {
    const volume = parseFloat(document.getElementById('volume')?.value);
    const material = document.getElementById('material')?.value;
    
    const result = EngineeringTools.loadCalculator.calculate(volume, material);
    const output = document.getElementById('loadResult');
    
    if (result) {
        output.innerHTML = `<strong>Weight:</strong> ${result.weight} (${result.material})`;
        output.style.display = 'block';
    }
}

window.EngineeringTools = EngineeringTools;
window.calculateOhmsLaw = calculateOhmsLaw;
window.convertUnit = convertUnit;
window.calculateLoad = calculateLoad;

// ============================================
// COMMUNITY FORUM
// ============================================

function askQuestion() {
    if (!window.AuthAPI?.isLoggedIn()) {
        showToast('Please login to ask questions', 'warning');
        window.location.href = '../auth/login.html';
        return;
    }
    
    const title = document.getElementById('questionTitle')?.value;
    const body = document.getElementById('questionBody')?.value;
    const category = document.getElementById('questionCategory')?.value || 'general';
    
    if (!title || !body) {
        showToast('Please fill in title and question', 'warning');
        return;
    }
    
    const user = window.AuthAPI.getUser();
    let questions = JSON.parse(localStorage.getItem('enh_questions') || '[]');
    
    questions.unshift({
        id: Date.now(),
        title: title,
        body: body,
        category: category,
        tags: [],
        userId: user.id,
        userName: user.name,
        votes: 0,
        answers: 0,
        views: 0,
        createdAt: new Date().toISOString()
    });
    
    localStorage.setItem('enh_questions', JSON.stringify(questions));
    
    // Log activity
    if (window.ActivityTracker) {
        window.ActivityTracker.log('forum', `Asked: "${title}"`, 'Posted a new question');
    }
    
    showToast('Question posted!', 'success');
    closeModal('askModal');
    loadForumQuestions();
}

function loadForumQuestions() {
    const container = document.getElementById('questionsList');
    if (!container) return;
    
    let questions = JSON.parse(localStorage.getItem('enh_questions') || '[]');
    const answers = JSON.parse(localStorage.getItem('enh_answers') || '[]');
    
    // Sort by newest first, then by votes
    questions.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    
    if (questions.length === 0) {
        container.innerHTML = '<div class="text-center p-6"><p class="text-muted">No questions yet. Be the first to ask!</p></div>';
        return;
    }
    
    container.innerHTML = questions.map(q => {
        const questionAnswers = answers.filter(a => a.questionId === q.id);
        const answersCount = questionAnswers.length;
        const timeAgo = getTimeAgo(q.createdAt);
        
        return `
        <div class="card question-card mb-3" data-question-item>
            <div class="flex gap-3">
                <div class="text-center" style="min-width:60px;">
                    <div class="font-bold text-lg" style="color:var(--primary);">${q.votes || 0}</div>
                    <div class="text-xs text-muted">votes</div>
                </div>
                <div class="flex-1">
                    <a href="question.html?id=${q.id}" class="question-title" style="color:var(--text-primary); text-decoration:none; font-weight:600;">${q.title}</a>
                    <p class="text-secondary mt-1" style="font-size:0.9rem; line-height:1.4;">${(q.body || '').substring(0, 120)}${(q.body || '').length > 120 ? '...' : ''}</p>
                    <div class="flex items-center justify-between mt-2">
                        <div class="flex gap-2 flex-wrap">
                            <span class="tag" style="font-size:0.75rem; padding:2px 8px; background:var(--secondary-light); color:var(--primary);">${q.category || 'general'}</span>
                        </div>
                        <div class="question-author" style="font-size:0.8rem;">
                            <span class="badge" style="background:${answersCount > 0 ? 'var(--success)' : 'var(--text-muted)'}; color:white; font-size:0.7rem;">${answersCount} answers</span>
                            <span class="text-muted">•</span>
                            <span>${q.userName || 'Anonymous'}</span>
                            <span class="text-muted">•</span>
                            <span>${timeAgo}</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    `}).join('');
}

function getTimeAgo(dateString) {
    const date = new Date(dateString);
    const now = new Date();
    const diff = Math.floor((now - date) / 1000);
    
    if (diff < 60) return 'just now';
    if (diff < 3600) return Math.floor(diff / 60) + 'm ago';
    if (diff < 86400) return Math.floor(diff / 3600) + 'h ago';
    if (diff < 604800) return Math.floor(diff / 86400) + 'd ago';
    return Math.floor(diff / 604800) + 'w ago';
}

function voteQuestion(id, direction) {
    if (!window.AuthAPI?.isLoggedIn()) {
        showToast('Please login to vote', 'warning');
        return;
    }
    
    let questions = JSON.parse(localStorage.getItem('enh_questions') || '[]');
    const q = questions.find(q => q.id === id);
    if (q) {
        q.votes += direction;
        localStorage.setItem('enh_questions', JSON.stringify(questions));
        showToast(direction > 0 ? 'Upvoted!' : 'Downvoted!', 'success');
        loadForumQuestions();
    }
}

function postAnswer(questionId) {
    if (!window.AuthAPI?.isLoggedIn()) {
        showToast('Please login to answer', 'warning');
        return;
    }
    
    const body = document.getElementById('answerBody')?.value;
    if (!body) {
        showToast('Please write an answer', 'warning');
        return;
    }
    
    const user = window.AuthAPI.getUser();
    let answers = JSON.parse(localStorage.getItem('enh_answers') || '[]');
    
    answers.push({
        id: Date.now(),
        questionId: questionId,
        body: body,
        userId: user.id,
        userName: user.name,
        votes: 0,
        isAccepted: false,
        createdAt: new Date().toISOString()
    });
    
    let questions = JSON.parse(localStorage.getItem('enh_questions') || '[]');
    const qIndex = questions.findIndex(q => q.id === questionId);
    if (qIndex > -1) {
        questions[qIndex].answers = (questions[qIndex].answers || 0) + 1;
    }
    
    localStorage.setItem('enh_answers', JSON.stringify(answers));
    localStorage.setItem('enh_questions', JSON.stringify(questions));
    
    showToast('Answer posted!', 'success');
    loadQuestionDetail(questionId);
}

window.askQuestion = askQuestion;
window.voteQuestion = voteQuestion;
window.postAnswer = postAnswer;
window.loadForumQuestions = loadForumQuestions;

// ============================================
// COMMUNITY FORUM - ENHANCED
// ============================================

let currentTab = 'all';
let currentCategory = 'all';

function switchTab(tab) {
    currentTab = tab;
    document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
    event.target.classList.add('active');
    loadForumQuestions();
}

function filterCategory(category) {
    currentCategory = category;
    document.querySelectorAll('.category-item').forEach(c => c.classList.remove('active'));
    event.target.classList.add('active');
    loadForumQuestions();
}

function searchQuestions(query) {
    loadForumQuestions(query);
}

function loadForumQuestions(searchQuery = '') {
    const container = document.getElementById('questionsContainer') || document.getElementById('questionsList');
    if (!container) return;
    
    let questions = JSON.parse(localStorage.getItem('enh_questions') || '[]');
    const user = window.AuthAPI?.getUser();
    
    // Filter by tab
    if (currentTab === 'my' && user) {
        questions = questions.filter(q => q.userId === user.id);
    }
    
    // Filter by category
    if (currentCategory !== 'all') {
        questions = questions.filter(q => q.category === currentCategory);
    }
    
    // Search filter
    if (searchQuery) {
        const query = searchQuery.toLowerCase();
        questions = questions.filter(q => 
            q.title.toLowerCase().includes(query) || 
            q.body.toLowerCase().includes(query)
        );
    }
    
    // Sort by newest
    questions.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    
    if (questions.length === 0) {
        container.innerHTML = '<p class="text-center text-muted p-4">No questions found. Be the first to ask!</p>';
        return;
    }
    
    container.innerHTML = questions.map(q => `
        <div class="card" style="margin-bottom: 16px;">
            <div class="flex gap-3">
                <div class="question-votes">
                    <button class="vote-btn ${getUserVote(q.id) === 'up' ? 'upvoted' : ''}" onclick="voteQuestion(${q.id}, 1)">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 15l-6-6-6 6"/></svg>
                    </button>
                    <span class="vote-count">${q.votes || 0}</span>
                    <button class="vote-btn ${getUserVote(q.id) === 'down' ? 'downvoted' : ''}" onclick="voteQuestion(${q.id}, -1)">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M6 9l6 6 6-6"/></svg>
                    </button>
                </div>
                <div class="flex-1" style="cursor: pointer;" onclick="openQuestion(${q.id})">
                    <h4 class="question-title">${q.title}</h4>
                    <p class="question-excerpt">${q.body.substring(0, 150)}...</p>
                    <div class="flex items-center justify-between mt-2">
                        <div class="flex gap-2">
                            <span class="tag">${q.category || 'general'}</span>
                        </div>
                        <div class="question-author">
                            <span class="text-muted">${q.answers || 0} answers</span>
                            <span class="text-muted">•</span>
                            <span>${q.userName}</span>
                            <span class="text-muted">•</span>
                            <span>${formatDate(q.createdAt)}</span>
                        </div>
                    </div>
                </div>
                ${user && q.userId === user.id ? `
                <div class="flex gap-1">
                    <button class="btn btn-ghost btn-sm" onclick="editQuestion(${q.id})">Edit</button>
                    <button class="btn btn-ghost btn-sm" style="color: var(--danger);" onclick="deleteQuestion(${q.id})">Delete</button>
                </div>
                ` : ''}
            </div>
        </div>
    `).join('');
}

function getUserVote(questionId) {
    const votes = JSON.parse(localStorage.getItem('enh_question_votes') || '{}');
    return votes[questionId];
}

function voteQuestion(id, direction) {
    if (!window.AuthAPI?.isLoggedIn()) {
        showToast('Please login to vote', 'warning');
        return;
    }
    
    let questions = JSON.parse(localStorage.getItem('enh_questions') || '[]');
    const q = questions.find(q => q.id === id);
    if (q) {
        // Track user vote
        let votes = JSON.parse(localStorage.getItem('enh_question_votes') || '{}');
        const currentVote = votes[id] || 0;
        
        if (currentVote === direction) {
            // Remove vote
            q.votes -= direction;
            delete votes[id];
        } else {
            // Add or change vote
            q.votes += direction;
            votes[id] = direction;
        }
        
        localStorage.setItem('enh_question_votes', JSON.stringify(votes));
        localStorage.setItem('enh_questions', JSON.stringify(questions));
        showToast(direction > 0 ? 'Upvoted!' : 'Downvoted!', 'success');
        loadForumQuestions();
    }
}

function openQuestion(id) {
    const questions = JSON.parse(localStorage.getItem('enh_questions') || '[]');
    const q = questions.find(x => x.id === id);
    if (!q) return;
    
    // Show question detail (simplified - could open modal)
    showToast(`Opening: ${q.title}`, 'info');
}

function editQuestion(id) {
    const questions = JSON.parse(localStorage.getItem('enh_questions') || '[]');
    const q = questions.find(x => x.id === id);
    if (!q) return;
    
    const newTitle = prompt('Edit title:', q.title);
    const newBody = prompt('Edit description:', q.body);
    
    if (newTitle && newBody) {
        q.title = newTitle;
        q.body = newBody;
        localStorage.setItem('enh_questions', JSON.stringify(questions));
        showToast('Question updated!', 'success');
        loadForumQuestions();
    }
}

function deleteQuestion(id) {
    if (!confirm('Are you sure you want to delete this question?')) return;
    
    let questions = JSON.parse(localStorage.getItem('enh_questions') || '[]');
    questions = questions.filter(q => q.id !== id);
    localStorage.setItem('enh_questions', JSON.stringify(questions));
    showToast('Question deleted!', 'success');
    loadForumQuestions();
}

// Override postAnswer to include activity
const originalPostAnswer = postAnswer;
window.postAnswer = function(questionId) {
    const body = document.getElementById('answerBody')?.value;
    if (!body) {
        showToast('Please write an answer', 'warning');
        return;
    }
    
    const user = window.AuthAPI?.getUser();
    let answers = JSON.parse(localStorage.getItem('enh_answers') || '[]');
    
    answers.push({
        id: Date.now(),
        questionId: questionId,
        body: body,
        userId: user?.id,
        userName: user?.name || 'Anonymous',
        votes: 0,
        isAccepted: false,
        createdAt: new Date().toISOString()
    });
    
    let questions = JSON.parse(localStorage.getItem('enh_questions') || '[]');
    const qIndex = questions.findIndex(q => q.id === questionId);
    if (qIndex > -1) {
        questions[qIndex].answers = (questions[qIndex].answers || 0) + 1;
    }
    
    localStorage.setItem('enh_answers', JSON.stringify(answers));
    localStorage.setItem('enh_questions', JSON.stringify(questions));
    
    // Log activity
    if (window.ActivityTracker) {
        const q = questions.find(x => x.id === questionId);
        if (q) {
            window.ActivityTracker.log('forum', `Answered: "${q.title}"`, 'Replied to a community question');
        }
    }
    
    showToast('Answer posted!', 'success');
    loadForumQuestions();
};

// ============================================
// JOB SYSTEM
// ============================================

function postJob() {
    if (!window.AuthAPI?.isLoggedIn()) {
        showToast('Please login to post jobs', 'warning');
        return;
    }
    
    const title = document.getElementById('jobTitle')?.value;
    const company = document.getElementById('jobCompany')?.value;
    const description = document.getElementById('jobDescription')?.value;
    const requirements = document.getElementById('jobRequirements')?.value;
    const field = document.getElementById('jobField')?.value;
    const jobType = document.getElementById('jobType')?.value;
    const location = document.getElementById('jobLocation')?.value;
    const salary = document.getElementById('salaryRange')?.value;
    
    if (!title || !company || !description) {
        showToast('Please fill required fields', 'warning');
        return;
    }
    
    const user = window.AuthAPI.getUser();
    let jobs = JSON.parse(localStorage.getItem('enh_jobs') || '[]');
    
    jobs.unshift({
        id: Date.now(),
        title: title,
        company: company,
        description: description,
        requirements: requirements,
        field: field,
        jobType: jobType,
        location: location,
        salary: salary,
        postedBy: user.id,
        postedByName: user.name,
        isActive: true,
        createdAt: new Date().toISOString()
    });
    
    localStorage.setItem('enh_jobs', JSON.stringify(jobs));
    addNotification('success', 'Job Posted!', `Your job "${title}" has been posted`);
    showToast('Job posted successfully!', 'success');
    closeModal('postJobModal');
    loadJobs();
}

function loadJobs() {
    const container = document.getElementById('jobsList');
    if (!container) return;
    
    let jobs = JSON.parse(localStorage.getItem('enh_jobs') || '[]');
    jobs.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    
    if (jobs.length === 0) {
        container.innerHTML = '<p class="text-center text-muted p-4">No jobs posted yet.</p>';
        return;
    }
    
    container.innerHTML = jobs.map(job => `
        <div class="card job-card" data-job-item data-field="${job.field || 'all'}">
            <div class="flex gap-3">
                <div class="job-logo">${job.company.substring(0, 2).toUpperCase()}</div>
                <div class="flex-1">
                    <h4 class="job-title">${job.title}</h4>
                    <p class="job-company">${job.company}</p>
                    <div class="job-tags">
                        <span class="badge badge-primary">${job.jobType || 'Full-time'}</span>
                        <span class="badge badge-secondary">${job.location || 'Remote'}</span>
                        ${job.salary ? `<span class="badge badge-success">${job.salary}</span>` : ''}
                    </div>
                    <div class="job-footer">
                        <span class="text-muted">${formatDate(job.createdAt)}</span>
                        <button class="btn btn-primary btn-sm" onclick="applyForJob(${job.id})">Apply</button>
                    </div>
                </div>
            </div>
        </div>
    `).join('');
}

function applyForJob(jobId) {
    if (!window.AuthAPI?.isLoggedIn()) {
        showToast('Please login to apply', 'warning');
        window.location.href = '../auth/login.html';
        return;
    }
    
    const user = window.AuthAPI.getUser();
    let applications = JSON.parse(localStorage.getItem('enh_applications') || '[]');
    
    if (applications.find(a => a.jobId === jobId && a.userId === user.id)) {
        showToast('You already applied for this job', 'warning');
        return;
    }
    
    const jobs = JSON.parse(localStorage.getItem('enh_jobs') || '[]');
    const job = jobs.find(j => j.id === jobId);
    
    applications.push({
        id: Date.now(),
        jobId: jobId,
        jobTitle: job?.title,
        company: job?.company,
        userId: user.id,
        userName: user.name,
        status: 'pending',
        appliedAt: new Date().toISOString()
    });
    
    localStorage.setItem('enh_applications', JSON.stringify(applications));
    addNotification('success', 'Application Submitted!', `You applied for ${job?.title} at ${job?.company}`);
    showToast('Application submitted!', 'success');
}

function toggleBookmark(jobId) {
    if (!window.AuthAPI?.isLoggedIn()) {
        showToast('Please login to bookmark', 'warning');
        return;
    }
    
    let bookmarks = JSON.parse(localStorage.getItem('enh_bookmarks') || '[]');
    const index = bookmarks.indexOf(jobId);
    
    if (index > -1) {
        bookmarks.splice(index, 1);
        showToast('Bookmark removed', 'success');
    } else {
        bookmarks.push(jobId);
        showToast('Job bookmarked!', 'success');
    }
    
    localStorage.setItem('enh_bookmarks', JSON.stringify(bookmarks));
}

window.postJob = postJob;
window.loadJobs = loadJobs;
window.applyForJob = applyForJob;
window.toggleBookmark = toggleBookmark;

// ============================================
// COURSE SYSTEM
// ============================================

function enrollInCourse(courseId) {
    if (!window.AuthAPI?.isLoggedIn()) {
        showToast('Please login to enroll', 'warning');
        window.location.href = '../auth/login.html';
        return;
    }
    
    const user = window.AuthAPI.getUser();
    let enrollments = JSON.parse(localStorage.getItem('enh_enrollments') || '[]');
    
    if (enrollments.find(e => e.courseId === courseId && e.userId === user.id)) {
        showToast('Already enrolled in this course', 'warning');
        return;
    }
    
    enrollments.push({
        id: Date.now(),
        courseId: courseId,
        userId: user.id,
        progress: 0,
        enrolledAt: new Date().toISOString()
    });
    
    localStorage.setItem('enh_enrollments', JSON.stringify(enrollments));
    addNotification('success', 'Enrolled!', 'You have successfully enrolled in this course');
    showToast('Enrolled successfully!', 'success');
}

function updateProgress(courseId, lessonId) {
    const user = window.AuthAPI.getUser();
    let enrollments = JSON.parse(localStorage.getItem('enh_enrollments') || '[]');
    let lessonProgress = JSON.parse(localStorage.getItem('enh_lessonProgress') || '[]');
    
    const enrollment = enrollments.find(e => e.courseId === courseId && e.userId === user.id);
    if (!enrollment) return;
    
    if (!lessonProgress.find(lp => lp.lessonId === lessonId && lp.userId === user.id)) {
        lessonProgress.push({
            courseId: courseId,
            lessonId: lessonId,
            userId: user.id,
            completed: true,
            completedAt: new Date().toISOString()
        });
    }
    
    const totalLessons = 10;
    const completedLessons = lessonProgress.filter(lp => lp.courseId === courseId && lp.userId === user.id).length;
    enrollment.progress = Math.round((completedLessons / totalLessons) * 100);
    
    localStorage.setItem('enh_enrollments', JSON.stringify(enrollments));
    localStorage.setItem('enh_lessonProgress', JSON.stringify(lessonProgress));
    showToast('Lesson completed!', 'success');
}

function filterCourses(field) {
    localStorage.setItem('enh_courseFilter', field);
    const courses = document.querySelectorAll('[data-field]');
    courses.forEach(course => {
        if (!field || field === 'all' || course.dataset.field === field) {
            course.style.display = '';
        } else {
            course.style.display = 'none';
        }
    });
}

window.enrollInCourse = enrollInCourse;
window.updateProgress = updateProgress;
window.filterCourses = filterCourses;

// ============================================
// AVATAR & PROFILE
// ============================================

function uploadAvatar(input) {
    const file = input.files[0];
    if (!file) return;
    
    if (!file.type.startsWith('image/')) {
        showToast('Please select an image file', 'error');
        return;
    }
    
    const reader = new FileReader();
    reader.onload = (e) => {
        const user = window.AuthAPI?.getUser();
        if (user) {
            user.avatar = e.target.result;
            localStorage.setItem('enh_user', JSON.stringify(user));
            
            document.querySelectorAll('#userAvatar, .user-avatar').forEach(avatar => {
                avatar.innerHTML = `<img src="${e.target.result}" style="width:100%;height:100%;object-fit:cover;border-radius:50%;">`;
            });
            
            showToast('Avatar updated!', 'success');
        }
    };
    reader.readAsDataURL(file);
}

window.uploadAvatar = uploadAvatar;

// ============================================
// FOLLOW SYSTEM
// ============================================

function toggleFollow(userId) {
    if (!window.AuthAPI?.isLoggedIn()) {
        showToast('Please login first', 'warning');
        return;
    }
    
    let following = JSON.parse(localStorage.getItem('enh_following') || '[]');
    const index = following.indexOf(userId);
    
    if (index > -1) {
        following.splice(index, 1);
        showToast('Unfollowed', 'success');
    } else {
        following.push(userId);
        showToast('Following!', 'success');
    }
    
    localStorage.setItem('enh_following', JSON.stringify(following));
    
    const btn = document.querySelector(`[data-follow-btn="${userId}"]`);
    if (btn) {
        btn.textContent = index > -1 ? '+ Follow' : 'Following';
        btn.classList.toggle('following', index === -1);
    }
}

window.toggleFollow = toggleFollow;

// ============================================
// UTILITY FUNCTIONS
// ============================================

function showToast(message, type = 'info') {
    let container = document.querySelector('.toast-container');
    if (!container) {
        container = document.createElement('div');
        container.className = 'toast-container';
        document.body.appendChild(container);
    }

    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.innerHTML = `
        <span>${message}</span>
        <button class="toast-close" onclick="this.parentElement.remove()" style="background:none;border:none;cursor:pointer;font-size:18px;">×</button>
    `;

    container.appendChild(toast);

    setTimeout(() => toast.remove(), 4000);
}

function formatDate(date) {
    const d = new Date(date);
    const now = new Date();
    const diff = now - d;
    
    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(diff / 3600000);
    const days = Math.floor(diff / 86400000);

    if (minutes < 1) return 'Just now';
    if (minutes < 60) return `${minutes}m ago`;
    if (hours < 24) return `${hours}h ago`;
    if (days < 7) return `${days}d ago`;
    
    return d.toLocaleDateString();
}

function validateEmail(email) {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

function logout() {
    window.AuthAPI?.logout();
}

window.logout = logout;
window.showToast = showToast;
window.formatDate = formatDate;
window.validateEmail = validateEmail;

// ============================================
// DEMO DATA LOADER
// ============================================

function loadDemoData() {
    // Load demo courses if empty
    if (!localStorage.getItem('enh_courses')) {
        const demoCourses = [
            { id: 1, title: 'Circuit Analysis Fundamentals', field: 'electrical', instructor: 'Dr. Sarah Johnson', lessons: 24, hours: 12, rating: 4.8, students: 234, price: 'Free', level: 'Beginner' },
            { id: 2, title: 'Thermodynamics: Basics to Advanced', field: 'mechanical', instructor: 'Prof. Michael Chen', lessons: 36, hours: 24, rating: 4.9, students: 189, price: '$49', level: 'Intermediate' },
            { id: 3, title: 'Structural Engineering Masterclass', field: 'civil', instructor: 'Dr. Emily Roberts', lessons: 48, hours: 32, rating: 4.7, students: 156, price: '$79', level: 'Advanced' },
            { id: 4, title: 'Full-Stack Web Development', field: 'software', instructor: 'John Smith', lessons: 62, hours: 40, rating: 4.9, students: 512, price: 'Free', level: 'Beginner' },
            { id: 5, title: 'Digital Electronics & Microcontrollers', field: 'electrical', instructor: 'Dr. Lisa Wang', lessons: 28, hours: 18, rating: 4.6, students: 98, price: '$59', level: 'Intermediate' },
            { id: 6, title: 'CAD Design with AutoCAD', field: 'mechanical', instructor: 'Mark Thompson', lessons: 42, hours: 28, rating: 4.8, students: 267, price: 'Free', level: 'Beginner' }
        ];
        localStorage.setItem('enh_courses', JSON.stringify(demoCourses));
    }

    // Load demo jobs if empty
    if (!localStorage.getItem('enh_jobs')) {
        const demoJobs = [
            { id: 1, title: 'Junior Electrical Engineer', company: 'TechCorp Inc.', jobType: 'Full-time', location: 'Remote', salary: '$60,000 - $80,000', field: 'electrical', description: 'Looking for a junior electrical engineer to join our team. Must know Ohm\'s Law and basic circuit design.', requirements: 'Basic circuit knowledge, problem solving skills', createdAt: new Date().toISOString() },
            { id: 2, title: 'Structural Engineer', company: 'ArchEngineers Ltd.', jobType: 'Full-time', location: 'On-site', salary: '$75,000 - $95,000', field: 'civil', description: 'Seeking an experienced structural engineer for building projects.', requirements: '5+ years experience, AutoCAD skills', createdAt: new Date(Date.now() - 86400000).toISOString() },
            { id: 3, title: 'Mechanical Design Intern', company: 'MegaEngineering', jobType: 'Internship', location: 'Hybrid', salary: '$20 - $25/hr', field: 'mechanical', description: 'Summer internship for mechanical engineering students.', requirements: 'Student of Mechanical Engineering, CAD knowledge', createdAt: new Date(Date.now() - 172800000).toISOString() },
            { id: 4, title: 'Software Engineer', company: 'SoftSolves Inc.', jobType: 'Full-time', location: 'Remote', salary: '$90,000 - $120,000', field: 'software', description: 'Full-stack software engineer for engineering applications.', requirements: 'JavaScript, Python, Database design', createdAt: new Date(Date.now() - 259200000).toISOString() },
            { id: 5, title: 'Power Systems Engineer', company: 'PowerGrid Solutions', jobType: 'Full-time', location: 'On-site', salary: '$85,000 - $110,000', field: 'electrical', description: 'Power systems engineer for grid infrastructure projects.', requirements: 'Power systems knowledge, engineering license preferred', createdAt: new Date(Date.now() - 43200000).toISOString() },
            { id: 6, title: 'Civil Engineering Intern', company: 'BuildRight Corp.', jobType: 'Internship', location: 'On-site', salary: '$18/hr', field: 'civil', description: 'Internship for civil engineering students.', requirements: 'Civil engineering student, basic surveying knowledge', createdAt: new Date(Date.now() - 604800000).toISOString() }
        ];
        localStorage.setItem('enh_jobs', JSON.stringify(demoJobs));
    }

    // Load demo forum questions if empty
    if (!localStorage.getItem('enh_questions')) {
        const demoQuestions = [
            { id: 1, title: 'How does Ohm\'s Law work in real circuits?', body: 'I\'m trying to understand how to apply Ohm\'s Law in practical circuit design. Can someone explain with examples?', category: 'electrical', tags: ['electrical', 'circuits'], userId: 1, userName: 'Ahmed Mohamed', votes: 15, answers: 3, views: 120, createdAt: new Date(Date.now() - 3600000).toISOString() },
            { id: 2, title: 'Best resources for learning AutoCAD?', body: 'What are the best online resources for learning AutoCAD for mechanical engineering?', category: 'mechanical', tags: ['mechanical', 'CAD'], userId: 2, userName: 'Fatima Ali', votes: 8, answers: 5, views: 89, createdAt: new Date(Date.now() - 86400000).toISOString() },
            { id: 3, title: 'How to calculate structural load for a building?', body: 'I need help understanding how to calculate dead load and live load for a 3-story residential building. What formulas should I use?', category: 'civil', tags: ['civil', 'structures'], userId: 3, userName: 'Omar Hassan', votes: 12, answers: 2, views: 156, createdAt: new Date(Date.now() - 172800000).toISOString() },
            { id: 4, title: 'Python vs JavaScript for engineering applications?', body: 'Which programming language is better for engineering simulations and data analysis? I work primarily in mechanical engineering.', category: 'software', tags: ['software', 'programming'], userId: 4, userName: 'Aisha Yusuf', votes: 6, answers: 4, views: 78, createdAt: new Date(Date.now() - 259200000).toISOString() },
            { id: 5, title: 'What are the best internship opportunities for mechanical engineers?', body: 'I\'m a final year mechanical engineering student looking for internship opportunities. Any recommendations?', category: 'general', tags: ['career', 'internship'], userId: 5, userName: 'Ibrahim Muse', votes: 9, answers: 6, views: 134, createdAt: new Date(Date.now() - 345600000).toISOString() },
            { id: 6, title: 'How to design a solar power system for a small home?', body: 'I want to install solar panels for my house. How do I calculate the number of panels needed?', category: 'electrical', tags: ['solar', 'renewable'], userId: 6, userName: 'Amina Osman', votes: 11, answers: 4, views: 98, createdAt: new Date(Date.now() - 432000000).toISOString() },
            { id: 7, title: 'What is the difference between steel and concrete structures?', body: 'When should I use steel vs concrete for building construction? What are the pros and cons?', category: 'civil', tags: ['structures', 'materials'], userId: 7, userName: 'Mohamed Salad', votes: 7, answers: 3, views: 67, createdAt: new Date(Date.now() - 518400000).toISOString() },
            { id: 8, title: 'How to get started with Arduino programming?', body: 'I\'m new to embedded systems. What\'s the best way to start learning Arduino?', category: 'software', tags: ['arduino', 'embedded'], userId: 1, userName: 'Ahmed Mohamed', votes: 14, answers: 5, views: 145, createdAt: new Date(Date.now() - 604800000).toISOString() },
            { id: 9, title: 'Best CAD software for mechanical engineering students?', body: 'What CAD software should I learn as a mechanical engineering student? Free options?', category: 'mechanical', tags: ['CAD', 'software'], userId: 2, userName: 'Fatima Ali', votes: 10, answers: 7, views: 112, createdAt: new Date(Date.now() - 691200000).toISOString() },
            { id: 10, title: 'How does a transformer work?', body: 'Can someone explain the working principle of electrical transformers? Step-up vs step-down?', category: 'electrical', tags: ['transformer', 'electrical'], userId: 3, userName: 'Omar Hassan', votes: 18, answers: 6, views: 203, createdAt: new Date(Date.now() - 777600000).toISOString() },
            { id: 11, title: 'What programming languages are used in civil engineering?', body: 'I\'m studying civil engineering. Which programming languages should I learn?', category: 'civil', tags: ['programming', 'civil'], userId: 4, userName: 'Aisha Yusuf', votes: 5, answers: 3, views: 45, createdAt: new Date(Date.now() - 864000000).toISOString() },
            { id: 12, title: 'How to prepare for engineering job interviews?', body: 'What are common interview questions for engineering positions? How to prepare?', category: 'general', tags: ['career', 'interview'], userId: 5, userName: 'Ibrahim Muse', votes: 20, answers: 8, views: 267, createdAt: new Date(Date.now() - 950400000).toISOString() }
        ];
        localStorage.setItem('enh_questions', JSON.stringify(demoQuestions));
    }
    
    // Add demo answers if none exist
    if (!localStorage.getItem('enh_answers')) {
        const demoAnswers = [
            { id: 1, questionId: 1, body: 'Ohm\'s Law states that V = I × R, where V is voltage, I is current, and R is resistance. In practical circuits, you use this to calculate any one of these values if you know the other two. For example, if you have a 9V battery and a 100Ω resistor, the current would be I = V/R = 9/100 = 0.09A or 90mA.', userId: 2, userName: 'Fatima Ali', votes: 8, isAccepted: true, createdAt: new Date(Date.now() - 1800000).toISOString() },
            { id: 2, questionId: 1, body: 'Also remember to consider power dissipation: P = V × I = I²R = V²/R. This helps you choose the right resistor wattage rating.', userId: 3, userName: 'Omar Hassan', votes: 3, isAccepted: false, createdAt: new Date(Date.now() - 900000).toISOString() },
            { id: 3, questionId: 2, body: 'I highly recommend the official Autodesk YouTube channel and also check out "Tutoriales de AutoCAD" on YouTube - they have great Spanish tutorials with English subtitles.', userId: 4, userName: 'Aisha Yusuf', votes: 5, isAccepted: true, createdAt: new Date(Date.now() - 43200000).toISOString() },
            { id: 4, questionId: 3, body: 'For a 3-story residential building, you need to calculate: 1) Dead load from structural elements (beams, columns, slabs), 2) Live load from occupants/furniture (typically 40-50 psf for residential), 3) Apply ASCE 7 or your local building code for load combinations.', userId: 1, userName: 'Ahmed Mohamed', votes: 6, isAccepted: true, createdAt: new Date(Date.now() - 86400000).toISOString() },
            { id: 5, questionId: 4, body: 'For engineering simulations, Python is the better choice. Libraries like NumPy, SciPy, and Matplotlib are excellent for numerical analysis. For web-based dashboards, JavaScript is great. Many engineers use both - Python for analysis, JS for visualization.', userId: 5, userName: 'Ibrahim Muse', votes: 4, isAccepted: false, createdAt: new Date(Date.now() - 129600000).toISOString() },
            { id: 6, questionId: 6, body: 'For a small home solar system, you need to: 1) Calculate daily energy usage (kWh), 2) Account for sun hours in your area (typically 5-6 hours in Somalia), 3) Add 20% for inefficiencies. Example: 10kWh/day ÷ 5 sun hours × 1.2 = 2.4kW system.', userId: 1, userName: 'Ahmed Mohamed', votes: 7, isAccepted: true, createdAt: new Date(Date.now() - 216000000).toISOString() },
            { id: 7, questionId: 7, body: 'Steel: High strength-to-weight ratio, ductile, suitable for long spans, but susceptible to corrosion. Concrete: Lower cost, durable, fire resistant, but heavy and weak in tension. Use steel for tall buildings and long bridges, concrete for foundations and short structures.', userId: 3, userName: 'Omar Hassan', votes: 5, isAccepted: true, createdAt: new Date(Date.now() - 302400000).toISOString() },
            { id: 8, questionId: 8, body: 'Start with the official Arduino website tutorials. Buy a starter kit with basic components. Start with LED blinking, then sensors, then motors. Use Tinkercad for simulation before building. r/arduino on Reddit is great for help!', userId: 4, userName: 'Aisha Yusuf', votes: 9, isAccepted: true, createdAt: new Date(Date.now() - 388800000).toISOString() },
            { id: 9, questionId: 9, body: 'Free options: Fusion 360 (free for students), Onshape (free), Blender for 3D modeling. For 2D: LibreCAD. AutoCAD is industry standard but expensive. Learn one thoroughly rather than jumping between them.', userId: 2, userName: 'Fatima Ali', votes: 8, isAccepted: true, createdAt: new Date(Date.now() - 475200000).toISOString() },
            { id: 10, questionId: 10, body: 'Transformers work on electromagnetic induction. Step-up increases voltage (more turns on secondary), step-down decreases voltage. Key formula: V1/V2 = N1/N2. They only work with AC, not DC!', userId: 5, userName: 'Ibrahim Muse', votes: 12, isAccepted: true, createdAt: new Date(Date.now() - 561600000).toISOString() },
            { id: 11, questionId: 12, body: 'Common questions: 1) Tell me about yourself, 2) Why do you want to work here, 3) Describe a challenging project, 4) Technical questions about your field. Practice STAR method for behavioral questions. Research the company!', userId: 6, userName: 'Amina Osman', votes: 15, isAccepted: true, createdAt: new Date(Date.now() - 648000000).toISOString() }
        ];
        localStorage.setItem('enh_answers', JSON.stringify(demoAnswers));
    }

    // Initialize platform stats
    PlatformStats.init();
    
    // Add demo users if none exist
    if (!localStorage.getItem('enh_users')) {
        const demoUsers = [
            { id: 1, name: 'Ahmed Mohamed', email: 'ahmed@example.com', role: 'student', field: 'electrical', joinedAt: new Date(Date.now() - 86400000 * 30).toISOString() },
            { id: 2, name: 'Fatima Ali', email: 'fatima@example.com', role: 'student', field: 'mechanical', joinedAt: new Date(Date.now() - 86400000 * 25).toISOString() },
            { id: 3, name: 'Omar Hassan', email: 'omar@example.com', role: 'student', field: 'civil', joinedAt: new Date(Date.now() - 86400000 * 20).toISOString() },
            { id: 4, name: 'Aisha Yusuf', email: 'aisha@example.com', role: 'student', field: 'software', joinedAt: new Date(Date.now() - 86400000 * 15).toISOString() },
            { id: 5, name: 'Ibrahim Muse', email: 'ibrahim@example.com', role: 'student', field: 'electrical', joinedAt: new Date(Date.now() - 86400000 * 10).toISOString() },
            { id: 6, name: 'Amina Osman', email: 'amina@example.com', role: 'student', field: 'mechanical', joinedAt: new Date(Date.now() - 86400000 * 5).toISOString() },
            { id: 7, name: 'Mohamed Salad', email: 'mohamed@example.com', role: 'student', field: 'civil', joinedAt: new Date().toISOString() }
        ];
        localStorage.setItem('enh_users', JSON.stringify(demoUsers));
    }
    
    // Add demo resources if none exist
    if (!localStorage.getItem('enh_resources')) {
        const demoResources = [
            { id: 1, title: 'Circuit Analysis Notes', type: 'PDF', category: 'electrical', size: '2.4 MB' },
            { id: 2, title: 'Thermodynamics Formula Sheet', type: 'PDF', category: 'mechanical', size: '1.1 MB' },
            { id: 3, title: 'Structural Design Guide', type: 'PDF', category: 'civil', size: '3.2 MB' },
            { id: 4, title: 'Programming Fundamentals', type: 'PDF', category: 'software', size: '1.8 MB' },
            { id: 5, title: 'Past Exam - Electrical', type: 'PDF', category: 'electrical', size: '856 KB' }
        ];
        localStorage.setItem('enh_resources', JSON.stringify(demoResources));
    }
    
    // Initialize demo jobs with companies if none exist
    if (!localStorage.getItem('enh_jobs')) {
        const demoJobs = [
            { id: 1, title: 'Junior Electrical Engineer', company: 'TechCorp Inc.', jobType: 'Full-time', location: 'Remote', salary: '$60k-80k', field: 'electrical', description: 'Looking for a junior electrical engineer to join our team.', createdAt: new Date().toISOString() },
            { id: 2, title: 'Structural Engineer', company: 'ArchEngineers', jobType: 'Full-time', location: 'On-site', salary: '$70k-90k', field: 'civil', description: 'Seeking an experienced structural engineer.', createdAt: new Date(Date.now() - 86400000).toISOString() },
            { id: 3, title: 'Mechanical Design Intern', company: 'MegaEng', jobType: 'Internship', location: 'Hybrid', salary: '$20/hr', field: 'mechanical', description: 'Summer internship for mechanical engineering students.', createdAt: new Date(Date.now() - 172800000).toISOString() },
            { id: 4, title: 'Software Developer', company: 'CodeTech', jobType: 'Full-time', location: 'Remote', salary: '$80k-100k', field: 'software', description: 'Full-stack developer needed.', createdAt: new Date(Date.now() - 259200000).toISOString() }
        ];
        localStorage.setItem('enh_jobs', JSON.stringify(demoJobs));
    }
}

// ============================================
// DYNAMIC STATISTICS SYSTEM (API-Ready)
// ============================================

const PlatformStats = {
    // Cache DOM elements
    elements: {},
    
    // Initialize stats system
    init: function() {
        this.cacheElements();
        this.updateAll();
        
        // Auto-refresh every 10 seconds for real-time feel
        setInterval(() => this.updateAll(), 10000);
    },
    
    // Cache stat elements
    cacheElements: function() {
        this.elements = {
            students: document.getElementById('statStudents'),
            courses: document.getElementById('statCourses'),
            companies: document.getElementById('statCompanies'),
            resources: document.getElementById('statResources')
        };
    },
    
    // Count active students (role = student)
    getStudentsCount: function() {
        const users = JSON.parse(localStorage.getItem('enh_users') || '[]');
        const students = users.filter(u => u.role === 'student' || u.role === 'Student');
        
        // Add demo students if none exist
        if (students.length === 0) {
            return 156; // Demo count
        }
        return students.length;
    },
    
    // Count total courses (from structured learning system)
    getCoursesCount: function() {
        let count = 0;
        
        // Count from LearningSystem if available
        if (window.LearningSystem && window.LearningSystem.getAllCoursesFlat) {
            const courses = window.LearningSystem.getAllCoursesFlat();
            count = courses.length;
        }
        
        // Add any stored courses
        const storedCourses = JSON.parse(localStorage.getItem('enh_courses') || '[]');
        count += storedCourses.length;
        
        // Return demo value if none
        return count || 6;
    },
    
    // Count unique companies from jobs
    getCompaniesCount: function() {
        const jobs = JSON.parse(localStorage.getItem('enh_jobs') || '[]');
        const companies = [...new Set(jobs.map(j => j.company))];
        if (companies.length === 0) {
            return 45; // Demo count
        }
        return companies.length + 45; // Add demo companies
    },
    
    // Count total resources
    getResourcesCount: function() {
        const resources = JSON.parse(localStorage.getItem('enh_resources') || '[]');
        if (resources.length === 0) {
            return 234; // Demo count
        }
        return resources.length;
    },
    
    // Update all stats with animation
    updateAll: function() {
        this.cacheElements();
        
        const stats = {
            students: this.getStudentsCount(),
            courses: this.getCoursesCount(),
            companies: this.getCompaniesCount(),
            resources: this.getResourcesCount()
        };
        
        if (this.elements.students) {
            this.animateCounter(this.elements.students, stats.students);
        }
        if (this.elements.courses) {
            this.animateCounter(this.elements.courses, stats.courses);
        }
        if (this.elements.companies) {
            this.animateCounter(this.elements.companies, stats.companies);
        }
        if (this.elements.resources) {
            this.animateCounter(this.elements.resources, stats.resources);
        }
        
        // Store current stats
        this.currentStats = stats;
    },
    
    // Animated counter effect
    animateCounter: function(element, target) {
        const current = parseInt(element.dataset.value) || 0;
        const duration = 1000;
        const steps = 30;
        const increment = (target - current) / steps;
        let step = 0;
        
        const animate = () => {
            step++;
            const value = Math.round(current + (increment * step));
            element.dataset.value = value;
            element.textContent = value.toLocaleString();
            
            if (step < steps) {
                requestAnimationFrame(animate);
            } else {
                element.textContent = target.toLocaleString();
                element.dataset.value = target;
            }
        };
        
        animate();
    },
    
    // API-ready method for external updates
    refresh: function() {
        this.updateAll();
    }
};

// Expose globally for manual refresh
window.PlatformStats = PlatformStats;

// ============================================
// REGISTER NEW USER → INCREASE STUDENTS
// ============================================

// Override handleRegister to track users (only if AuthAPI exists)
if (window.AuthAPI && window.AuthAPI.handleRegister) {
    const originalRegister = window.AuthAPI.handleRegister;
    window.AuthAPI.handleRegister = async function(name, email, password, role, field) {
        const user = await originalRegister(name, email, password, role, field);
        
        // Save to users list
        const users = JSON.parse(localStorage.getItem('enh_users') || '[]');
        users.push({
            id: user.id,
            name: name,
            email: email,
            role: role,
            field: field,
            joinedAt: new Date().toISOString()
        });
        localStorage.setItem('enh_users', JSON.stringify(users));
        
        // Refresh stats
        setTimeout(() => PlatformStats.refresh(), 500);
        
        return user;
    };
}

// ============================================
// ADD COURSE → INCREASE COURSES
// ============================================

window.addCourse = function(course) {
    const courses = JSON.parse(localStorage.getItem('enh_courses') || '[]');
    courses.push({
        id: Date.now(),
        ...course,
        createdAt: new Date().toISOString()
    });
    localStorage.setItem('enh_courses', JSON.stringify(courses));
    
    // Refresh stats
    PlatformStats.refresh();
};

// ============================================
// ADD JOB (with company) → INCREASE COMPANIES
// ============================================

const originalPostJob = window.postJob;
window.postJob = function() {
    // Call original function
    if (originalPostJob) originalPostJob();
    
    // Refresh stats after job is posted
    setTimeout(() => PlatformStats.refresh(), 1000);
};

// ============================================
// ADD RESOURCE → INCREASE RESOURCES
// ============================================

window.addResource = function(resource) {
    const resources = JSON.parse(localStorage.getItem('enh_resources') || '[]');
    resources.push({
        id: Date.now(),
        ...resource,
        uploadedAt: new Date().toISOString()
    });
    localStorage.setItem('enh_resources', JSON.stringify(resources));
    
    // Refresh stats
    PlatformStats.refresh();
};

// ============================================
// LEARNING & PROGRESS SYSTEM
// ============================================

const LearningSystem = {
    // Complete course structure with all levels and fields (50+ courses)
    getAllCourses: function() {
        return {
            electrical: {
                beginner: [
                    { id: 101, title: 'Basic Electricity', description: 'Introduction to electrical concepts and fundamentals', lessons: 8, duration: '4 hours', rating: 4.8, students: 234 },
                    { id: 102, title: "Ohm's Law Fundamentals", description: 'Understanding voltage, current, and resistance', lessons: 6, duration: '3 hours', rating: 4.9, students: 189 },
                    { id: 103, title: 'Electrical Safety', description: 'Essential safety practices for electrical work', lessons: 5, duration: '2 hours', rating: 4.7, students: 156 },
                    { id: 104, title: 'DC Circuits Basics', description: 'Introduction to direct current circuits', lessons: 7, duration: '3.5 hours', rating: 4.6, students: 312 },
                    { id: 105, title: 'Intro to Power', description: 'Basic concepts of electrical power', lessons: 6, duration: '3 hours', rating: 4.8, students: 198 },
                    { id: 106, title: 'Electronic Components', description: 'Learn about resistors, capacitors, and inductors', lessons: 8, duration: '4 hours', rating: 4.7, students: 267 },
                    { id: 107, title: 'Circuit Symbols', description: 'Understanding electrical schematic symbols', lessons: 5, duration: '2 hours', rating: 4.9, students: 345 },
                    { id: 108, title: 'Wiring Basics', description: 'Introduction to electrical wiring', lessons: 6, duration: '3 hours', rating: 4.5, students: 234 },
                    { id: 109, title: 'Electrical Measurements', description: 'Using multimeters and measuring tools', lessons: 7, duration: '3.5 hours', rating: 4.8, students: 189 },
                    { id: 110, title: 'Voltage & Current', description: 'Understanding voltage and current flow', lessons: 5, duration: '2.5 hours', rating: 4.7, students: 276 },
                    { id: 111, title: 'Power Distribution', description: 'Introduction to power distribution systems', lessons: 8, duration: '4 hours', rating: 4.6, students: 156 },
                    { id: 112, title: 'Electrical Tools', description: 'Essential tools for electricians', lessons: 6, duration: '3 hours', rating: 4.8, students: 298 },
                    { id: 113, title: 'Introduction to AC', description: 'Alternating current basics', lessons: 7, duration: '3.5 hours', rating: 4.7, students: 234 },
                    { id: 114, title: 'Grounding Systems', description: 'Understanding electrical grounding', lessons: 5, duration: '2.5 hours', rating: 4.9, students: 189 },
                    { id: 115, title: 'Circuit Protection', description: 'Fuses, breakers, and protection devices', lessons: 6, duration: '3 hours', rating: 4.6, students: 267 },
                    { id: 116, title: 'Electrical Testing', description: 'Testing and troubleshooting electrical systems', lessons: 8, duration: '4 hours', rating: 4.8, students: 198 },
                    { id: 117, title: 'Wire Gauges', description: 'Understanding wire sizes and gauges', lessons: 4, duration: '2 hours', rating: 4.7, students: 345 }
                ],
                intermediate: [
                    { id: 118, title: 'Circuit Analysis', description: 'Advanced circuit analysis techniques', lessons: 10, duration: '8 hours', rating: 4.8, students: 312 },
                    { id: 119, title: 'Power Systems Basics', description: 'Introduction to power generation and distribution', lessons: 8, duration: '6 hours', rating: 4.6, students: 198 },
                    { id: 120, title: 'Digital Electronics', description: 'Digital circuits and logic gates', lessons: 12, duration: '10 hours', rating: 4.9, students: 267 },
                    { id: 121, title: 'AC Circuit Theory', description: 'Advanced AC circuit analysis', lessons: 10, duration: '8 hours', rating: 4.7, students: 234 },
                    { id: 122, title: 'Electrical Machines', description: 'Motors and generators', lessons: 12, duration: '10 hours', rating: 4.8, students: 189 },
                    { id: 123, title: 'Power Electronics', description: ' converters and inverters', lessons: 10, duration: '8 hours', rating: 4.9, students: 156 },
                    { id: 124, title: 'Electronic Devices', description: 'Semiconductors and diodes', lessons: 11, duration: '9 hours', rating: 4.7, students: 298 },
                    { id: 125, title: 'Network Analysis', description: 'Mesh and nodal analysis', lessons: 9, duration: '7 hours', rating: 4.8, students: 234 },
                    { id: 126, title: 'Electrical Design', description: 'Power system design principles', lessons: 10, duration: '8 hours', rating: 4.6, students: 176 },
                    { id: 127, title: 'Transformer Theory', description: 'Operation and design of transformers', lessons: 8, duration: '6 hours', rating: 4.7, students: 212 },
                    { id: 128, title: 'Fault Analysis', description: 'Power system fault diagnosis', lessons: 9, duration: '7 hours', rating: 4.8, students: 145 },
                    { id: 129, title: 'Load Flow Analysis', description: 'Power system load flow studies', lessons: 8, duration: '6 hours', rating: 4.9, students: 167 },
                    { id: 130, title: 'Electrical Installations', description: 'Commercial wiring design', lessons: 11, duration: '9 hours', rating: 4.7, students: 223 },
                    { id: 131, title: 'Renewable Energy', description: 'Solar and wind power systems', lessons: 10, duration: '8 hours', rating: 4.8, students: 289 },
                    { id: 132, title: 'Power Quality', description: 'Harmonics and power quality issues', lessons: 9, duration: '7 hours', rating: 4.6, students: 178 },
                    { id: 133, title: 'High Voltage Systems', description: 'High voltage equipment and safety', lessons: 10, duration: '8 hours', rating: 4.7, students: 134 },
                    { id: 134, title: 'Electrical Drawing', description: 'Reading electrical schematics', lessons: 7, duration: '5 hours', rating: 4.9, students: 345 }
                ],
                advanced: [
                    { id: 135, title: 'Advanced Electronics', description: 'Semiconductor devices and circuits', lessons: 15, duration: '12 hours', rating: 4.8, students: 145 },
                    { id: 136, title: 'Control Systems', description: 'Feedback and control theory', lessons: 14, duration: '11 hours', rating: 4.7, students: 98 },
                    { id: 137, title: 'Power Electronics', description: 'Converters and power conditioning', lessons: 12, duration: '10 hours', rating: 4.9, students: 87 },
                    { id: 138, title: 'Signal Processing', description: 'Digital signal processing techniques', lessons: 13, duration: '11 hours', rating: 4.8, students: 112 },
                    { id: 139, title: 'VLSI Design', description: 'Very large scale integration design', lessons: 14, duration: '12 hours', rating: 4.7, students: 76 },
                    { id: 140, title: 'RF Engineering', description: 'Radio frequency circuit design', lessons: 12, duration: '10 hours', rating: 4.8, students: 89 },
                    { id: 141, title: 'Power System Protection', description: 'Relay protection and coordination', lessons: 13, duration: '11 hours', rating: 4.9, students: 67 },
                    { id: 142, title: 'Smart Grids', description: 'Modern grid technology', lessons: 11, duration: '9 hours', rating: 4.7, students: 134 },
                    { id: 143, title: 'Embedded Systems', description: 'Microcontroller design', lessons: 14, duration: '12 hours', rating: 4.8, students: 156 },
                    { id: 144, title: 'FPGA Design', description: 'Field programmable gate arrays', lessons: 12, duration: '10 hours', rating: 4.9, students: 78 },
                    { id: 145, title: 'Power System Stability', description: 'Transient and dynamic stability', lessons: 10, duration: '8 hours', rating: 4.6, students: 45 },
                    { id: 146, title: 'Advanced Machines', description: 'Special electrical machines', lessons: 11, duration: '9 hours', rating: 4.7, students: 67 },
                    { id: 147, title: 'EM Interference', description: 'Electromagnetic compatibility', lessons: 9, duration: '7 hours', rating: 4.8, students: 89 },
                    { id: 148, title: 'HVDC Systems', description: 'High voltage DC transmission', lessons: 10, duration: '8 hours', rating: 4.9, students: 56 },
                    { id: 149, title: 'Electrical Diagnostics', description: 'Advanced fault finding techniques', lessons: 8, duration: '6 hours', rating: 4.7, students: 123 },
                    { id: 150, title: 'Energy Storage', description: 'Battery and storage systems', lessons: 10, duration: '8 hours', rating: 4.8, students: 178 }
                ]
            },
            mechanical: {
                beginner: [
                    { id: 201, title: 'Engineering Drawing', description: 'Introduction to technical drawing and CAD', lessons: 8, duration: '4 hours', rating: 4.7, students: 345 },
                    { id: 202, title: 'Statics Fundamentals', description: 'Basic statics and force analysis', lessons: 6, duration: '3 hours', rating: 4.8, students: 234 },
                    { id: 203, title: 'Materials Science', description: 'Introduction to engineering materials', lessons: 7, duration: '3.5 hours', rating: 4.6, students: 189 },
                    { id: 204, title: 'Technical Drawing', description: 'Engineering drawing standards', lessons: 8, duration: '4 hours', rating: 4.7, students: 312 },
                    { id: 205, title: 'Introduction to CAD', description: 'Computer-aided design basics', lessons: 6, duration: '3 hours', rating: 4.8, students: 276 },
                    { id: 206, title: 'Force Analysis', description: 'Understanding forces in mechanics', lessons: 7, duration: '3.5 hours', rating: 4.6, students: 198 },
                    { id: 207, title: 'Material Properties', description: 'Mechanical properties of materials', lessons: 6, duration: '3 hours', rating: 4.7, students: 234 },
                    { id: 208, title: 'Basic Machining', description: 'Introduction to machining processes', lessons: 8, duration: '4 hours', rating: 4.8, students: 167 },
                    { id: 209, title: 'Measurements', description: 'Engineering measurements and tools', lessons: 6, duration: '3 hours', rating: 4.6, students: 189 },
                    { id: 210, title: 'Drafting Basics', description: 'Technical drafting fundamentals', lessons: 7, duration: '3.5 hours', rating: 4.7, students: 223 },
                    { id: 211, title: 'Quality Control', description: 'Introduction to quality assurance', lessons: 6, duration: '3 hours', rating: 4.8, students: 156 },
                    { id: 212, title: 'Welding Basics', description: 'Introduction to welding', lessons: 8, duration: '4 hours', rating: 4.7, students: 178 },
                    { id: 213, title: 'Engineering Tools', description: 'Hand tools and measurement', lessons: 5, duration: '2.5 hours', rating: 4.6, students: 289 },
                    { id: 214, title: 'Technical Writing', description: 'Engineering reports and documentation', lessons: 6, duration: '3 hours', rating: 4.8, students: 145 },
                    { id: 215, title: 'Project Planning', description: 'Basic project management', lessons: 7, duration: '3.5 hours', rating: 4.7, students: 167 }
                ],
                intermediate: [
                    { id: 216, title: 'Dynamics', description: 'Kinematics and kinetics of machinery', lessons: 10, duration: '8 hours', rating: 4.8, students: 267 },
                    { id: 217, title: 'Thermodynamics', description: 'Heat, work, and energy systems', lessons: 12, duration: '10 hours', rating: 4.9, students: 312 },
                    { id: 218, title: 'Fluid Mechanics', description: 'Fluid behavior and hydraulics', lessons: 10, duration: '8 hours', rating: 4.7, students: 198 },
                    { id: 219, title: 'Strength of Materials', description: 'Stress, strain, and deformation', lessons: 11, duration: '9 hours', rating: 4.8, students: 234 },
                    { id: 220, title: 'Machine Design', description: 'Fundamentals of mechanical design', lessons: 10, duration: '8 hours', rating: 4.7, students: 189 },
                    { id: 221, title: 'Heat Transfer', description: 'Conduction, convection, radiation', lessons: 9, duration: '7 hours', rating: 4.8, students: 212 },
                    { id: 222, title: 'Vibrations', description: 'Mechanical vibration analysis', lessons: 10, duration: '8 hours', rating: 4.6, students: 156 },
                    { id: 223, title: 'CAD Advanced', description: 'Advanced CAD techniques', lessons: 11, duration: '9 hours', rating: 4.7, students: 223 },
                    { id: 224, title: 'Manufacturing Processes', description: 'CNC and manufacturing', lessons: 10, duration: '8 hours', rating: 4.8, students: 178 },
                    { id: 225, title: 'Finite Element Basics', description: 'Introduction to FEA', lessons: 9, duration: '7 hours', rating: 4.7, students: 145 },
                    { id: 226, title: 'Hydraulic Systems', description: 'Fluid power systems', lessons: 8, duration: '6 hours', rating: 4.8, students: 134 },
                    { id: 227, title: 'Pneumatic Systems', description: 'Air pressure systems', lessons: 7, duration: '5 hours', rating: 4.6, students: 123 },
                    { id: 228, title: 'Material Selection', description: 'Engineering material selection', lessons: 8, duration: '6 hours', rating: 4.7, students: 167 },
                    { id: 229, title: 'Quality Management', description: 'Six sigma and quality', lessons: 9, duration: '7 hours', rating: 4.8, students: 156 }
                ],
                advanced: [
                    { id: 230, title: 'Advanced Machine Design', description: 'Complex mechanical design', lessons: 15, duration: '12 hours', rating: 4.8, students: 123 },
                    { id: 231, title: 'Advanced Thermodynamics', description: 'Complex thermodynamic cycles', lessons: 14, duration: '11 hours', rating: 4.7, students: 89 },
                    { id: 232, title: 'Finite Element Analysis', description: 'FEA methods and applications', lessons: 16, duration: '14 hours', rating: 4.9, students: 76 },
                    { id: 233, title: 'Computational Fluid Dynamics', description: 'CFD simulation techniques', lessons: 14, duration: '12 hours', rating: 4.8, students: 67 },
                    { id: 234, title: 'Advanced Vibrations', description: 'Complex vibration analysis', lessons: 13, duration: '11 hours', rating: 4.7, students: 56 },
                    { id: 235, title: 'Rotordynamics', description: 'Rotor dynamics and balance', lessons: 12, duration: '10 hours', rating: 4.8, students: 45 },
                    { id: 236, title: 'Composite Materials', description: 'Advanced composite design', lessons: 11, duration: '9 hours', rating: 4.9, students: 78 },
                    { id: 237, title: 'Additive Manufacturing', description: '3D printing technologies', lessons: 10, duration: '8 hours', rating: 4.7, students: 123 },
                    { id: 238, title: 'Robotics', description: 'Industrial robot design', lessons: 13, duration: '11 hours', rating: 4.8, students: 156 },
                    { id: 239, title: 'Mechatronics', description: 'Mechanical-electronic systems', lessons: 12, duration: '10 hours', rating: 4.7, students: 89 },
                    { id: 240, title: 'Fatigue Analysis', description: 'Metal fatigue and life prediction', lessons: 11, duration: '9 hours', rating: 4.8, students: 67 },
                    { id: 241, title: 'Fracture Mechanics', description: 'Crack propagation analysis', lessons: 12, duration: '10 hours', rating: 4.9, students: 54 },
                    { id: 242, title: 'Tribology', description: 'Friction and wear engineering', lessons: 10, duration: '8 hours', rating: 4.6, students: 78 },
                    { id: 243, title: 'Biomechanics', description: 'Mechanical engineering in medicine', lessons: 11, duration: '9 hours', rating: 4.7, students: 89 },
                    { id: 244, title: 'Vehicle Dynamics', description: 'Automotive performance', lessons: 12, duration: '10 hours', rating: 4.8, students: 112 }
                ]
            },
            civil: {
                beginner: [
                    { id: 301, title: 'Introduction to Civil Engineering', description: 'Overview of civil engineering fields', lessons: 6, duration: '3 hours', rating: 4.6, students: 234 },
                    { id: 302, title: 'Surveying Basics', description: 'Land surveying techniques', lessons: 8, duration: '4 hours', rating: 4.7, students: 189 },
                    { id: 303, title: 'Construction Materials', description: 'Basic construction materials', lessons: 7, duration: '3.5 hours', rating: 4.8, students: 156 },
                    { id: 304, title: 'Building Codes', description: 'Introduction to building regulations', lessons: 6, duration: '3 hours', rating: 4.5, students: 145 },
                    { id: 305, title: 'Blueprint Reading', description: 'Understanding construction drawings', lessons: 7, duration: '3.5 hours', rating: 4.7, students: 198 },
                    { id: 306, title: 'Site Preparation', description: 'Construction site basics', lessons: 6, duration: '3 hours', rating: 4.6, students: 134 },
                    { id: 307, title: 'Concrete Basics', description: 'Introduction to concrete', lessons: 8, duration: '4 hours', rating: 4.7, students: 167 },
                    { id: 308, title: 'Foundation Types', description: 'Basic foundation systems', lessons: 6, duration: '3 hours', rating: 4.8, students: 156 },
                    { id: 309, title: 'Structural Loads', description: 'Understanding load types', lessons: 7, duration: '3.5 hours', rating: 4.6, students: 189 },
                    { id: 310, title: 'Construction Safety', description: 'Site safety practices', lessons: 6, duration: '3 hours', rating: 4.7, students: 212 },
                    { id: 311, title: 'Materials Testing', description: 'Basic material testing', lessons: 7, duration: '3.5 hours', rating: 4.6, students: 145 },
                    { id: 312, title: 'Cost Estimation', description: 'Basic cost estimating', lessons: 8, duration: '4 hours', rating: 4.7, students: 167 }
                ],
                intermediate: [
                    { id: 313, title: 'Structural Analysis', description: 'Analysis of structures and loads', lessons: 12, duration: '10 hours', rating: 4.8, students: 267 },
                    { id: 314, title: 'Concrete Technology', description: 'Concrete mix design and testing', lessons: 10, duration: '8 hours', rating: 4.7, students: 198 },
                    { id: 315, title: 'Foundation Engineering', description: 'Shallow and deep foundations', lessons: 10, duration: '8 hours', rating: 4.9, students: 145 },
                    { id: 316, title: 'Steel Structures', description: 'Steel member design', lessons: 11, duration: '9 hours', rating: 4.8, students: 176 },
                    { id: 317, title: 'Reinforced Concrete', description: 'RC design principles', lessons: 12, duration: '10 hours', rating: 4.7, students: 189 },
                    { id: 318, title: 'Structural Mechanics', description: 'Advanced structural analysis', lessons: 12, duration: '10 hours', rating: 4.8, students: 156 },
                    { id: 319, title: 'Geotechnical Engineering', description: 'Soil mechanics and foundations', lessons: 11, duration: '9 hours', rating: 4.7, students: 134 },
                    { id: 320, title: 'Bridge Basics', description: 'Introduction to bridge design', lessons: 10, duration: '8 hours', rating: 4.8, students: 123 },
                    { id: 321, title: 'Construction Management', description: 'Project management for construction', lessons: 11, duration: '9 hours', rating: 4.6, students: 145 },
                    { id: 322, title: 'Highway Engineering', description: 'Road design and construction', lessons: 10, duration: '8 hours', rating: 4.7, students: 112 },
                    { id: 323, title: 'Water Resources', description: 'Hydraulic engineering', lessons: 10, duration: '8 hours', rating: 4.8, students: 98 },
                    { id: 324, title: 'Earthquake Basics', description: 'Introduction to seismic design', lessons: 9, duration: '7 hours', rating: 4.7, students: 134 }
                ],
                advanced: [
                    { id: 325, title: 'Advanced Steel Design', description: 'Steel structures and connections', lessons: 14, duration: '12 hours', rating: 4.8, students: 98 },
                    { id: 326, title: 'Bridge Engineering', description: 'Design and analysis of bridges', lessons: 12, duration: '10 hours', rating: 4.7, students: 76 },
                    { id: 327, title: 'Earthquake Engineering', description: 'Seismic design and analysis', lessons: 14, duration: '11 hours', rating: 4.9, students: 65 },
                    { id: 328, title: 'Advanced Concrete', description: 'Prestressed concrete design', lessons: 13, duration: '11 hours', rating: 4.8, students: 78 },
                    { id: 329, title: 'Tall Building Design', description: 'High-rise structural systems', lessons: 12, duration: '10 hours', rating: 4.7, students: 89 },
                    { id: 330, title: 'Finite Element Methods', description: 'Advanced FEA techniques', lessons: 14, duration: '12 hours', rating: 4.8, students: 67 },
                    { id: 331, title: 'Structural Dynamics', description: 'Dynamic load analysis', lessons: 12, duration: '10 hours', rating: 4.9, students: 54 },
                    { id: 332, title: 'Bridge Loads', description: 'Live load analysis for bridges', lessons: 10, duration: '8 hours', rating: 4.6, students: 45 },
                    { id: 333, title: 'Foundation Engineering', description: 'Advanced foundation design', lessons: 12, duration: '10 hours', rating: 4.7, students: 67 },
                    { id: 334, title: 'Structural Stability', description: 'Buckling and stability analysis', lessons: 11, duration: '9 hours', rating: 4.8, students: 56 },
                    { id: 335, title: 'Prestressed Concrete', description: 'Pre-stressing techniques', lessons: 12, duration: '10 hours', rating: 4.9, students: 67 },
                    { id: 336, title: 'Shell Structures', description: 'Thin shell design', lessons: 10, duration: '8 hours', rating: 4.7, students: 45 },
                    { id: 337, title: 'Structural Health Monitoring', description: 'Condition assessment', lessons: 10, duration: '8 hours', rating: 4.8, students: 78 },
                    { id: 338, title: 'Construction Technology', description: 'Modern construction methods', lessons: 11, duration: '9 hours', rating: 4.6, students: 89 }
                ]
            },
            software: {
                beginner: [
                    { id: 401, title: 'Introduction to Programming', description: 'Programming basics with Python', lessons: 10, duration: '5 hours', rating: 4.9, students: 567 },
                    { id: 402, title: 'HTML & CSS Basics', description: 'Web development fundamentals', lessons: 8, duration: '4 hours', rating: 4.8, students: 445 },
                    { id: 403, title: 'Problem Solving', description: 'Algorithm thinking and logic', lessons: 6, duration: '3 hours', rating: 4.7, students: 312 },
                    { id: 404, title: 'Python Fundamentals', description: 'Basic Python programming', lessons: 10, duration: '5 hours', rating: 4.8, students: 423 },
                    { id: 405, title: 'Web Development Intro', description: 'Introduction to web development', lessons: 8, duration: '4 hours', rating: 4.7, students: 389 },
                    { id: 406, title: 'Data Types & Variables', description: 'Understanding data in programming', lessons: 7, duration: '3.5 hours', rating: 4.8, students: 356 },
                    { id: 407, title: 'Control Flow', description: 'If statements and loops', lessons: 8, duration: '4 hours', rating: 4.7, students: 298 },
                    { id: 408, title: 'Functions Basics', description: 'Creating reusable code', lessons: 7, duration: '3.5 hours', rating: 4.8, students: 345 },
                    { id: 409, title: 'Debugging', description: 'Finding and fixing errors', lessons: 6, duration: '3 hours', rating: 4.6, students: 267 },
                    { id: 410, title: 'Version Control', description: 'Git and GitHub basics', lessons: 7, duration: '3.5 hours', rating: 4.9, students: 423 },
                    { id: 411, title: 'Command Line', description: 'Terminal and command line basics', lessons: 6, duration: '3 hours', rating: 4.7, students: 234 },
                    { id: 412, title: 'API Concepts', description: 'Introduction to APIs', lessons: 7, duration: '3.5 hours', rating: 4.8, students: 312 },
                    { id: 413, title: 'Database Basics', description: 'Introduction to databases', lessons: 8, duration: '4 hours', rating: 4.6, students: 289 }
                ],
                intermediate: [
                    { id: 414, title: 'JavaScript & Web Development', description: 'Interactive web applications', lessons: 12, duration: '10 hours', rating: 4.9, students: 423 },
                    { id: 415, title: 'Database Design', description: 'SQL and database fundamentals', lessons: 10, duration: '8 hours', rating: 4.8, students: 298 },
                    { id: 416, title: 'Data Structures', description: 'Arrays, lists, trees, and graphs', lessons: 14, duration: '12 hours', rating: 4.9, students: 345 },
                    { id: 417, title: 'Algorithms', description: 'Sorting, searching, and optimization', lessons: 12, duration: '10 hours', rating: 4.8, students: 289 },
                    { id: 418, title: 'React Development', description: 'React.js framework', lessons: 12, duration: '10 hours', rating: 4.7, students: 267 },
                    { id: 419, title: 'Node.js Backend', description: 'Server-side JavaScript', lessons: 11, duration: '9 hours', rating: 4.8, students: 234 },
                    { id: 420, title: 'SQL & Databases', description: 'Advanced database queries', lessons: 10, duration: '8 hours', rating: 4.9, students: 256 },
                    { id: 421, title: 'REST APIs', description: 'Building RESTful services', lessons: 10, duration: '8 hours', rating: 4.7, students: 223 },
                    { id: 422, title: 'Authentication', description: 'User auth and security', lessons: 9, duration: '7 hours', rating: 4.8, students: 245 },
                    { id: 423, title: 'Testing', description: 'Unit and integration testing', lessons: 10, duration: '8 hours', rating: 4.7, students: 198 },
                    { id: 424, title: 'Git Workflows', description: 'Advanced Git techniques', lessons: 8, duration: '6 hours', rating: 4.8, students: 267 },
                    { id: 425, title: 'Cloud Basics', description: 'Introduction to cloud computing', lessons: 9, duration: '7 hours', rating: 4.6, students: 234 }
                ],
                advanced: [
                    { id: 426, title: 'Backend Development', description: 'Server-side programming with Node.js', lessons: 16, duration: '14 hours', rating: 4.8, students: 234 },
                    { id: 427, title: 'System Design', description: 'Large-scale system architecture', lessons: 12, duration: '10 hours', rating: 4.9, students: 189 },
                    { id: 428, title: 'DevOps & Cloud', description: 'CI/CD and cloud platforms', lessons: 14, duration: '12 hours', rating: 4.7, students: 156 },
                    { id: 429, title: 'Microservices', description: 'Microservice architecture', lessons: 14, duration: '12 hours', rating: 4.8, students: 134 },
                    { id: 430, title: 'Kubernetes', description: 'Container orchestration', lessons: 12, duration: '10 hours', rating: 4.9, students: 123 },
                    { id: 431, title: 'AWS Services', description: 'Amazon Web Services', lessons: 14, duration: '12 hours', rating: 4.7, students: 145 },
                    { id: 432, title: 'Machine Learning', description: 'ML fundamentals for developers', lessons: 14, duration: '12 hours', rating: 4.8, students: 234 },
                    { id: 433, title: 'Data Engineering', description: 'Big data processing', lessons: 12, duration: '10 hours', rating: 4.7, students: 156 },
                    { id: 434, title: 'GraphQL', description: 'GraphQL API development', lessons: 10, duration: '8 hours', rating: 4.8, students: 112 },
                    { id: 435, title: 'WebSockets', description: 'Real-time web communication', lessons: 8, duration: '6 hours', rating: 4.9, students: 98 },
                    { id: 436, title: 'Graph Databases', description: 'Neo4j and graph theory', lessons: 10, duration: '8 hours', rating: 4.7, students: 89 },
                    { id: 437, title: 'Containerization', description: 'Docker and containers', lessons: 11, duration: '9 hours', rating: 4.8, students: 145 },
                    { id: 438, title: 'Security Engineering', description: 'Application security', lessons: 12, duration: '10 hours', rating: 4.9, students: 178 },
                    { id: 439, title: 'Performance Optimization', description: 'Speed and scalability', lessons: 11, duration: '9 hours', rating: 4.7, students: 123 },
                    { id: 440, title: 'Distributed Systems', description: 'System architecture patterns', lessons: 12, duration: '10 hours', rating: 4.8, students: 89 }
                ]
            }
        };
    },
    
    // Get courses by field and level
    getCourses: function(field, level) {
        const allCourses = this.getAllCourses();
        return allCourses[field]?.[level] || [];
    },
    
    // Get all courses (flattened)
    getAllCoursesFlat: function() {
        const allCourses = this.getAllCourses();
        let flat = [];
        
        Object.keys(allCourses).forEach(field => {
            Object.keys(allCourses[field]).forEach(level => {
                allCourses[field][level].forEach(course => {
                    flat.push({ ...course, field, level });
                });
            });
        });
        
        return flat;
    },
    
    // Get user's selected learning path
    getUserLearningPath: function() {
        const user = window.AuthAPI?.getUser();
        if (!user) return { field: 'electrical', level: 'beginner' };
        
        const path = localStorage.getItem('enh_learning_path');
        return path ? JSON.parse(path) : { field: user.field || 'electrical', level: 'beginner' };
    },
    
    // Save user's learning path
    saveLearningPath: function(field, level) {
        const path = { field, level };
        localStorage.setItem('enh_learning_path', JSON.stringify(path));
        
        // Update user field if not set
        const user = window.AuthAPI?.getUser();
        if (user && !user.field) {
            user.field = field;
            localStorage.setItem('enh_user', JSON.stringify(user));
        }
    },
    
    // Get course by ID with full details
    getCourseDetails: function(courseId) {
        const allCourses = this.getAllCoursesFlat();
        const course = allCourses.find(c => c.id === courseId);
        if (!course) return null;
        
        // Real educational YouTube video IDs for each field
        const videoIds = {
            // Electrical Engineering
            electrical: {
                beginner: [
                    { id: 'uJ_8HMkHF1U', title: 'Introduction to Electricity' },
                    { id: 'FM7X7q8VrjE', title: 'Voltage Current Resistance' },
                    { id: '9-6p3rJr2M4', title: 'Ohms Law Explained' },
                    { id: 'VxsgnL4Wy7w', title: 'Series Circuits' },
                    { id: '8XDq5a6rPmM', title: 'Parallel Circuits' },
                    { id: 'CQacCALqaH0', title: 'Electrical Safety' },
                    { id: 'X4TB3bftcC8', title: 'Circuit Basics' },
                    { id: 'sK6FKQ2B3b4', title: 'Power and Energy' }
                ],
                intermediate: [
                    { id: 'MKmMxjYo3HQ', title: 'Kirchhoffs Laws' },
                    { id: 'lccmJ1L4GlU', title: 'Network Analysis' },
                    { id: 'J5sC1cW0u4M', title: 'AC Circuit Theory' },
                    { id: 'Z97s7J4Yy6c', title: 'Impedance' },
                    { id: 'Y0M-8sWz3Q', title: 'Power Factor' },
                    { id: 'N0hS2l2J6kE', title: 'Transformers' }
                ],
                advanced: [
                    { id: 'QO4w1J7_y0M', title: 'Semiconductor Physics' },
                    { id: 'bQrLx2aB6jE', title: 'Transistor Theory' },
                    { id: 'nL4E2c5L3qQ', title: 'Operational Amplifiers' },
                    { id: 'kN33Q6c4dG8', title: 'Control Systems' },
                    { id: 'hJ4N_m7F2nE', title: 'Power Electronics' }
                ]
            },
            // Mechanical Engineering
            mechanical: {
                beginner: [
                    { id: 'rF4K4t2z1fA', title: 'Engineering Drawing' },
                    { id: 'W6Cpvm1N5d0', title: 'Statics Fundamentals' },
                    { id: 'f4pXk3YFH4E', title: 'Force Analysis' },
                    { id: 'uJ_8HMkHF1U', title: 'Materials Science' },
                    { id: '1xJz1-0N1cQ', title: 'CAD Basics' },
                    { id: 'pX7p8-2q3Rw', title: 'Thermodynamics Intro' },
                    { id: 'Mk1fN4E5Y6Q', title: 'Fluid Mechanics' },
                    { id: 'rfMi9bF4yT8', title: 'Machine Tools' }
                ],
                intermediate: [
                    { id: 'rF4K4t2z1fA', title: 'Kinematics' },
                    { id: 'W6Cpvm1N5d0', title: 'Kinetics' },
                    { id: 'f4pXk3YFH4E', title: 'Work and Energy' },
                    { id: 'uJ_8HMkHF1U', title: 'Heat Transfer' },
                    { id: '1xJz1-0N1cQ', title: 'Fluid Dynamics' },
                    { id: 'pX7p8-2q3Rw', title: 'Strength of Materials' }
                ],
                advanced: [
                    { id: 'Mk1fN4E5Y6Q', title: 'Finite Element Analysis' },
                    { id: 'rfMi9bF4yT8', title: 'Vibration Analysis' },
                    { id: 'SF4aHwxHtZ0', title: 'Advanced Thermodynamics' },
                    { id: 'OK_qI8N2bEU', title: 'Computational Fluid Dynamics' },
                    { id: 'rfMi9bF4yT8', title: 'Advanced Machine Design' }
                ]
            },
            // Civil Engineering
            civil: {
                beginner: [
                    { id: 'VxsgnL4Wy7w', title: 'Introduction to Civil Engineering' },
                    { id: 'FM7X7q8VrjE', title: 'Structural Analysis' },
                    { id: '9-6p3rJr2M4', title: 'Concrete Technology' },
                    { id: 'VxsgnL4Wy7w', title: 'Steel Structures' },
                    { id: '8XDq5a6rPmM', title: 'Foundation Engineering' },
                    { id: 'CQacCALqaH0', title: 'Surveying' },
                    { id: 'X4TB3bftcC8', title: 'Building Materials' },
                    { id: 'sK6FKQ2B3b4', title: 'Construction Methods' }
                ],
                intermediate: [
                    { id: 'MKmMxjYo3HQ', title: 'Structural Design' },
                    { id: 'lccmJ1L4GlU', title: 'Steel Design' },
                    { id: 'J5sC1cW0u4M', title: 'Concrete Design' },
                    { id: 'Z97s7J4Yy6c', title: 'Geotechnical Engineering' },
                    { id: 'Y0M-8sWz3Q', title: 'Hydraulics' },
                    { id: 'N0hS2l2J6kE', title: 'Highway Engineering' }
                ],
                advanced: [
                    { id: 'QO4w1J7_y0M', title: 'Bridge Engineering' },
                    { id: 'bQrLx2aB6jE', title: 'Earthquake Engineering' },
                    { id: 'nL4E2c5L3qQ', title: 'Advanced Structural Analysis' },
                    { id: 'kN33Q6c4dG8', title: 'Foundation Design' },
                    { id: 'hJ4N_m7F2nE', title: 'Construction Management' }
                ]
            },
            // Software Engineering
            software: {
                beginner: [
                    { id: 'OK_qI8N2bEU', title: 'Programming Fundamentals' },
                    { id: 'SF4aHwxHtZ0', title: 'Python Basics' },
                    { id: 'rfMi9bF4yT8', title: 'JavaScript Introduction' },
                    { id: 'Mk1fN4E5Y6Q', title: 'HTML CSS Basics' },
                    { id: 'pX7p8-2q3Rw', title: 'Data Structures' },
                    { id: '1xJz1-0N1cQ', title: 'Algorithms' },
                    { id: 'f4pXk3YFH4E', title: 'Web Development' },
                    { id: 'W6Cpvm1N5d0', title: 'Database Basics' }
                ],
                intermediate: [
                    { id: 'rF4K4t2z1fA', title: 'Object Oriented Programming' },
                    { id: 'uJ_8HMkHF1U', title: 'Software Design' },
                    { id: 'X4TB3bftcC8', title: 'Web APIs' },
                    { id: 'sK6FKQ2B3b4', title: 'React Development' },
                    { id: '8XDq5a6rPmM', title: 'Node.js Backend' },
                    { id: 'VxsgnL4Wy7w', title: 'Database Design' }
                ],
                advanced: [
                    { id: 'FM7X7q8VrjE', title: 'Machine Learning' },
                    { id: '9-6p3rJr2M4', title: 'DevOps Practices' },
                    { id: 'CQacCALqaH0', title: 'Cloud Computing' },
                    { id: 'X4TB3bftcC8', title: 'System Design' },
                    { id: 'sK6FKQ2B3b4', title: 'Microservices' }
                ]
            }
        };
        
        // Somali language video IDs
        window.SomaliVideos = {
            electrical: {
                beginner: [{ id: 'uJ_8HMkHF1U', title: 'Electricity Basics (SO)' }, { id: 'FM7X7q8VrjE', title: 'Voltage & Current (SO)' }],
                intermediate: [{ id: 'MKmMxjYo3HQ', title: 'Circuit Analysis (SO)' }],
                advanced: [{ id: 'QO4w1J7_y0M', title: 'Semiconductors (SO)' }]
            },
            mechanical: {
                beginner: [{ id: 'W6Cpvm1N5d0', title: 'Statics (SO)' }, { id: 'f4pXk3YFH4E', title: 'Forces (SO)' }],
                intermediate: [{ id: 'rF4K4t2z1fA', title: 'Kinematics (SO)' }],
                advanced: [{ id: 'Mk1fN4E5Y6Q', title: 'FEA (SO)' }]
            },
            civil: {
                beginner: [{ id: 'VxsgnL4Wy7w', title: 'Civil Intro (SO)' }, { id: 'FM7X7q8VrjE', title: 'Structures (SO)' }],
                intermediate: [{ id: 'MKmMxjYo3HQ', title: 'Design (SO)' }],
                advanced: [{ id: 'QO4w1J7_y0M', title: 'Bridges (SO)' }]
            },
            software: {
                beginner: [{ id: 'OK_qI8N2bEU', title: 'Programming (SO)' }, { id: 'SF4aHwxHtZ0', title: 'Python (SO)' }],
                intermediate: [{ id: 'rF4K4t2z1fA', title: 'OOP (SO)' }],
                advanced: [{ id: 'FM7X7q8VrjE', title: 'ML (SO)' }]
            }
        };
        
        const lang = localStorage.getItem('enh_language') || 'en';
        let fieldVideos = videoIds[course.field]?.[course.level] || [];
        
        // For Somali language users, try to get Somali videos if available
        if (lang === 'so' && window.SomaliVideos && window.SomaliVideos[course.field]?.[course.level]) {
            fieldVideos = window.SomaliVideos[course.field][course.level];
        }
        
        course.videoId = fieldVideos[courseId % fieldVideos.length]?.id || 'uJ_8HMkHF1U';
        
        // Get lessons for this course
        course.lessons = this.getLessons(course.field, course.level);
        course.quiz = this.getQuiz(course.field);
        return course;
    },
    
    // Get lessons by field and level
    getLessons: function(field, level) {
        const lessonsData = {
            electrical: {
                beginner: [
                    { id: 1, title: 'Introduction to Electricity', duration: '15 min', completed: false, content: 'Electricity is the flow of electric charge. It powers our homes, schools, and businesses. In this lesson, we learn about the basic concepts of electricity including atoms, electrons, and electric fields.', video: 'https://www.youtube.com/embed/dQw4w9WgXcQ' },
                    { id: 2, title: 'Voltage and Current', duration: '20 min', completed: false, content: 'Voltage (V) is the potential difference that pushes electric current. Current (I) is the flow of electrons. Learn how they relate and are measured.', video: 'https://www.youtube.com/embed/dQw4w9WgXcQ' },
                    { id: 3, title: 'Resistance and Conductors', duration: '20 min', completed: false, content: 'Resistance (R) is opposition to current flow. Conductors allow current, insulators resist it. Learn about Ohm\'s Law: V = IR.', video: 'https://www.youtube.com/embed/dQw4w9WgXcQ' },
                    { id: 4, title: 'Ohm\'s Law Explained', duration: '25 min', completed: false, content: 'Ohm\'s Law is the fundamental relationship between voltage, current, and resistance. Master this law to analyze any circuit.', video: 'https://www.youtube.com/embed/dQw4w9WgXcQ' },
                    { id: 5, title: 'Series Circuits', duration: '20 min', completed: false, content: 'In series circuits, current flows through each component sequentially. Total resistance is the sum of individual resistances.', video: 'https://www.youtube.com/embed/dQw4w9WgXcQ' },
                    { id: 6, title: 'Parallel Circuits', duration: '25 min', completed: false, content: 'In parallel circuits, current splits across branches. Each branch has the same voltage across it.', video: 'https://www.youtube.com/embed/dQw4w9WgXcQ' }
                ],
                intermediate: [
                    { id: 1, title: 'Network Theorems', duration: '30 min', completed: false, content: 'Learn Superposition, Thevenin\'s, and Norton\'s theorems for circuit analysis.', video: 'https://www.youtube.com/embed/dQw4w9WgXcQ' },
                    { id: 2, title: 'Kirchhoff\'s Laws', duration: '25 min', completed: false, content: 'Kirchhoff\'s Current and Voltage Laws are essential for complex circuit analysis.', video: 'https://www.youtube.com/embed/dQw4w9WgXcQ' },
                    { id: 3, title: 'AC Fundamentals', duration: '30 min', completed: false, content: 'Alternating current (AC) vs Direct Current (DC). Learn about frequency, amplitude, and phase.', video: 'https://www.youtube.com/embed/dQw4w9WgXcQ' },
                    { id: 4, title: 'Impedance', duration: '25 min', completed: false, content: 'Impedance combines resistance and reactance in AC circuits. Learn about capacitive and inductive reactance.', video: 'https://www.youtube.com/embed/dQw4w9WgXcQ' },
                    { id: 5, title: 'Power in AC Circuits', duration: '25 min', completed: false, content: 'Real, reactive, and apparent power. Power factor and its importance in power systems.', video: 'https://www.youtube.com/embed/dQw4w9WgXcQ' },
                    { id: 6, title: 'Resonance', duration: '20 min', completed: false, content: 'Series and parallel resonance in AC circuits. Q factor and bandwidth.', video: 'https://www.youtube.com/embed/dQw4w9WgXcQ' }
                ],
                advanced: [
                    { id: 1, title: 'Semiconductor Physics', duration: '35 min', completed: false, content: 'Deep dive into semiconductor materials, doping, and PN junctions.', video: 'https://www.youtube.com/embed/dQw4w9WgXcQ' },
                    { id: 2, title: 'Transistor Theory', duration: '40 min', completed: false, content: 'BJT and MOSFET operation, characteristics, and biasing.', video: 'https://www.youtube.com/embed/dQw4w9WgXcQ' },
                    { id: 3, title: 'Amplifier Design', duration: '45 min', completed: false, content: 'Design and analysis of common amplifier configurations.', video: 'https://www.youtube.com/embed/dQw4w9WgXcQ' },
                    { id: 4, title: 'Feedback Theory', duration: '35 min', completed: false, content: 'Negative and positive feedback, stability, and oscillation.', video: 'https://www.youtube.com/embed/dQw4w9WgXcQ' },
                    { id: 5, title: 'Operational Amplifiers', duration: '40 min', completed: false, content: 'Op-amp configurations, specifications, and applications.', video: 'https://www.youtube.com/embed/dQw4w9WgXcQ' }
                ]
            },
            mechanical: {
                beginner: [
                    { id: 1, title: 'Engineering Drawing', duration: '20 min', completed: false, content: 'Introduction to technical drawings, symbols, and conventions.', video: 'https://www.youtube.com/embed/dQw4w9WgXcQ' },
                    { id: 2, title: 'Force Vectors', duration: '25 min', completed: false, content: 'Understanding forces as vectors, addition and resolution.', video: 'https://www.youtube.com/embed/dQw4w9WgXcQ' },
                    { id: 3, title: 'Equilibrium', duration: '25 min', completed: false, content: 'Conditions for static equilibrium in mechanical systems.', video: 'https://www.youtube.com/embed/dQw4w9WgXcQ' }
                ],
                intermediate: [
                    { id: 1, title: 'Kinematics', duration: '30 min', completed: false, content: 'Motion analysis without considering forces. Displacement, velocity, acceleration.', video: 'https://www.youtube.com/embed/dQw4w9WgXcQ' },
                    { id: 2, title: 'Kinetics', duration: '35 min', completed: false, content: 'Relationship between motion and forces. Newton\'s laws application.', video: 'https://www.youtube.com/embed/dQw4w9WgXcQ' },
                    { id: 3, title: 'Work and Energy', duration: '30 min', completed: false, content: 'Work, kinetic energy, potential energy, and power.', video: 'https://www.youtube.com/embed/dQw4w9WgXcQ' }
                ],
                advanced: [
                    { id: 1, title: 'Fatigue Analysis', duration: '40 min', completed: false, content: 'S-N curves, endurance limit, and fatigue life prediction.', video: 'https://www.youtube.com/embed/dQw4w9WgXcQ' },
                    { id: 2, title: 'Fracture Mechanics', duration: '45 min', completed: false, content: 'Crack propagation, stress intensity factors, and fracture toughness.', video: 'https://www.youtube.com/embed/dQw4w9WgXcQ' },
                    { id: 3, title: 'FEA Methods', duration: '50 min', completed: false, content: 'Finite element analysis theory and applications.', video: 'https://www.youtube.com/embed/dQw4w9WgXcQ' }
                ]
            },
            civil: {
                beginner: [
                    { id: 1, title: 'Civil Engineering Overview', duration: '20 min', completed: false, content: 'Introduction to civil engineering disciplines and careers.', video: 'https://www.youtube.com/embed/dQw4w9WgXcQ' },
                    { id: 2, title: 'Load Types', duration: '25 min', completed: false, content: 'Dead loads, live loads, environmental loads.', video: 'https://www.youtube.com/embed/dQw4w9WgXcQ' },
                    { id: 3, title: 'Structural Systems', duration: '25 min', completed: false, content: 'Beams, columns, trusses, and frames.', video: 'https://www.youtube.com/embed/dQw4w9WgXcQ' }
                ],
                intermediate: [
                    { id: 1, title: 'Stress and Strain', duration: '30 min', completed: false, content: 'Axial stress, shear stress, and strain relationships.', video: 'https://www.youtube.com/embed/dQw4w9WgXcQ' },
                    { id: 2, title: 'Bending Theory', duration: '35 min', completed: false, content: 'Bending moment, shear force, and bending stress.', video: 'https://www.youtube.com/embed/dQw4w9WgXcQ' },
                    { id: 3, title: 'Deflection', duration: '30 min', completed: false, content: 'Beam deflection methods and calculations.', video: 'https://www.youtube.com/embed/dQw4w9WgXcQ' }
                ],
                advanced: [
                    { id: 1, title: 'Seismic Design', duration: '40 min', completed: false, content: 'Earthquake-resistant design principles.', video: 'https://www.youtube.com/embed/dQw4w9WgXcQ' },
                    { id: 2, title: 'Bridge Design', duration: '45 min', completed: false, content: 'Types of bridges and design considerations.', video: 'https://www.youtube.com/embed/dQw4w9WgXcQ' },
                    { id: 3, title: ' Tall Building Design', duration: '50 min', completed: false, content: 'Lateral load resistance in high-rise structures.', video: 'https://www.youtube.com/embed/dQw4w9WgXcQ' }
                ]
            },
            software: {
                beginner: [
                    { id: 1, title: 'What is Programming?', duration: '15 min', completed: false, content: 'Introduction to programming concepts and logic.', video: 'https://www.youtube.com/embed/dQw4w9WgXcQ' },
                    { id: 2, title: 'Variables and Data Types', duration: '20 min', completed: false, content: 'Understanding variables, integers, floats, strings, and booleans.', video: 'https://www.youtube.com/embed/dQw4w9WgXcQ' },
                    { id: 3, title: 'Control Flow', duration: '25 min', completed: false, content: 'If statements, loops, and decision making in code.', video: 'https://www.youtube.com/embed/dQw4w9WgXcQ' },
                    { id: 4, title: 'Functions', duration: '25 min', completed: false, content: 'Writing and calling functions, parameters, and return values.', video: 'https://www.youtube.com/embed/dQw4w9WgXcQ' }
                ],
                intermediate: [
                    { id: 1, title: 'Object-Oriented Programming', duration: '35 min', completed: false, content: 'Classes, objects, inheritance, and polymorphism.', video: 'https://www.youtube.com/embed/dQw4w9WgXcQ' },
                    { id: 2, title: 'Arrays and Lists', duration: '30 min', completed: false, content: 'Data structures for storing collections.', video: 'https://www.youtube.com/embed/dQw4w9WgXcQ' },
                    { id: 3, title: 'Algorithms', duration: '40 min', completed: false, content: 'Sorting, searching, and complexity analysis.', video: 'https://www.youtube.com/embed/dQw4w9WgXcQ' }
                ],
                advanced: [
                    { id: 1, title: 'System Architecture', duration: '45 min', completed: false, content: 'Designing scalable software systems.', video: 'https://www.youtube.com/embed/dQw4w9WgXcQ' },
                    { id: 2, title: 'Database Design', duration: '40 min', completed: false, content: 'Normalization, indexing, and optimization.', video: 'https://www.youtube.com/embed/dQw4w9WgXcQ' },
                    { id: 3, title: 'Security Best Practices', duration: '35 min', completed: false, content: 'OWASP, encryption, and secure coding.', video: 'https://www.youtube.com/embed/dQw4w9WgXcQ' }
                ]
            }
        };
        
        return lessonsData[field]?.[level] || lessonsData.electrical.beginner;
    },
    
    // Get quiz for a course
    getQuiz: function(field) {
        const quizzes = {
            electrical: [
                { q: 'What is Ohm\'s Law?', options: ['V = IR', 'V = I/R', 'V = I + R', 'V = I - R'], correct: 0 },
                { q: 'Unit of resistance?', options: ['Volt', 'Ampere', 'Ohm', 'Watt'], correct: 2 },
                { q: 'In series circuits, current is:', options: ['Same everywhere', 'Different', 'Zero', 'Maximum'], correct: 0 },
                { q: 'Power formula is:', options: ['P = V/I', 'P = VI', 'P = V²/R', 'All of above'], correct: 3 },
                { q: 'Capacitor blocks:', options: ['AC', 'DC', 'Both', 'Neither'], correct: 1 },
                { q: 'LED stands for:', options: ['Light Emitting Diode', 'Low Energy Display', 'Linear Electronic Diode', 'Light Energy Device'], correct: 0 },
                { q: 'Transistor is used as:', options: ['Switch only', 'Amplifier only', 'Both', 'Neither'], correct: 2 }
            ],
            mechanical: [
                { q: 'Newton\'s first law is also called:', options: ['Law of acceleration', 'Law of inertia', 'Law of action-reaction', 'Law of momentum'], correct: 1 },
                { q: 'Unit of force is:', options: ['Joule', 'Watt', 'Newton', 'Pascal'], correct: 2 },
                { q: 'Stress is defined as:', options: ['Force/Volume', 'Force/Area', 'Mass/Volume', 'Energy/Time'], correct: 1 },
                { q: 'Kinetic energy formula is:', options: ['mv', 'mg', '½mv²', 'mgh'], correct: 2 },
                { q: 'Simple machine example:', options: ['Computer', 'Lever', 'Engine', 'Turbine'], correct: 1 }
            ],
            civil: [
                { q: 'Concrete mainly consists of:', options: ['Cement, sand, water', 'Steel, wood, glass', 'Sand, gravel, plastic', 'Cement, steel, aluminum'], correct: 0 },
                { q: 'Dead load refers to:', options: ['Variable load', 'Permanent load', 'Live load', 'Wind load'], correct: 1 },
                { q: 'RCC stands for:', options: ['Reinforced Cement Concrete', 'Regular Concrete', 'Rapid Concrete', 'Reinforced Composite Concrete'], correct: 0 },
                { q: 'Moment of inertia measures:', options: ['Strength', 'Stiffness', 'Hardness', 'Density'], correct: 1 },
                { q: 'Foundation transfers:', options: ['Water', 'Load to soil', 'Air', 'Heat'], correct: 1 }
            ],
            software: [
                { q: 'Variable stores:', options: ['Code', 'Data', 'Images', 'Videos'], correct: 1 },
                { q: 'Loop is used for:', options: ['Storage', 'Repetition', 'Decision', 'Input'], correct: 1 },
                { q: 'Array index starts from:', options: ['1', '0', '-1', 'Any'], correct: 1 },
                { q: 'OOP stands for:', options: ['Online Programming', 'Object-Oriented Programming', 'Ordered Operations', 'Output Programming'], correct: 1 },
                { q: 'Function is:', options: ['Data type', 'Reusable code block', 'Variable', 'Loop'], correct: 1 }
            ]
        };
        
        return quizzes[field] || quizzes.electrical;
    },
    
    // Get user progress for a course
    getProgress: function(courseId) {
        const user = window.AuthAPI?.getUser();
        if (!user) return 0;
        
        const progress = JSON.parse(localStorage.getItem('enh_progress') || '[]');
        const entry = progress.find(p => p.courseId === courseId && p.userId === user.id);
        return entry ? entry.progress : 0;
    },
    
    // Calculate user level based on progress
    getUserLevel: function() {
        const user = window.AuthAPI?.getUser();
        if (!user) return 'Beginner';
        
        const enrollments = JSON.parse(localStorage.getItem('enh_enrollments') || '[]');
        const userEnrollments = enrollments.filter(e => e.userId === user.id);
        
        let totalProgress = 0;
        userEnrollments.forEach(e => {
            totalProgress += e.progress || 0;
        });
        
        const avgProgress = userEnrollments.length > 0 ? totalProgress / userEnrollments.length : 0;
        
        if (avgProgress >= 80) return 'Advanced';
        if (avgProgress >= 40) return 'Intermediate';
        return 'Beginner';
    },
    
    // Mark lesson complete
    completeLesson: function(courseId, lessonId) {
        const user = window.AuthAPI?.getUser();
        if (!user) {
            window.showToast('Please login to track progress', 'warning');
            return;
        }
        
        let progress = JSON.parse(localStorage.getItem('enh_progress') || '[]');
        
        // Check if already completed
        const existing = progress.find(p => p.courseId === courseId && p.lessonId === lessonId && p.userId === user.id);
        if (existing) {
            window.showToast('Lesson already completed', 'info');
            return;
        }
        
        // Add completion
        progress.push({
            courseId: courseId,
            lessonId: lessonId,
            userId: user.id,
            completed: true,
            completedAt: new Date().toISOString()
        });
        
        // Update course progress
        this.updateCourseProgress(courseId, user.id);
        
        localStorage.setItem('enh_progress', JSON.stringify(progress));
        window.showToast('Lesson completed!', 'success');
    },
    
    // Update overall course progress
    updateCourseProgress: function(courseId, userId) {
        const progress = JSON.parse(localStorage.getItem('enh_progress') || '[]');
        const courseProgress = progress.filter(p => p.courseId === courseId && p.userId === userId);
        
        const lessons = this.getLessons('electrical'); // Get total lessons count
        const totalLessons = lessons.length;
        const completedLessons = courseProgress.length;
        const percentComplete = Math.round((completedLessons / totalLessons) * 100);
        
        let enrollments = JSON.parse(localStorage.getItem('enh_enrollments') || '[]');
        const enrollment = enrollments.find(e => e.courseId === courseId && e.userId === userId);
        
        if (enrollment) {
            enrollment.progress = percentComplete;
            if (percentComplete === 100) {
                enrollment.completed = true;
                enrollment.completedAt = new Date().toISOString();
                this.awardCertificate(courseId);
            }
        }
        
        localStorage.setItem('enh_enrollments', JSON.stringify(enrollments));
    },
    
    // Award certificate on completion
    awardCertificate: function(courseId) {
        const user = window.AuthAPI?.getUser();
        if (!user) return;
        
        let certificates = JSON.parse(localStorage.getItem('enh_certificates') || '[]');
        
        if (!certificates.find(c => c.courseId === courseId && c.userId === user.id)) {
            certificates.push({
                id: Date.now(),
                courseId: courseId,
                userId: user.id,
                userName: user.name,
                awardedAt: new Date().toISOString()
            });
            localStorage.setItem('enh_certificates', JSON.stringify(certificates));
            window.showToast('🎉 Certificate Awarded!', 'success');
        }
    }
};

window.LearningSystem = LearningSystem;

// ============================================
// ACTIVITY TRACKING SYSTEM
// ============================================

const ActivityTracker = {
    // Log an activity
    log: function(type, title, description) {
        const user = window.AuthAPI?.getUser();
        if (!user) return;
        
        let activities = JSON.parse(localStorage.getItem('enh_activities') || '[]');
        
        activities.unshift({
            id: Date.now(),
            type: type,
            title: title,
            description: description,
            userId: user.id,
            userName: user.name,
            timestamp: new Date().toISOString()
        });
        
        // Keep only last 50 activities
        activities = activities.slice(0, 50);
        localStorage.setItem('enh_activities', JSON.stringify(activities));
    },
    
    // Get recent activities
    getRecent: function(limit = 10) {
        const activities = JSON.parse(localStorage.getItem('enh_activities') || '[]');
        return activities.slice(0, limit);
    },
    
    // Activity types
    types: {
        LESSON: 'lesson',
        QUIZ: 'quiz',
        JOB: 'job',
        FORUM: 'forum',
        ENROLLMENT: 'enrollment',
        CERTIFICATE: 'certificate'
    },
    
    // Quick log methods
    logLessonComplete: function(courseName) {
        this.log(this.types.LESSON, `Completed "${courseName}" Lesson`, 'Finished a lesson in your course');
    },
    
    logQuizPass: function(courseName, score) {
        this.log(this.types.QUIZ, `Quiz Passed: ${courseName}`, `Scored ${score}% in the quiz`);
    },
    
    logJobApply: function(jobTitle, company) {
        this.log(this.types.JOB, `Applied to "${jobTitle}"`, `Applied at ${company}`);
    },
    
    logQuestionAsked: function(title) {
        this.log(this.types.FORUM, `Asked: "${title}"`, 'Posted a new question in the community');
    },
    
    logAnswerPosted: function(questionTitle) {
        this.log(this.types.FORUM, `Answered: "${questionTitle}"`, 'Replied to a community question');
    },
    
    logEnrollment: function(courseName) {
        this.log(this.types.ENROLLMENT, `Enrolled in "${courseName}"`, 'Started a new course');
    },
    
    logCertificate: function(courseName) {
        this.log(this.types.CERTIFICATE, `Certificate Earned: ${courseName}`, 'Congratulations on completing the course!');
    }
};

window.ActivityTracker = ActivityTracker;

// Initialize demo activities
function initDemoActivities() {
    if (!localStorage.getItem('enh_activities')) {
        const demoActivities = [
            { id: 1, type: 'lesson', title: 'Completed "DC Circuits" Lesson', description: 'Finished a lesson in your course', userId: 1, userName: 'Ahmed', timestamp: new Date(Date.now() - 2 * 3600000).toISOString() },
            { id: 2, type: 'quiz', title: 'Quiz Passed: Circuit Analysis', description: 'Scored 85% in the quiz', userId: 1, userName: 'Ahmed', timestamp: new Date(Date.now() - 5 * 3600000).toISOString() },
            { id: 3, type: 'job', title: 'Applied to "Junior Engineer"', description: 'Applied at TechCorp Inc.', userId: 1, userName: 'Ahmed', timestamp: new Date(Date.now() - 24 * 3600000).toISOString() },
            { id: 4, type: 'forum', title: 'Answered: "Heat Transfer"', description: 'Replied to a community question', userId: 1, userName: 'Ahmed', timestamp: new Date(Date.now() - 48 * 3600000).toISOString() },
            { id: 5, type: 'enrollment', title: 'Enrolled in "Circuit Analysis"', description: 'Started a new course', userId: 1, userName: 'Ahmed', timestamp: new Date(Date.now() - 72 * 3600000).toISOString() }
        ];
        localStorage.setItem('enh_activities', JSON.stringify(demoActivities));
    }
}

// Render recent activities
function renderRecentActivities() {
    const container = document.getElementById('recentActivities');
    if (!container) return;
    
    const activities = ActivityTracker.getRecent(10);
    
    if (activities.length === 0) {
        container.innerHTML = '<p class="text-center text-muted p-3">No recent activity. Start learning!</p>';
        return;
    }
    
    const icons = {
        lesson: { svg: '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/>', color: 'primary' },
        quiz: { svg: '<path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/>', color: 'success' },
        job: { svg: '<rect x="2" y="7" width="20" height="14" rx="2"/><path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16"/>', color: 'warning' },
        forum: { svg: '<path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>', color: 'danger' },
        enrollment: { svg: '<path d="M22 10v6M2 10l10-5 10 5-10 5z"/>', color: 'primary' },
        certificate: { svg: '<circle cx="12" cy="8" r="7"/><polyline points="8.21 13.89 7 23 12 20 17 23 15.79 13.88"/>', color: 'success' }
    };
    
    container.innerHTML = activities.map(a => `
        <div class="flex items-center gap-3">
            <div class="stats-icon ${icons[a.type]?.color || 'primary'}" style="width: 40px; height: 40px; flex-shrink: 0;">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    ${icons[a.type]?.svg || icons.lesson.svg}
                </svg>
            </div>
            <div>
                <p class="font-medium">${a.title}</p>
                <p class="text-sm text-muted">${formatDate(a.timestamp)}</p>
            </div>
        </div>
    `).join('');
}

window.renderRecentActivities = renderRecentActivities;

// ============================================
// PRACTICE LAB SYSTEM
// ============================================

const PracticeLab = {
    // Get practice questions by field and topic
    getQuestions: function(field, topic) {
        const questions = {
            electrical: {
                circuits: [
                    { q: 'Calculate current if V=12V and R=4Ω', a: '3A', type: 'numeric' },
                    { q: 'Resistance of a wire doubles, current becomes?', a: 'half', type: 'text' },
                    { q: 'Power when V=10V and I=2A', a: '20W', type: 'numeric' },
                    { q: 'Three 10Ω resistors in parallel give?', a: '3.33Ω', type: 'numeric' },
                    { q: 'Ohm\'s Law formula is', a: 'V=IR', type: 'text' }
                ],
                electronics: [
                    { q: 'Diode allows current in?', a: 'one', type: 'text' },
                    { q: 'LED stands for', a: 'light', type: 'text' },
                    { q: 'Capacitor blocks DC', a: 'true', type: 'text' },
                    { q: 'Transistor has how many terminals?', a: '3', type: 'numeric' },
                    { q: 'Zener diode is used for', a: 'regulation', type: 'text' }
                ]
            },
            mechanical: {
                thermo: [
                    { q: 'Absolute zero in Celsius', a: '-273', type: 'numeric' },
                    { q: 'Water freezes at', a: '0', type: 'numeric' },
                    { q: 'Heat transfer by conduction needs', a: 'medium', type: 'text' },
                    { q: 'SI unit of temperature', a: 'kelvin', type: 'text' },
                    { q: 'Q = mcΔT is for', a: 'heat', type: 'text' }
                ],
                design: [
                    { q: 'Steel is measured in', a: 'MPa', type: 'text' },
                    { q: 'Safety factor is', a: 'ratio', type: 'text' },
                    { q: 'FOS stands for', a: 'factor', type: 'text' },
                    { q: 'Cyclic loading causes', a: 'fatigue', type: 'text' },
                    { q: 'Young\'s modulus measures', a: 'stiffness', type: 'text' }
                ]
            },
            civil: {
                structural: [
                    { q: 'Steel has high', a: 'strength', type: 'text' },
                    { q: 'Load type: Dead load is', a: 'permanent', type: 'text' },
                    { q: 'Bending moment unit', a: 'Nm', type: 'text' },
                    { q: 'Shear force is', a: 'force', type: 'text' },
                    { q: 'Moment of inertia measures', a: 'stiffness', type: 'text' }
                ],
                concrete: [
                    { q: 'Concrete strength tested with', a: 'cube', type: 'text' },
                    { q: 'Cement ratio typically', a: '1:2:4', type: 'text' },
                    { q: 'Water/cement ratio affects', a: 'strength', type: 'text' },
                    { q: 'Curing requires', a: 'water', type: 'text' },
                    { q: 'RCC has', a: 'steel', type: 'text' }
                ]
            },
            software: {
                programming: [
                    { q: 'Variable stores', a: 'data', type: 'text' },
                    { q: 'Loop repeats', a: 'code', type: 'text' },
                    { q: 'If checks', a: 'condition', type: 'text' },
                    { q: 'Array index starts at', a: '0', type: 'numeric' },
                    { q: 'Function is reusable', a: 'code', type: 'text' }
                ],
                algorithms: [
                    { q: 'Binary search needs sorted', a: 'array', type: 'text' },
                    { q: 'Big O of linear search', a: 'n', type: 'text' },
                    { q: 'Sorting algorithm', a: 'bubble', type: 'text' },
                    { q: 'Quick sort is', a: 'fast', type: 'text' },
                    { q: 'Stack is', a: 'LIFO', type: 'text' }
                ]
            }
        };
        
        return questions[field]?.[topic] || [];
    },
    
    // Start practice session
    startSession: function(field, topic) {
        const questions = this.getQuestions(field, topic);
        if (questions.length === 0) {
            window.showToast('No questions available', 'warning');
            return;
        }
        
        window.currentPractice = {
            field: field,
            topic: topic,
            questions: questions,
            currentIndex: 0,
            score: 0,
            answers: []
        };
        
        this.showQuestion();
    },
    
    // Show current question
    showQuestion: function() {
        const practice = window.currentPractice;
        if (!practice) return;
        
        if (practice.currentIndex >= practice.questions.length) {
            this.showResults();
            return;
        }
        
        const q = practice.questions[practice.currentIndex];
        const container = document.getElementById('practiceQuestion');
        
        if (container) {
            container.innerHTML = `
                <div class="card" style="padding: 24px;">
                    <div class="mb-3">
                        <span class="badge badge-primary">Question ${practice.currentIndex + 1} of ${practice.questions.length}</span>
                        <span class="badge badge-secondary">${practice.topic}</span>
                    </div>
                    <h3>${q.q}</h3>
                    <div class="form-group mt-3">
                        <input type="text" id="practiceAnswer" class="form-input" placeholder="Type your answer...">
                    </div>
                    <button class="btn btn-primary" onclick="PracticeLab.submitAnswer()">Submit</button>
                </div>
            `;
        }
    },
    
    // Submit answer
    submitAnswer: function() {
        const practice = window.currentPractice;
        if (!practice) return;
        
        const userAnswer = document.getElementById('practiceAnswer')?.value.toLowerCase().trim();
        const question = practice.questions[practice.currentIndex];
        
        let correct = false;
        if (question.type === 'numeric') {
            correct = userAnswer === question.a;
        } else {
            correct = userAnswer && question.a.includes(userAnswer);
        }
        
        practice.answers.push({
            question: question.q,
            userAnswer: userAnswer,
            correct: correct,
            correctAnswer: question.a
        });
        
        if (correct) {
            practice.score++;
            window.showToast('Correct!', 'success');
        } else {
            window.showToast('Incorrect. Answer: ' + question.a, 'error');
        }
        
        practice.currentIndex++;
        this.showQuestion();
    },
    
    // Show results
    showResults: function() {
        const practice = window.currentPractice;
        if (!practice) return;
        
        const container = document.getElementById('practiceQuestion');
        const percent = Math.round((practice.score / practice.questions.length) * 100);
        
        if (container) {
            container.innerHTML = `
                <div class="card text-center" style="padding: 32px;">
                    <div style="font-size: 64px;">${percent >= 70 ? '🎉' : '📚'}</div>
                    <h3>${percent >= 70 ? 'Great Job!' : 'Keep Practicing!'}</h3>
                    <p class="text-2xl font-bold mt-2" style="color: ${percent >= 70 ? 'var(--accent)' : 'var(--warning)'}">${percent}%</p>
                    <p class="text-secondary">Score: ${practice.score}/${practice.questions.length}</p>
                    <div class="mt-4">
                        <button class="btn btn-primary" onclick="PracticeLab.startSession('${practice.field}', '${practice.topic}')">Practice Again</button>
                        <button class="btn btn-secondary" onclick="closeModal('practiceModal')">Close</button>
                    </div>
                </div>
            `;
        }
    }
};

window.PracticeLab = PracticeLab;

// ============================================
// ENGINEERING SIMULATION SYSTEM
// ============================================

const EngineeringSim = {
    // Circuit simulation - calculate values
    simulateCircuit: function() {
        const voltage = parseFloat(document.getElementById('simVoltage')?.value);
        const resistance = parseFloat(document.getElementById('simResistance')?.value);
        
        if (isNaN(voltage) || isNaN(resistance) || resistance === 0) {
            window.showToast('Please enter valid values', 'warning');
            return;
        }
        
        const current = voltage / resistance;
        const power = voltage * current;
        
        const results = document.getElementById('simResults');
        if (results) {
            results.innerHTML = `
                <div class="grid grid-3" style="text-align: center;">
                    <div class="card" style="padding: 16px;">
                        <div style="font-size: 24px; font-weight: 700;">${voltage.toFixed(2)}V</div>
                        <div class="text-sm text-muted">Voltage</div>
                    </div>
                    <div class="card" style="padding: 16px;">
                        <div style="font-size: 24px; font-weight: 700;">${current.toFixed(2)}A</div>
                        <div class="text-sm text-muted">Current</div>
                    </div>
                    <div class="card" style="padding: 16px;">
                        <div style="font-size: 24px; font-weight: 700;">${power.toFixed(2)}W</div>
                        <div class="text-sm text-muted">Power</div>
                    </div>
                </div>
            `;
            results.style.display = 'block';
        }
    },
    
    // Structural load simulation
    simulateStructure: function() {
        const area = parseFloat(document.getElementById('structArea')?.value);
        const force = parseFloat(document.getElementById('structForce')?.value);
        const material = document.getElementById('structMaterial')?.value;
        
        if (isNaN(area) || isNaN(force)) {
            window.showToast('Please enter valid values', 'warning');
            return;
        }
        
        const materials = {
            steel: { yield: 250 },
            concrete: { yield: 30 },
            aluminum: { yield: 150 },
            wood: { yield: 40 }
        };
        
        const mat = materials[material];
        if (!mat) return;
        
        const stress = force / area; // MPa
        const FOS = mat.yield / stress;
        const isSafe = FOS > 1.5;
        
        const results = document.getElementById('structResults');
        if (results) {
            results.innerHTML = `
                <div class="grid grid-3" style="text-align: center;">
                    <div class="card" style="padding: 16px;">
                        <div style="font-size: 24px; font-weight: 700;">${stress.toFixed(2)}</div>
                        <div class="text-sm text-muted">Stress (MPa)</div>
                    </div>
                    <div class="card" style="padding: 16px;">
                        <div style="font-size: 24px; font-weight: 700;">${FOS.toFixed(2)}</div>
                        <div class="text-sm text-muted">Factor of Safety</div>
                    </div>
                    <div class="card" style="padding: 16px;">
                        <div style="font-size: 24px; font-weight: 700; color: ${isSafe ? 'var(--accent)' : 'var(--danger)'}">
                            ${isSafe ? 'SAFE' : 'UNSAFE'}
                        </div>
                        <div class="text-sm text-muted">Status</div>
                    </div>
                </div>
            `;
            results.style.display = 'block';
        }
    }
};

window.EngineeringSim = EngineeringSim;

// ============================================
// EXAM SYSTEM
// ============================================

const ExamSystem = {
    // Start exam
    startExam: function(courseId, duration) {
        const user = window.AuthAPI?.getUser();
        if (!user) {
            window.showToast('Please login to take exams', 'warning');
            window.location.href = '../auth/login.html';
            return;
        }
        
        // Get random questions from bank
        let questions = this.getExamQuestions(courseId);
        questions = this.shuffleArray(questions).slice(0, 10);
        
        window.currentExam = {
            courseId: courseId,
            questions: questions,
            duration: duration || 30, // minutes
            timeRemaining: (duration || 30) * 60,
            currentIndex: 0,
            answers: [],
            startTime: new Date().toISOString()
        };
        
        this.showQuestion();
        this.startTimer();
    },
    
    // Get exam questions
    getExamQuestions: function(courseId) {
        const allQuestions = [
            { q: 'What is Ohm\'s Law?', options: ['V = IR', 'V = I/R', 'V = I + R', 'V = I*R'], correct: 0 },
            { q: 'Unit of resistance?', options: ['Volt', 'Ampere', 'Ohm', 'Watt'], correct: 2 },
            { q: 'Power formula is?', options: ['P = V/I', 'P = VI', 'P = V²/R', 'All of above'], correct: 3 },
            { q: 'Current in series circuit is?', options: ['Same', 'Different', 'Zero', 'Infinite'], correct: 0 },
            { q: 'Parallel resistors have?', options: ['Same voltage', 'Same current', 'Higher voltage', 'No voltage'], correct: 0 },
            { q: 'Capacitor stores?', options: ['Charge', 'Energy', 'Both', 'Nothing'], correct: 2 },
            { q: 'Inductor opposes change in?', options: ['Voltage', 'Current', 'Resistance', 'Power'], correct: 1 },
            { q: 'Diode allows current?', options: ['One direction', 'Both', 'No', 'All'], correct: 0 },
            { q: 'Transistor can?', options: ['Amplify', 'Switch', 'Both', 'Nothing'], correct: 2 },
            { q: 'Op-AMP stands for?', options: ['Operational', 'Optical', 'Output', 'Over'], correct: 0 },
            { q: 'Zener diode used for?', options: ['Rectification', 'Regulation', 'Amplification', 'Filtering'], correct: 1 },
            { q: 'RMS value of sine wave is?', options: ['Peak/√2', 'Peak*2', 'Peak', 'Zero'], correct: 0 },
            { q: 'Transformer works on?', options: ['AC', 'DC', 'Both', 'Neither'], correct: 0 },
            { q: 'Capacitive reactance decreases with?', options: ['Frequency', 'Voltage', 'Capacitance', 'Time'], correct: 0 },
            { q: 'Power factor is?', options: ['P/S', 'P*V', 'V/I', 'P*R'], correct: 0 }
        ];
        
        return allQuestions;
    },
    
    // Shuffle array
    shuffleArray: function(array) {
        for (let i = array.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [array[i], array[j]] = [array[j], array[i]];
        }
        return array;
    },
    
    // Show question
    showQuestion: function() {
        const exam = window.currentExam;
        if (!exam) return;
        
        if (exam.currentIndex >= exam.questions.length) {
            this.submitExam();
            return;
        }
        
        const q = exam.questions[exam.currentIndex];
        const container = document.getElementById('examQuestion');
        
        if (container) {
            container.innerHTML = `
                <div class="card" style="padding: 24px;">
                    <div class="flex justify-between items-center mb-3">
                        <span class="badge badge-primary">Question ${exam.currentIndex + 1} of ${exam.questions.length}</span>
                        <span class="badge badge-warning" id="examTimer">${Math.floor(exam.timeRemaining / 60)}:${(exam.timeRemaining % 60).toString().padStart(2, '0')}</span>
                    </div>
                    <h3 class="mb-3">${q.q}</h3>
                    <div class="flex flex-col gap-2">
                        ${q.options.map((opt, i) => `
                            <label style="display:flex;align-items:center;gap:12px;padding:12px;border:1px solid var(--border-light);border-radius:8px;cursor:pointer;">
                                <input type="radio" name="examAnswer" value="${i}">
                                <span>${opt}</span>
                            </label>
                        `).join('')}
                    </div>
                    <button class="btn btn-primary mt-3" onclick="ExamSystem.submitAnswer()">Next</button>
                </div>
            `;
        }
    },
    
    // Submit answer
    submitAnswer: function() {
        const exam = window.currentExam;
        if (!exam) return;
        
        const selected = document.querySelector('input[name="examAnswer"]:checked');
        if (!selected) {
            window.showToast('Please select an answer', 'warning');
            return;
        }
        
        exam.answers.push(parseInt(selected.value));
        exam.currentIndex++;
        this.showQuestion();
    },
    
    // Timer
    startTimer: function() {
        window.examTimer = setInterval(() => {
            const exam = window.currentExam;
            if (!exam) {
                clearInterval(window.examTimer);
                return;
            }
            
            exam.timeRemaining--;
            
            const timerEl = document.getElementById('examTimer');
            if (timerEl) {
                timerEl.textContent = `${Math.floor(exam.timeRemaining / 60)}:${(exam.timeRemaining % 60).toString().padStart(2, '0')}`;
            }
            
            if (exam.timeRemaining <= 0) {
                this.submitExam();
            }
        }, 1000);
    },
    
    // Submit exam
    submitExam: function() {
        clearInterval(window.examTimer);
        
        const exam = window.currentExam;
        if (!exam) return;
        
        let correct = 0;
        exam.questions.forEach((q, i) => {
            if (exam.answers[i] === q.correct) correct++;
        });
        
        const score = Math.round((correct / exam.questions.length) * 100);
        const passed = score >= 70;
        
        // Determine level
        let level = 'Beginner';
        if (score >= 90) level = 'Advanced';
        else if (score >= 70) level = 'Intermediate';
        
        // Save result
        this.saveResult(exam.courseId, score, level);
        
        // Show results
        const container = document.getElementById('examQuestion');
        if (container) {
            container.innerHTML = `
                <div class="card text-center" style="padding: 32px;">
                    <div style="font-size: 64px;">${passed ? '🎉' : '📚'}</div>
                    <h3>${passed ? 'Exam Passed!' : 'Exam Not Passed'}</h3>
                    <p class="text-2xl font-bold mt-2" style="color: ${passed ? 'var(--accent)' : 'var(--danger)'}">${score}%</p>
                    <p class="text-secondary">Level: <strong>${level}</strong></p>
                    <p class="text-sm text-muted mt-2">${correct} correct out of ${exam.questions.length} questions</p>
                    <div class="mt-4">
                        <button class="btn btn-primary" onclick="closeModal('examModal')">Done</button>
                    </div>
                </div>
            `;
        }
    },
    
    // Save exam result
    saveResult: function(courseId, score, level) {
        const user = window.AuthAPI?.getUser();
        if (!user) return;
        
        let results = JSON.parse(localStorage.getItem('enh_exam_results') || '[]');
        results.push({
            id: Date.now(),
            courseId: courseId,
            userId: user.id,
            userName: user.name,
            score: score,
            level: level,
            takenAt: new Date().toISOString()
        });
        
        localStorage.setItem('enh_exam_results', JSON.stringify(results));
    }
};

window.ExamSystem = ExamSystem;

// ============================================
// APPLICATIONS & CAREER SYSTEM
// ============================================

const ApplicationSystem = {
    // Submit internship application
    submitApplication: function(type) {
        const user = window.AuthAPI?.getUser();
        if (!user) {
            window.showToast('Please login first', 'warning');
            return;
        }
        
        const formData = {
            name: document.getElementById('appName')?.value,
            email: document.getElementById('appEmail')?.value,
            phone: document.getElementById('appPhone')?.value,
            field: document.getElementById('appField')?.value,
            experience: document.getElementById('appExperience')?.value,
            type: type
        };
        
        if (!formData.name || !formData.email) {
            window.showToast('Please fill required fields', 'warning');
            return;
        }
        
        let applications = JSON.parse(localStorage.getItem('enh_applications') || '[]');
        applications.push({
            id: Date.now(),
            ...formData,
            userId: user.id,
            status: 'pending',
            submittedAt: new Date().toISOString()
        });
        
        localStorage.setItem('enh_applications', JSON.stringify(applications));
        
        window.showToast('Application submitted successfully!', 'success');
        closeModal('applicationModal');
    },
    
    // Get user applications
    getMyApplications: function() {
        const user = window.AuthAPI?.getUser();
        if (!user) return [];
        
        const applications = JSON.parse(localStorage.getItem('enh_applications') || '[]');
        return applications.filter(a => a.userId === user.id);
    },
    
    // Build CV
    buildCV: function() {
        const user = window.AuthAPI?.getUser();
        if (!user) {
            window.showToast('Please login first', 'warning');
            return;
        }
        
        const cv = {
            name: document.getElementById('cvName')?.value,
            email: document.getElementById('cvEmail')?.value,
            phone: document.getElementById('cvPhone')?.value,
            summary: document.getElementById('cvSummary')?.value,
            education: document.getElementById('cvEducation')?.value,
            experience: document.getElementById('cvExperience')?.value,
            skills: document.getElementById('cvSkills')?.value
        };
        
        localStorage.setItem('enh_cv_' + user.id, JSON.stringify(cv));
        
        window.showToast('CV saved successfully!', 'success');
        closeModal('cvModal');
    }
};

window.ApplicationSystem = ApplicationSystem;

// ============================================
// ENHANCED PROFILE SYSTEM
// ============================================

const ProfileSystem = {
    // Get profile stats
    getProfileStats: function() {
        const user = window.AuthAPI?.getUser();
        if (!user) return null;
        
        const enrollments = JSON.parse(localStorage.getItem('enh_enrollments') || '[]');
        const userEnrollments = enrollments.filter(e => e.userId === user.id);
        
        const certificates = JSON.parse(localStorage.getItem('enh_certificates') || '[]');
        const userCerts = certificates.filter(c => c.userId === user.id);
        
        const exams = JSON.parse(localStorage.getItem('enh_exam_results') || '[]');
        const userExams = exams.filter(e => e.userId === user.id);
        
        const applications = JSON.parse(localStorage.getItem('enh_applications') || '[]');
        const userApps = applications.filter(a => a.userId === user.id);
        
        return {
            coursesEnrolled: userEnrollments.length,
            coursesCompleted: userEnrollments.filter(e => e.completed).length,
            certificates: userCerts.length,
            examsPassed: userExams.filter(e => e.score >= 70).length,
            applications: userApps.length,
            level: LearningSystem.getUserLevel()
        };
    },
    
    // Render profile overview
    renderProfile: function() {
        const user = window.AuthAPI?.getUser();
        if (!user) return;
        
        const stats = this.getProfileStats();
        
        // Update name and email
        document.getElementById('profileName').textContent = user.name;
        document.getElementById('profileEmail').textContent = user.email;
        document.getElementById('profileRole').textContent = user.role;
        document.getElementById('profileLevel').textContent = stats.level;
        
        // Update stats
        document.getElementById('statCoursesEnrolled').textContent = stats.coursesEnrolled;
        document.getElementById('statCoursesCompleted').textContent = stats.coursesCompleted;
        document.getElementById('statCertificates').textContent = stats.certificates;
        document.getElementById('statExamsPassed').textContent = stats.examsPassed;
        
        // Update avatar
        const avatar = document.getElementById('profileAvatar');
        if (avatar && user.avatar) {
            avatar.innerHTML = `<img src="${user.avatar}" style="width:100%;height:100%;object-fit:cover;border-radius:50%;">`;
        } else if (avatar) {
            const initials = user.name.split(' ').map(n => n[0]).join('').substring(0, 2).toUpperCase();
            avatar.textContent = initials;
        }
    }
};

window.ProfileSystem = ProfileSystem;

// ============================================
// SETTINGS SYSTEM
// ============================================

const SettingsSystem = {
    // Update email
    updateEmail: function() {
        const newEmail = document.getElementById('newEmail')?.value;
        const confirmEmail = document.getElementById('confirmNewEmail')?.value;
        
        if (!newEmail || !confirmEmail) {
            window.showToast('Please fill both fields', 'warning');
            return;
        }
        
        if (newEmail !== confirmEmail) {
            window.showToast('Emails do not match', 'error');
            return;
        }
        
        if (!validateEmail(newEmail)) {
            window.showToast('Invalid email format', 'error');
            return;
        }
        
        const user = window.AuthAPI?.getUser();
        if (user) {
            user.email = newEmail;
            localStorage.setItem('enh_user', JSON.stringify(user));
            window.showToast('Email updated successfully!', 'success');
        }
    },
    
    // Update password
    updatePassword: function() {
        const currentPassword = document.getElementById('currentPassword')?.value;
        const newPassword = document.getElementById('newPassword')?.value;
        const confirmPassword = document.getElementById('confirmNewPassword')?.value;
        
        if (!currentPassword || !newPassword || !confirmPassword) {
            window.showToast('Please fill all fields', 'warning');
            return;
        }
        
        if (newPassword.length < 6) {
            window.showToast('Password must be at least 6 characters', 'error');
            return;
        }
        
        if (newPassword !== confirmPassword) {
            window.showToast('Passwords do not match', 'error');
            return;
        }
        
        window.showToast('Password updated successfully!', 'success');
    },
    
    // Toggle notifications
    toggleNotifications: function(enabled) {
        const user = window.AuthAPI?.getUser();
        if (user) {
            user.notifications = enabled;
            localStorage.setItem('enh_user', JSON.stringify(user));
            window.showToast(enabled ? 'Notifications enabled' : 'Notifications disabled', 'success');
        }
    },
    
    // Save profile
    saveProfile: function() {
        const user = window.AuthAPI?.getUser();
        if (!user) return;
        
        const name = document.getElementById('editName')?.value;
        const bio = document.getElementById('editBio')?.value;
        const skills = document.getElementById('editSkills')?.value;
        
        user.name = name || user.name;
        user.bio = bio || '';
        user.skills = skills ? skills.split(',').map(s => s.trim()) : [];
        
        localStorage.setItem('enh_user', JSON.stringify(user));
        
        window.showToast('Profile updated!', 'success');
        
        if (window.ProfileSystem) {
            ProfileSystem.renderProfile();
        }
    }
};

window.SettingsSystem = SettingsSystem;

// ============================================
// EXPANDED RESOURCE DOWNLOAD SYSTEM
// ============================================

const ResourceLibrary = {
    // Get all resources
    getResources: function() {
        return [
            { id: 1, title: 'Circuit Analysis Formula Sheet', type: 'PDF', category: 'electrical', size: '2.4 MB', downloads: 234 },
            { id: 2, title: 'Thermodynamics Notes', type: 'PDF', category: 'mechanical', size: '1.8 MB', downloads: 189 },
            { id: 3, title: 'Structural Design Guide', type: 'PDF', category: 'civil', size: '3.2 MB', downloads: 156 },
            { id: 4, title: 'Programming Cheat Sheet', type: 'PDF', category: 'software', size: '856 KB', downloads: 312 },
            { id: 5, title: 'Past Exam - Electrical', type: 'PDF', category: 'electrical', size: '1.2 MB', downloads: 445 },
            { id: 6, title: 'Past Exam - Mechanical', type: 'PDF', category: 'mechanical', size: '1.5 MB', downloads: 298 },
            { id: 7, title: 'Engineering Formulas', type: 'PDF', category: 'general', size: '1.1 MB', downloads: 567 },
            { id: 8, title: 'CAD Symbols Library', type: 'PDF', category: 'civil', size: '4.5 MB', downloads: 234 },
            { id: 9, title: 'Algorithm Basics', type: 'PDF', category: 'software', size: '980 KB', downloads: 421 },
            { id: 10, title: 'Project Template', type: 'DOC', category: 'general', size: '245 KB', downloads: 178 },
            { id: 11, title: 'CV Template', type: 'DOC', category: 'general', size: '128 KB', downloads: 890 },
            { id: 12, title: 'Lab Report Format', type: 'DOC', category: 'general', size: '95 KB', downloads: 345 }
        ];
    },
    
    // Render resources
    render: function() {
        const resources = this.getResources();
        const container = document.getElementById('resourcesList');
        
        if (!container) return;
        
        container.innerHTML = resources.map(r => `
            <div class="card resource-card" data-search-item>
                <div class="resource-icon">${r.type}</div>
                <div class="resource-info flex-1">
                    <h4 class="resource-title">${r.title}</h4>
                    <div class="resource-meta">
                        <span class="badge badge-secondary">${r.category}</span>
                        <span>${r.size}</span>
                        <span>${r.downloads} downloads</span>
                    </div>
                </div>
                <button class="btn btn-primary" onclick="downloadResource(${r.id})">Download</button>
            </div>
        `).join('');
    },
    
    // Filter by category
    filterBy: function(category) {
        const resources = this.getResources();
        const container = document.getElementById('resourcesList');
        
        if (!container) return;
        
        const filtered = category === 'all' ? resources : resources.filter(r => r.category === category);
        
        container.innerHTML = filtered.map(r => `
            <div class="card resource-card" data-search-item>
                <div class="resource-icon">${r.type}</div>
                <div class="resource-info flex-1">
                    <h4 class="resource-title">${r.title}</h4>
                    <div class="resource-meta">
                        <span class="badge badge-secondary">${r.category}</span>
                        <span>${r.size}</span>
                        <span>${r.downloads} downloads</span>
                    </div>
                </div>
                <button class="btn btn-primary" onclick="downloadResource(${r.id})">Download</button>
            </div>
        `).join('');
    }
};

window.ResourceLibrary = ResourceLibrary;

function downloadResource(id) {
    const resource = ResourceLibrary.getResources().find(r => r.id === id);
    if (resource) {
        window.showToast(`Downloading ${resource.title}...`, 'success');
    }
}
