// Engineering Nexus Hub - Complete Authentication System

// User data storage
function getUser() {
    const userStr = localStorage.getItem('enh_user');
    return userStr ? JSON.parse(userStr) : null;
}

function saveUser(user) {
    localStorage.setItem('enh_user', JSON.stringify(user));
}

function getToken() {
    return localStorage.getItem('enh_token');
}

function isLoggedIn() {
    return !!getToken();
}

// Login with email/password
function handleLogin(email, password) {
    return new Promise((resolve, reject) => {
        if (!email || !password) {
            reject(new Error('Please fill in all fields'));
            return;
        }
        
        if (!validateEmail(email)) {
            reject(new Error('Please enter a valid email'));
            return;
        }

        setTimeout(() => {
            const user = {
                id: Date.now(),
                name: email.split('@')[0],
                email: email,
                role: 'student',
                field: 'electrical',
                bio: '',
                skills: [],
                avatar: null,
                joinedAt: new Date().toISOString()
            };
            
            localStorage.setItem('enh_token', 'jwt-' + Math.random().toString(36));
            localStorage.setItem('enh_user', JSON.stringify(user));
            
            resolve(user);
        }, 800);
    });
}

// Google Sign-In simulation
function handleGoogleLogin(googleEmail) {
    return new Promise((resolve, reject) => {
        if (!googleEmail) {
            reject(new Error('Please enter your Gmail address'));
            return;
        }

        if (!googleEmail.includes('@gmail.com') && !googleEmail.includes('google')) {
            if (!googleEmail.endsWith('@gmail.com')) {
                reject(new Error('Please use a valid Gmail address'));
                return;
            }
        }

        setTimeout(() => {
            const name = googleEmail.split('@')[0];
            const user = {
                id: Date.now(),
                name: name,
                email: googleEmail,
                role: 'student',
                field: 'electrical',
                bio: '',
                skills: [],
                avatar: null,
                joinedAt: new Date().toISOString(),
                loginMethod: 'google'
            };
            
            localStorage.setItem('enh_token', 'google-' + Math.random().toString(36));
            localStorage.setItem('enh_user', JSON.stringify(user));
            
            resolve(user);
        }, 800);
    });
}

// Facebook Sign-In simulation
function handleFacebookLogin(email) {
    return new Promise((resolve, reject) => {
        if (!email) {
            reject(new Error('Please enter your Facebook email'));
            return;
        }

        setTimeout(() => {
            const name = email.split('@')[0];
            const user = {
                id: Date.now(),
                name: name,
                email: email,
                role: 'student',
                field: 'electrical',
                bio: '',
                skills: [],
                avatar: null,
                joinedAt: new Date().toISOString(),
                loginMethod: 'facebook'
            };
            
            localStorage.setItem('enh_token', 'fb-' + Math.random().toString(36));
            localStorage.setItem('enh_user', JSON.stringify(user));
            
            resolve(user);
        }, 800);
    });
}

// Register new user
function handleRegister(name, email, password, role, field) {
    return new Promise((resolve, reject) => {
        if (!name || !email || !password) {
            reject(new Error('Please fill in all required fields'));
            return;
        }
        
        if (!validateEmail(email)) {
            reject(new Error('Please enter a valid email'));
            return;
        }

        if (password.length < 6) {
            reject(new Error('Password must be at least 6 characters'));
            return;
        }

        setTimeout(() => {
            const user = {
                id: Date.now(),
                name: name,
                email: email,
                role: role || 'student',
                field: field || 'electrical',
                bio: '',
                skills: [],
                avatar: null,
                joinedAt: new Date().toISOString()
            };
            
            localStorage.setItem('enh_token', 'jwt-' + Math.random().toString(36));
            localStorage.setItem('enh_user', JSON.stringify(user));
            
            // Store user in users list for stats counting
            const users = JSON.parse(localStorage.getItem('enh_users') || '[]');
            users.push({
                id: user.id,
                name: name,
                email: email,
                role: role || 'student',
                field: field || 'electrical',
                joinedAt: new Date().toISOString()
            });
            localStorage.setItem('enh_users', JSON.stringify(users));
            
            resolve(user);
        }, 800);
    });
}

// Logout - clears all user data
function logout() {
    localStorage.removeItem('enh_token');
    localStorage.removeItem('enh_user');
    window.location.href = '../auth/login.html';
}

// Update user profile
function updateProfile(updates) {
    const user = getUser();
    if (!user) return null;
    
    const updatedUser = { ...user, ...updates };
    saveUser(updatedUser);
    return updatedUser;
}

// Change password
function changePassword(currentPassword, newPassword) {
    return new Promise((resolve, reject) => {
        if (!currentPassword || !newPassword) {
            reject(new Error('Please fill in all password fields'));
            return;
        }
        if (newPassword.length < 6) {
            reject(new Error('New password must be at least 6 characters'));
            return;
        }
        
        setTimeout(() => {
            resolve(true);
        }, 500);
    });
}

// Export functions for global use
window.AuthAPI = {
    getUser,
    saveUser,
    isLoggedIn,
    getToken,
    handleLogin,
    handleGoogleLogin,
    handleFacebookLogin,
    handleRegister,
    logout,
    updateProfile,
    changePassword
};

// ============================================
// MULTILINGUAL SYSTEM
// ============================================
const translations = {
    en: {
        home: 'Home', courses: 'Courses', practice: 'Practice Lab', community: 'Community',
        'my questions': 'My Questions', bookmarks: 'Bookmarks', profile: 'Profile', settings: 'Settings', about: 'About',
        login: 'Login', logout: 'Logout', save: 'Save', cancel: 'Cancel', delete: 'Delete', edit: 'Edit',
        search: 'Search', filter: 'Filter', submit: 'Submit', next: 'Next', previous: 'Previous',
        'no results': 'No results found', 'loading': 'Loading...', 'error': 'Error',
        'success': 'Success', 'warning': 'Warning', 'info': 'Info'
    },
    so: {
        home: 'Sh', courses: 'Koorsoyasha', practice: 'Layliska', community: 'Bulsho',
        'my questions': 'Su Alla Gu', bookmarks: 'Bidixiyey', profile: 'Profaayl', settings: 'Dejannada', about: 'Ku Saabsan',
        login: 'Geli', logout: 'Bad', save: 'Keydi', cancel: 'Jebi', delete: 'Tir', edit: 'Wax ka bedel',
        search: 'Raadi', filter: 'Safi', submit: 'Dir', next: 'Dambe', previous: 'Hore',
        'no results': 'Natiijo ma helin', 'loading': 'La geliyey...', 'error': 'Qalad',
        'success': 'Guul', 'warning': 'Eeg', 'info': 'Macluumaad'
    },
    ar: {
        home: 'الرئيسية', courses: 'الدورات', practice: 'مختبر التدريب', community: 'المجتمع',
        'my questions': 'أسئلتي', bookmarks: 'المفضلة', profile: 'الملف الشخصي', settings: 'الإعدادات', about: 'حول',
        login: 'تسجيل الدخول', logout: 'تسجيل الخروج', save: 'حفظ', cancel: 'إلغاء', delete: 'حذف', edit: 'تعديل',
        search: 'بحث', filter: 'تصفية', submit: 'إرسال', next: 'التالي', previous: 'السابق',
        'no results': 'لم يتم العثور على نتائج', 'loading': 'جار التحميل...', 'error': 'خطأ',
        'success': 'نجاح', 'warning': 'تحذير', 'info': 'معلومات'
    }
};

function t(key) {
    const lang = localStorage.getItem('enh_language') || 'en';
    return translations[lang]?.[key] || translations.en[key] || key;
}

function setLanguage(lang) {
    localStorage.setItem('enh_language', lang);
    document.dispatchEvent(new Event('languageChanged'));
}

// ============================================
// BOOKMARK SYSTEM
// ============================================
function addBookmark(type, id, data) {
    const bookmarks = JSON.parse(localStorage.getItem('enh_bookmarks') || '[]');
    const exists = bookmarks.find(b => b.type === type && b.id === id);
    if (!exists) {
        bookmarks.push({ type, id, data, createdAt: new Date().toISOString() });
        localStorage.setItem('enh_bookmarks', JSON.stringify(bookmarks));
    }
    return bookmarks;
}

function removeBookmark(type, id) {
    let bookmarks = JSON.parse(localStorage.getItem('enh_bookmarks') || '[]');
    bookmarks = bookmarks.filter(b => !(b.type === type && b.id === id));
    localStorage.setItem('enh_bookmarks', JSON.stringify(bookmarks));
    return bookmarks;
}

function getBookmarks(type) {
    const bookmarks = JSON.parse(localStorage.getItem('enh_bookmarks') || '[]');
    if (type) return bookmarks.filter(b => b.type === type);
    return bookmarks;
}

function isBookmarked(type, id) {
    const bookmarks = JSON.parse(localStorage.getItem('enh_bookmarks') || '[]');
    return bookmarks.some(b => b.type === type && b.id === id);
}

// ============================================
// PAGINATION SYSTEM
// ============================================
function paginateData(data, page, perPage) {
    const start = (page - 1) * perPage;
    const end = start + perPage;
    return {
        data: data.slice(start, end),
        total: data.length,
        pages: Math.ceil(data.length / perPage),
        current: page
    };
}

// ============================================
// COMMUNITY QUESTIONS SYSTEM
// ============================================
function saveQuestion(question) {
    const questions = JSON.parse(localStorage.getItem('enh_questions') || '[]');
    const newQ = {
        id: Date.now(),
        ...question,
        createdAt: new Date().toISOString(),
        answers: 0,
        votes: 0
    };
    questions.unshift(newQ);
    localStorage.setItem('enh_questions', JSON.stringify(questions));
    return newQ;
}

function getQuestions(category) {
    const questions = JSON.parse(localStorage.getItem('enh_questions') || '[]');
    if (category && category !== 'all') {
        return questions.filter(q => q.category === category);
    }
    return questions;
}

function getUserQuestions(userId) {
    const questions = JSON.parse(localStorage.getItem('enh_questions') || '[]');
    return questions.filter(q => q.userId === userId);
}

function deleteQuestion(id) {
    let questions = JSON.parse(localStorage.getItem('enh_questions') || '[]');
    questions = questions.filter(q => q.id !== id);
    localStorage.setItem('enh_questions', JSON.stringify(questions));
    return questions;
}

// ============================================
// PRACTICE SYSTEM
// ============================================
function savePracticeScore(field, topic, score, total) {
    const scores = JSON.parse(localStorage.getItem('enh_practice_scores') || '[]');
    scores.push({ field, topic, score, total, date: new Date().toISOString() });
    localStorage.setItem('enh_practice_scores', JSON.stringify(scores));
    return scores;
}

function getPracticeScores(field) {
    const scores = JSON.parse(localStorage.getItem('enh_practice_scores') || '[]');
    if (field) return scores.filter(s => s.field === field);
    return scores;
}

function getPerformanceLevel(score, total) {
    const percent = (score / total) * 100;
    if (percent >= 80) return 'Advanced';
    if (percent >= 40) return 'Intermediate';
    return 'Beginner';
}

// ============================================
// FIX MY DATA TOOL
// ============================================
function fixUserData() {
    const user = getUser();
    if (!user) return null;
    
    const defaults = {
        name: user.email?.split('@')[0] || 'Student',
        field: 'electrical',
        faculty: 'CS & IT',
        university: 'Jazeera University',
        skills: [],
        bio: ''
    };
    
    const fixed = { ...defaults, ...user };
    saveUser(fixed);
    return fixed;
}

function validateUserData() {
    const user = getUser();
    if (!user) return { valid: false, issues: ['No user logged in'] };
    
    const issues = [];
    if (!user.name) issues.push('Missing name');
    if (!user.email) issues.push('Missing email');
    if (!user.field) issues.push('Missing field');
    if (!user.faculty) issues.push('Missing faculty');
    if (!user.university) issues.push('Missing university');
    
    return { valid: issues.length === 0, issues };
}

// Export all helper functions
window.ENHSystem = {
    t, setLanguage,
    addBookmark, removeBookmark, getBookmarks, isBookmarked,
    paginateData,
    saveQuestion, getQuestions, getUserQuestions, deleteQuestion,
    savePracticeScore, getPracticeScores, getPerformanceLevel,
    fixUserData, validateUserData
};

// Initialize auth on page load
document.addEventListener('DOMContentLoaded', () => {
    const user = getUser();
    
    // Update user display in navbar
    if (user) {
        const userDisplayName = document.getElementById('userDisplayName');
        if (userDisplayName) userDisplayName.textContent = user.name;
        
        const userAvatar = document.getElementById('userAvatar');
        if (userAvatar) {
            const initials = user.name.split(' ').map(n => n[0]).join('').substring(0, 2).toUpperCase();
            userAvatar.textContent = initials;
        }
    }
});

// ============================================
// AI ASSISTANT SYSTEM
// ============================================
const AIKnowledgeBase = {
    electrical: {
        "ohms law": "Ohm's Law states that Voltage (V) = Current (I) × Resistance (R). For beginners: think of voltage as water pressure, current as water flow, and resistance as pipe narrowness. For experts: V = IR can be rearranged as I = V/R or R = V/I for circuit analysis.",
        "voltage": "Voltage is the electrical potential difference that pushes current through a circuit. Unit: Volt (V). Think of it like water pressure in a pipe - higher pressure pushes more water.",
        "current": "Current is the flow of electric charge through a conductor. Unit: Ampere (A). It flows from positive to negative terminal in conventional current.",
        "resistance": "Resistance opposes current flow. Unit: Ohm (Ω). Higher resistance means less current flows for the same voltage.",
        "capacitor": "A capacitor stores electrical energy in an electric field. It blocks DC but allows AC to pass. Used for filtering and energy storage.",
        "inductor": "An inductor stores energy in a magnetic field when current flows through it. It opposes changes in current flow.",
        "transformer": "A transformer changes AC voltage levels. Step-up increases voltage, step-down decreases voltage. Works on electromagnetic induction principle."
    },
    mechanical: {
        "newtons law": "Newton's Laws: 1) Objects at rest stay at rest; 2) F = ma (Force = mass × acceleration); 3) For every action there's an equal opposite reaction.",
        "force": "Force is a push or pull on an object. Unit: Newton (N). It causes acceleration of mass.",
        "stress": "Stress = Force/Area. Unit: Pascal (Pa). It measures internal force per unit area in a material.",
        "strain": "Strain is deformation per original length. Unitless ratio. ε = ΔL/L₀",
        "thermodynamics": "Laws: 1) Energy conserved; 2) Entropy increases; 3) Absolute zero unreachable. Heat transfers from hot to cold.",
        "entropy": "Entropy measures disorder in a system. In thermodynamics, total entropy of isolated system always increases.",
        "heat transfer": "Three types: Conduction (through material), Convection (by fluid motion), Radiation (as electromagnetic waves)."
    },
    civil: {
        "foundation": "Foundation spreads building load to ground safely. Types: Shallow (depth < width) and Deep (piles, caissons).",
        "concrete": "Concrete = Cement + Water + Aggregates (sand, gravel). Strength develops over 28 days. Mix ratio matters.",
        "steel": "Structural steel has high tensile strength. Used in beams, columns, reinforcement. ASTM standards define properties.",
        "load": "Types: Dead (permanent), Live (variable), Wind, Seismic. Structural design considers all loads per building code.",
        "moment": "Bending moment causes curvature. M = F×d. Maximum moment determines required reinforcement.",
        "shear": "Shear force causes sliding failure. V = F. Critical at supports and point loads.",
        "reinforcement": "Rebar provides tensile strength concrete lacks. Placed in tension zones per design drawings."
    },
    software: {
        "variable": "A variable is a container for data. It has name, type, value. Think of it like a labeled box storing information.",
        "function": "A function is reusable code block. Input → Processing → Output. Functions organize code and avoid repetition.",
        "array": "An array stores multiple values of same type. Access by index starting at 0. Like a numbered list.",
        "loop": "Loops repeat code: for (counted), while (condition), do-while (at least once).",
        "object": "Objects store related data and functions. Properties = data, Methods = functions. Blueprint for instances.",
        "algorithm": "Step-by-step problem-solving procedure. Quality measured by time complexity and space usage.",
        "database": "Organized data storage. Types: Relational (SQL), Document (NoSQL). Query with languages like SQL."
    }
};

function askAI(question, field) {
    const q = question.toLowerCase();
    const kb = AIKnowledgeBase[field] || AIKnowledgeBase.electrical;
    
    for (let [key, answer] of Object.entries(kb)) {
        if (q.includes(key)) {
            return answer;
        }
    }
    
    return "I don't have specific information about that topic. Try asking about: ohm's law, voltage, current, force, stress, foundation, variable, function, array, or another engineering concept.";
}

function getAIExplanation(question, level, field) {
    const basicAnswer = askAI(question, field);
    
    if (level === 'beginner') {
        return "📚 **Simple Explanation:**\n\n" + basicAnswer.split('.')[0] + ".\n\n**Tip:** Think of " + question + " like everyday objects to make it easier!";
    } else if (level === 'intermediate') {
        return "📖 **Step-by-Step Explanation:**\n\n" + basicAnswer;
    } else {
        return "🔬 **Advanced Analysis:**\n\n" + basicAnswer + "\n\n**Mathematical Form:** " + getMathForm(question, field);
    }
}

function getMathForm(topic, field) {
    const forms = {
        "ohms law": "V = IR, I = V/R, R = V/I",
        "newtons law": "F = ma, a = F/m, m = F/a",
        "stress": "σ = F/A",
        "strain": "ε = ΔL/L₀",
        "moment": "M = F × d",
        "shear": "V = F",
        "power": "P = VI = I²R"
    };
    return forms[topic.toLowerCase()] || "Equation varies by specific application";
}

// Make AI available globally
window.AIAssistant = {
    ask: askAI,
    explain: getAIExplanation,
    knowledgeBase: AIKnowledgeBase
};

// ============================================
// GLOBAL LANGUAGE SYSTEM
// ============================================
const translations = {
    en: { home: 'Home', courses: 'Courses', practice: 'Practice Lab', community: 'Community', 'ask questions': 'Ask Questions', bookmarks: 'Bookmarks', profile: 'Profile', settings: 'Settings', about: 'About', tools: 'Tools', jobs: 'Jobs', search: 'Search...', submit: 'Submit', cancel: 'Cancel', save: 'Save', delete: 'Delete', edit: 'Edit', login: 'Login', logout: 'Logout' },
    so: { home: 'Sh', courses: 'Koorsoyasha', practice: 'Layliska', community: 'Bulsho', 'ask questions: 'Waydiiso', bookmarks: 'Bidixiyey', profile: 'Profaayl', settings: 'Dejannada', about: 'Ku Saabsan', tools: 'Qalabka', jobs: 'Shaqo', search: 'Raadi...', submit: 'Dir', cancel: 'Jebi', save: 'Keydi', delete: 'Tir', edit: 'Waxka Bedel', login: 'Geli', logout: 'Bax' },
    ar: { home: 'الرئيسية', courses: 'الدورات', practice: 'مختبر التدريب', community: 'المجتمع', 'ask questions': 'طرح سؤال', bookmarks: 'المفضلة', profile: 'الملف الشخصي', settings: 'الإعدادات', about: 'حول', tools: 'الأدوات', jobs: 'الوظائف', search: 'بحث...', submit: 'إرسال', cancel: 'إلغاء', save: 'حفظ', delete: 'حذف', edit: 'تعديل', login: 'تسجيل الدخول', logout: 'تسجيل الخروج' }
};

function t(key) {
    const lang = localStorage.getItem('enh_language') || 'en';
    return translations[lang]?.[key] || translations.en[key] || key;
}

function setLanguage(lang) {
    localStorage.setItem('enh_language', lang);
    document.documentElement.setAttribute('lang', lang);
    document.querySelectorAll('[data-i18n]').forEach(el => {
        const key = el.dataset.i18n;
        el.textContent = t(key);
    });
}

window.LanguageSystem = { t, setLanguage, translations };

// ============================================
// PRACTICE SYSTEM WITH SCORING
// ============================================
function submitPracticeAnswer(questionId, selectedOption, correctOption) {
    const results = JSON.parse(localStorage.getItem('enh_practice_results') || '[]');
    const isCorrect = selectedOption === correctOption;
    
    results.push({
        questionId,
        selected: selectedOption,
        correct: correctOption,
        isCorrect,
        timestamp: Date.now()
    });
    
    localStorage.setItem('enh_practice_results', JSON.stringify(results));
    return isCorrect;
}

function getPracticeScore(field) {
    const results = JSON.parse(localStorage.getItem('enh_practice_results') || '[]');
    const fieldResults = results.filter(r => r.field === field);
    const correct = fieldResults.filter(r => r.isCorrect).length;
    const total = fieldResults.length;
    
    return {
        correct,
        total,
        percentage: total > 0 ? Math.round((correct / total) * 100) : 0
    };
}

function getPerformanceLevel(score) {
    if (score >= 80) return 'Advanced';
    if (score >= 50) return 'Intermediate';
    return 'Beginner';
}

window.PracticeSystem = {
    submitAnswer: submitPracticeAnswer,
    getScore: getPracticeScore,
    getLevel: getPerformanceLevel
};

// ============================================
// JOBS SYSTEM
// ============================================
const demoJobs = [
    { id: 1, title: 'Junior Electrical Engineer', company: 'MedTech Solutions', location: 'Mogadishu', type: 'Full-time', salary: '$800-1200', field: 'electrical', description: 'Design and maintain medical equipment electrical systems.' },
    { id: 2, title: 'Software Developer', company: 'TechHub Somalia', location: 'Garowe', type: 'Full-time', salary: '$1000-1500', field: 'software', description: 'Develop web and mobile applications.' },
    { id: 3, title: 'Civil Engineer', company: 'BuildCorp', location: 'Hargeisa', type: 'Contract', salary: '$900-1400', field: 'civil', description: ' supervise construction projects.' },
    { id: 4, title: 'Mechanical Technician', company: 'AutoWorks', location: 'Mogadishu', type: 'Full-time', salary: '$700-1000', field: 'mechanical', description: 'Maintain and repair mechanical systems.' },
    { id: 5, title: 'Embedded Systems Engineer', company: 'IoT Solutions', location: 'Dubai', type: 'Full-time', salary: '$2000-3000', field: 'electrical', description: 'Design embedded systems and IoT devices.' },
    { id: 6, title: 'Full Stack Developer', company: 'GlobalTech', location: 'Remote', type: 'Remote', salary: '$1500-2500', field: 'software', description: 'Build complete web applications.' }
];

function getJobs(field) {
    if (!field || field === 'all') return demoJobs;
    return demoJobs.filter(j => j.field === field);
}

function applyToJob(jobId) {
    const user = getUser();
    if (!user) return { success: false, message: 'Please login first' };
    
    const applications = JSON.parse(localStorage.getItem('enh_applications') || '[]');
    const job = demoJobs.find(j => j.id === jobId);
    
    if (!job) return { success: false, message: 'Job not found' };
    
    const exists = applications.find(a => a.jobId === jobId && a.userId === user.id);
    if (exists) return { success: false, message: 'Already applied' };
    
    applications.push({
        userId: user.id,
        jobId,
        job: job,
        status: 'Pending',
        appliedAt: new Date().toISOString()
    });
    
    localStorage.setItem('enh_applications', JSON.stringify(applications));
    return { success: true, message: 'Application submitted!' };
}

function getMyApplications() {
    const user = getUser();
    if (!user) return [];
    const applications = JSON.parse(localStorage.getItem('enh_applications') || '[]');
    return applications.filter(a => a.userId === user.id);
}

window.JobsSystem = {
    getJobs,
    apply: applyToJob,
    getMyApplications,
    demoJobs
};

// ============================================
// BOOKMARKS SYSTEM
// ============================================
function addBookmark(type, id, data) {
    const bookmarks = JSON.parse(localStorage.getItem('enh_bookmarks') || '[]');
    const exists = bookmarks.find(b => b.type === type && b.id === id);
    if (exists) return bookmarks;
    
    bookmarks.push({ type, id, data, createdAt: new Date().toISOString() });
    localStorage.setItem('enh_bookmarks', JSON.stringify(bookmarks));
    return bookmarks;
}

function removeBookmark(type, id) {
    let bookmarks = JSON.parse(localStorage.getItem('enh_bookmarks') || '[]');
    bookmarks = bookmarks.filter(b => !(b.type === type && b.id === id));
    localStorage.setItem('enh_bookmarks', JSON.stringify(bookmarks));
    return bookmarks;
}

function getBookmarks(type) {
    const bookmarks = JSON.parse(localStorage.getItem('enh_bookmarks') || '[]');
    if (!type) return bookmarks;
    return bookmarks.filter(b => b.type === type);
}

function isBookmarked(type, id) {
    const bookmarks = JSON.parse(localStorage.getItem('enh_bookmarks') || '[]');
    return bookmarks.some(b => b.type === type && b.id === id);
}

window.BookmarkSystem = {
    add: addBookmark,
    remove: removeBookmark,
    get: getBookmarks,
    is Bookmarked: isBookmarked
};

// ============================================
// QUESTIONS SYSTEM
// ============================================
function saveQuestion(title, content, category, userId) {
    const questions = JSON.parse(localStorage.getItem('enh_questions') || '[]');
    const newQ = {
        id: Date.now(),
        title,
        content,
        category,
        userId,
        votes: 0,
        answers: 0,
        createdAt: new Date().toISOString()
    };
    questions.unshift(newQ);
    localStorage.setItem('enh_questions', JSON.stringify(questions));
    return newQ;
}

function getQuestions(category) {
    const questions = JSON.parse(localStorage.getItem('enh_questions') || '[]');
    if (!category || category === 'all') return questions;
    return questions.filter(q => q.category === category);
}

function getUserQuestions(userId) {
    const questions = JSON.parse(localStorage.getItem('enh_questions') || '[]');
    return questions.filter(q => q.userId === userId);
}

window.QuestionSystem = {
    save: saveQuestion,
    getAll: getQuestions,
    getUser: getUserQuestions
};
